import re,shutil,os,sys
SP=os.path.dirname(os.path.abspath(__file__));SRC=os.path.join(SP,'pubsrc');OUT=os.path.join(SP,'pub')
os.makedirs(OUT,exist_ok=True)
s=open(os.path.join(SP,'gastos.html')).read()
def rep(a,b,cnt=1):
    global s
    assert s.count(a)==cnt,(a[:70],s.count(a))
    s=s.replace(a,b)
FBV='10.14.1'
head='''<title>Lu-Ks</title>
<meta name="description" content="Lu-Ks: tus finanzas personales, claras. Gratis y sin anuncios: gastos, presupuestos, metas y plan para salir de deudas.">
<meta property="og:type" content="website">
<meta property="og:title" content="Lu-Ks · Tus finanzas, claras">
<meta property="og:description" content="Registra tus gastos en segundos, controla tus presupuestos y sal de deudas con un plan. Gratis y sin anuncios.">
<meta property="og:image" content="https://jimenez19pro.github.io/lu-ks/og-luks.jpg">
<meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">
<meta property="og:url" content="https://jimenez19pro.github.io/lu-ks/">
<meta name="twitter:card" content="summary_large_image">
<meta name="theme-color" content="#F2F2F7" media="(prefers-color-scheme: light)">
<meta name="theme-color" content="#000000" media="(prefers-color-scheme: dark)">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Lu-Ks">
<link rel="manifest" href="manifest.json">
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<link rel="icon" type="image/png" href="icon-192.png">
<script src="config.js"></script>
<script src="https://www.gstatic.com/firebasejs/%s/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/%s/firebase-auth-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/%s/firebase-firestore-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/%s/firebase-messaging-compat.js"></script>'''%(FBV,FBV,FBV,FBV)
import json as _j
I18N=open(os.path.join(SRC,'i18n.js')).read().replace('__DICT__',_j.dumps(_j.load(open(os.path.join(SRC,'dict.json'))),ensure_ascii=False))
head=head+'\n<script>'+I18N+'</script>'
rep('<title>Lu-Ks</title>',head)
rep('</style>','\n'+open(os.path.join(SRC,'auth.css')).read()+'\n'+open(os.path.join(SRC,'ui.css')).read()+'\n'+open(os.path.join(SRC,'ios.css')).read()+'\n'+open(os.path.join(SRC,'nuevo.css')).read()+'</style>')
# shim before main script
i=s.find('<script>',s.find('<body'));s=s[:i]+'<script>\n'+open(os.path.join(SRC,'shim.js')).read()+'\n</script>\n'+s[i:]
# Ajustes: sin automatización iOS ni hoja de Google
m=re.search(r"<h2>Automatización en iOS</h2>.*?<h2>Configuración</h2>",s,re.S);assert m;s=s[:m.start()]+"<h2>Configuración</h2>"+s[m.end():]
m=re.search(r"'<h2>Tus datos</h2>.*?'</div>'\}\nfunction manage\(",s,re.S);assert m;s=s[:m.start()]+"LKPUB.cuentaHtml()}\nfunction manage("+s[m.end():]
rep('t="Hoja sincronizada"','t="Sincronizado"')
rep('t="Conectado. Aún no hay gastos en tu hoja."','t="¡Bienvenido! Toca + para registrar tu primer movimiento."')
rep('t="Abre esta página dentro de Claude para leer tu hoja Gastos."','t="Conectando…"')
k=s.rfind('window.LKREADY=true;');s=s[:k]+open(os.path.join(SRC,'post.js')).read()+'\n'+open(os.path.join(SRC,'imp.js')).read()+'\n'+open(os.path.join(SRC,'onb.js')).read()+'\n'+open(os.path.join(SRC,'siri.js')).read()+'\n'+open(os.path.join(SRC,'land.js')).read()+'\n'+open(os.path.join(SRC,'story.js')).read()+'\n'+open(os.path.join(SRC,'push.js')).read().replace('__VAPID__',(open(os.path.join(SRC,'vapid.txt')).read().strip() if os.path.exists(os.path.join(SRC,'vapid.txt')) else '__VAPID__'))+'\n'+open(os.path.join(SRC,'gar.js')).read()+'\n'+open(os.path.join(SRC,'auto.js')).read()+'\n'+open(os.path.join(SRC,'port.js')).read()+'\n'+open(os.path.join(SRC,'lic.js')).read()+'\n'+open(os.path.join(SRC,'ui.js')).read()+'\n'+open(os.path.join(SRC,'li.js')).read()+'\n'+open(os.path.join(SRC,'nuevo.js')).read()+'\n'+s[k:]
# ---------- Seguridad: política de contenido (CSP) ----------
# Le dice al navegador de dónde puede cargar código y a dónde puede conectarse la página.
# Si algún día la app usa un servicio nuevo (otra dirección de internet), hay que agregarlo aquí
# o el navegador lo bloquea (se ve en la consola como "Content Security Policy").
def csp(extra_script='',extra_connect=''):
    p=["default-src 'self'",
       "script-src 'self' 'unsafe-inline' https://www.gstatic.com https://apis.google.com"+extra_script,
       "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
       "font-src 'self' data: https://fonts.gstatic.com",
       "img-src 'self' data: blob: https:",
       "media-src 'self' data: blob:",
       "connect-src 'self' data: blob: https://*.googleapis.com https://www.gstatic.com https://lu-ks-ia.firebaseapp.com https://*.firebaseio.com wss://*.firebaseio.com"+extra_connect,
       "frame-src 'self' https://lu-ks-ia.firebaseapp.com https://*.google.com",
       "worker-src 'self' blob:",
       "manifest-src 'self'",
       "object-src 'none'",
       "base-uri 'self'",
       "form-action 'self'"]
    return '<meta http-equiv="Content-Security-Policy" content="'+'; '.join(p)+'">\n<meta name="referrer" content="strict-origin-when-cross-origin">'
def con_csp(html,meta):
    assert 'Content-Security-Policy' not in html
    i=html.lower().find('<meta charset="utf-8">');assert i>=0
    j=i+len('<meta charset="utf-8">')
    return html[:j]+'\n'+meta+html[j:]
CSP_LUKS=csp()
# Tienda: además el lector de códigos de barras (barcode-detector) baja un archivo WebAssembly de jsdelivr
# y necesita permiso para compilarlo ('wasm-unsafe-eval'; 'unsafe-eval' es para iPhone con iOS 15 o anterior).
CSP_TIENDA=csp(" 'wasm-unsafe-eval' 'unsafe-eval' https://*.jsdelivr.net https://unpkg.com",' https://world.openfoodfacts.org https://*.jsdelivr.net https://unpkg.com')
CSP_SIMPLE='<meta http-equiv="Content-Security-Policy" content="default-src \'self\'; script-src \'self\' \'unsafe-inline\'; style-src \'self\' \'unsafe-inline\'; img-src \'self\' data:; media-src \'self\'; object-src \'none\'; base-uri \'self\'; form-action \'self\'">'
s=con_csp(s,CSP_LUKS)
open(os.path.join(OUT,'index.html'),'w').write(s)
for f in ['sw.js','manifest.json','privacidad.html','icon-192.png','icon-512.png','apple-touch-icon.png','og-luks.jpg','lu-ks-poster.jpg','lu-ks-video.mp4']:
    if os.path.exists(os.path.join(SRC,f)):shutil.copy(os.path.join(SRC,f),os.path.join(OUT,f))  # el video no va en el zip: si falta, se salta
if not os.path.exists(os.path.join(OUT,'config.js')):
    open(os.path.join(OUT,'config.js'),'w').write('window.LUKS_FB=null;\n')
TD=os.path.join(SRC,'tienda')
if os.path.isdir(TD):
    os.makedirs(os.path.join(OUT,'tienda'),exist_ok=True)
    for f in os.listdir(TD):
        shutil.copy(os.path.join(TD,f),os.path.join(OUT,'tienda',f))
    for f,meta in [('index.html',CSP_TIENDA),('conoce.html',CSP_SIMPLE)]:
        p=os.path.join(OUT,'tienda',f)
        if os.path.exists(p):
            h=open(p,encoding='utf-8').read();open(p,'w',encoding='utf-8').write(con_csp(h,meta))
p=os.path.join(OUT,'privacidad.html');h=open(p,encoding='utf-8').read()
if '<meta charset="utf-8">' in h.lower():open(p,'w',encoding='utf-8').write(con_csp(h,CSP_SIMPLE))
print('built',len(s))
