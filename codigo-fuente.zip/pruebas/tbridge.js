const {chromium}=require('/opt/node22/lib/node_modules/playwright');const {spawn}=require('child_process');const fs=require('fs');
const src=fs.readFileSync((process.env.LUKSAPP||'../lu-ks-app')+'/App.js','utf8');
const BR=/export const BRIDGE = `([\s\S]*?)`;/.exec(src)[1].replace("${VERSION}","1.0.0").replace("${Platform.OS}","ios");
(async()=>{
const srv=spawn('python3',['-m','http.server','8813'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},locale:'es-CO',serviceWorkers:'block'});
await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept());
let pops=0;ctx.on('page',()=>pops++);
await p.addInitScript(()=>{localStorage.setItem('luks-lang','es');window.__msgs=[];window.ReactNativeWebView={postMessage:m=>window.__msgs.push(JSON.parse(m))}});
await p.addInitScript(BR);
const W=ms=>p.waitForTimeout(ms||400);let ok=0,bad=0;const CK=(n,c,i)=>{c?ok++:bad++;console.log(c?'  ✔':'  ✘',n,i===undefined?'':i)};
await p.goto('http://localhost:8813/');await W(3000);
CK('LUKS_APP definido',await p.evaluate(()=>!!window.LUKS_APP&&window.LUKS_APP.v==='1.0.0'));
// abrir pantalla de login si hace falta
let hasG=await p.evaluate(()=>!!document.querySelector('[data-au="google"]'));
if(!hasG){await p.evaluate(()=>{const x=[...document.querySelectorAll('button,a')].find(e=>/Entrar|Iniciar|Crear/i.test(e.textContent));x&&x.click()});await W(800);hasG=await p.evaluate(()=>!!document.querySelector('[data-au="google"]'))}
CK('botón Google existe',hasG);
if(hasG){await p.click('[data-au="google"]');await W(800);const m=await p.evaluate(()=>window.__msgs.map(x=>x.t));CK('Google → aviso nativo',m.includes('google'),m.join());CK('no abre ventana emergente',pops===0,pops);
 CK('botón Google no queda bloqueado',await p.evaluate(()=>!document.querySelector('[data-au="google"]').disabled))}
// crear cuenta
await p.click('[data-au="up"]');await p.fill('#au-n','Jose');await p.fill('#au-e','jose@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(2500);
for(let i=0;i<8;i++){await p.evaluate(()=>{const s=document.querySelector('[data-ob="skip"]');if(s)s.click()});await W(250)}
CK('entró a la app',await p.evaluate(()=>!!document.querySelector('#add')));
// descarga blob con a.click()
await p.evaluate(()=>{window.__msgs=[];const a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['{"hola":1}'],{type:'application/json'}));a.download='respaldo.json';document.body.appendChild(a);a.click()});await W(600);
let f=await p.evaluate(()=>window.__msgs.find(x=>x.t==='file'));CK('descarga blob → archivo a la app',f&&f.name==='respaldo.json'&&Buffer?true:!!f,f&&f.name);
CK('contenido correcto',f&&Buffer.from(f.data,'base64').toString()==='{"hola":1}');CK('tipo json',f&&f.mime==='application/json',f&&f.mime);
// descarga con data: y toque real
await p.evaluate(()=>{window.__msgs=[];const a=document.createElement('a');a.href='data:text/plain;base64,'+btoa('abc');a.download='x.txt';a.id='dl';a.textContent='dl';a.style.cssText='position:fixed;top:120px;left:20px;z-index:99999';document.body.appendChild(a)});await p.click('#dl');await W(600);
f=await p.evaluate(()=>window.__msgs.find(x=>x.t==='file'));CK('toque en enlace data: → archivo',f&&Buffer.from(f.data,'base64').toString()==='abc');
// respaldo real de la app (si existe la función)
await p.evaluate(()=>{window.__msgs=[]});const exp=await p.evaluate(()=>{const b=[...document.querySelectorAll('button,[data-a],div')].find(e=>/Exportar|Descargar respaldo|Copia de seguridad/i.test(e.textContent)&&e.children.length<4);return b?b.textContent.trim().slice(0,40):null});console.log('   (botón respaldo:',exp,')');
// enlace normal no se intercepta
CK('enlace sin download no se intercepta',await p.evaluate(()=>{window.__msgs=[];const a=document.createElement('a');a.href='#zz';document.body.appendChild(a);a.click();return location.hash==='#zz'&&window.__msgs.length===0}));
// atrás de Android
await p.evaluate(()=>{location.hash=''});await p.click('#add');await W(700);
CK('se abrió una ventana',await p.evaluate(()=>document.querySelectorAll('.sheet.on').length>0));
CK('__lkBack la cierra',await p.evaluate(()=>window.__lkBack()===true&&document.querySelectorAll('.sheet.on').length===0));
CK('__lkBack sin ventanas → false',await p.evaluate(()=>window.__lkBack()===false));
CK('sin errores de página',errs.length===0,errs.slice(0,3).join(' | '));
console.log(ok+' bien, '+bad+' mal');await b.close();srv.kill();process.exit(bad?1:0)})();
