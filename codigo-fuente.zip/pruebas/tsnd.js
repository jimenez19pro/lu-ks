const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8809'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch({args:['--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream','--autoplay-policy=user-gesture-required']});
const ctx=await b.newContext({viewport:{width:390,height:844},locale:'es-CO',serviceWorkers:'block',permissions:['camera']});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const FAKE='window.__cur=null;globalThis.BarcodeDetector=class{async detect(c){await new Promise(r=>setTimeout(r,15));return window.__cur?[{rawValue:window.__cur}]:[]}}';await ctx.route(/barcode-detector/,r=>r.fulfill({body:FAKE,contentType:'application/javascript'}));
await ctx.addInitScript(()=>{window.__snd=[];const A=window.AudioContext;window.AudioContext=function(){const c=new A();window.__ctx=c;const co=c.createOscillator.bind(c);c.createOscillator=function(){const o=co();const st=o.start.bind(o);o.start=function(t){setTimeout(()=>window.__snd.push({f:Math.round(o.frequency.value),state:c.state}),40);return st(t)};return o};return c};try{localStorage.setItem('luks-lang','es')}catch(e){}});
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));const W=ms=>p.waitForTimeout(ms||300);
const S=async()=>p.evaluate(()=>{const r=window.__snd.length+' sonidos'+(window.__snd.length?' · último '+window.__snd[window.__snd.length-1].f+' Hz · audio '+(window.__ctx&&window.__ctx.state):'');window.__snd=[];return r});
// TIENDA
await p.goto('http://localhost:8809/tienda/');await W(1500);await p.click('[data-am="up"]');await p.fill('#au-e','s@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500);
await p.evaluate(()=>{const u=firebase.auth().currentUser.uid;const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()});await W(1200);
await p.click('[data-tab="inv"]');await p.click('[data-a="nuevoProd"]');await p.fill('#p-n','Gaseosa');await p.fill('#p-pv','3000');await p.fill('#p-st','20');await p.fill('#p-cod','111111111111');await p.click('[data-a="guardarProd"]');await W(300);await S();
await p.click('[data-tab="caja"]');await p.click('[data-a="ventaCam"]');await W(1500);await p.evaluate(()=>{window.__cur='111111111111'});await W(1200);console.log('TIENDA bip al escanear con cámara:',await S());
await p.evaluate(()=>{window.__cur=null});await p.click('#scan-done');await W(400);
await p.evaluate(()=>document.activeElement.blur());await p.keyboard.type('111111111111',{delay:8});await p.keyboard.press('Enter');await W(400);console.log('TIENDA bip con lectora Bluetooth:',await S());
// LU-KS
await p.evaluate(()=>firebase.auth().signOut());await W(500);await p.goto('http://localhost:8809/');await W(2500);await p.click('[data-au="up"]');await p.fill('#au-n','Jose');await p.fill('#au-e','s2@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(2500);
for(let i=0;i<8;i++){await p.evaluate(()=>{const s=document.querySelector('[data-ob="skip"]');if(s)s.click()});await W(250)}await S();
await p.click('#add');await W(500);await p.fill('#f-amt','25000');await p.click('#save');await W(800);console.log('LU-KS guardar gasto:',await S());
await p.click('[data-t="con"]');await W(1000);const pr=await p.$('[data-lk="sndt"]');if(pr){await pr.click();await W(1500);console.log('LU-KS botón Probar:',await S())}else console.log('sin botón probar');
await p.click('[data-lk="snd"][data-lkv="no"]');await W(500);await S();await p.click('[data-t="home"]');await W(500);await p.click('#add');await W(500);await p.fill('#f-amt','12000');await p.click('#save');await W(800);console.log('LU-KS con sonidos en NO:',await S());
await p.click('[data-t="con"]');await W(800);await p.click('[data-lk="snd"][data-lkv="si"]');await W(400);await S();
// volver de segundo plano
await p.evaluate(()=>window.__ctx&&window.__ctx.suspend());await W(200);await p.evaluate(()=>{Object.defineProperty(document,'hidden',{configurable:true,get:()=>false});document.dispatchEvent(new Event('visibilitychange'))});await W(500);console.log('LU-KS audio tras volver a la app:',await p.evaluate(()=>window.__ctx&&window.__ctx.state));
console.log('errs',errs);await b.close();srv.kill()})();
