const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8797'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},colorScheme:'dark',locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept());const W=ms=>p.waitForTimeout(ms||300);
await p.goto('http://localhost:8797/');await W(3000);await p.click('[data-au="up"] >> nth=0');await p.fill('#au-n','Jose');await p.fill('#au-e','j@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(2000);await p.click('[data-ob="skip"]');await W(800);
const keys=await p.evaluate(()=>Object.keys(JSON.parse(localStorage.mockdb)).filter(k=>k.includes('/tabs/')));console.log(keys.join(' '));
await p.evaluate(()=>{const d=JSON.parse(localStorage.mockdb);const k=t=>Object.keys(d).find(x=>x.includes('/tabs/'+t+'__'));const set=(t,rows)=>{const key=k(t);const cur=JSON.parse(d[key].rows);d[key].rows=JSON.stringify([cur[0]].concat(rows))};
set('Cuentas',[["Billetera","Efectivo",2900,"","","","","","","","",""],["Nequi","Débito",126000,"","Nequi","","","","","","",""]]);
const f='2026-10-18 10:00';set('Gastos',[[f,60000,"Internet","Efectivo","COP","manual","gasto","","Servicios",""],[f,70000,"Agua","Efectivo","COP","manual","gasto","","Servicios",""],[f,170000,"Energia","Efectivo","COP","manual","gasto","","Servicios",""],[f,20000,"Almuerzo","Nequi","COP","manual","gasto","","Comida",""]]);
set('Recurrentes',[["Internet",60000,5,"Servicios","Efectivo"]]);localStorage.mockdb=JSON.stringify(d)});
await p.reload();await W(3500);
const st=()=>p.evaluate(()=>({acc:ACC.map(a=>a.n+':'+a.ini+':'+(a.tipo==='credito'?(a.ini-bal(a.n)):(+a.ini+bal(a.n)))),tx:tx.map(t=>t.mer+'@'+t.acc),rec:REC.map(r=>r.n+'@'+r.acc),all:allAcc(),orf:huerf().map(x=>x.n+':'+x.c+':'+x.b)}));
console.log('ANTES',JSON.stringify(await st()));
await p.evaluate(()=>{tab='home';render();scrollTo(0,0)});await W(400);await p.screenshot({path:'acc1.png'});
console.log('aviso home:',await p.evaluate(()=>{const b=document.querySelector('[data-orf]');return b&&b.closest('div[style]').innerText.replace(/\n/g,' ')}));
await p.click('[data-orf]');await W(300);await p.screenshot({path:'acc2.png'});await p.click('#orf-go');await W(1500);
console.log('DESPUES',JSON.stringify(await st()));
// montos
await p.evaluate(()=>{tab='con';SUB='manage';render()});await W(300);await p.screenshot({path:'acc3.png'});
const hasB=await p.$('[data-bud]');console.log('bud row',!!hasB);
await p.evaluate(()=>{const k=Object.keys(CATS).find(c=>c==='comida')||Object.keys(CATS)[0];BK=k;$("#bt").textContent="Presupuesto";$("#b-amt").value=BUD[k]||"";$("#bsheet").classList.add("on")});await W(300);
await p.fill('#b-amt','');await p.type('#b-amt','1250000');console.log('b-amt shows',await p.inputValue('#b-amt'));await p.screenshot({path:'acc4.png'});
await p.evaluate(()=>saveBud());await W(500);console.log('BUD saved',await p.evaluate(()=>BUD[BK]));
await p.evaluate(()=>{$("#b-amt").value="600000";$("#bsheet").classList.add("on")});await W(150);await p.click('#b-amt');await W(200);console.log('preset shows',await p.inputValue('#b-amt'));
console.log('errs',errs);await b.close();srv.kill()})();
