const {chromium}=require('playwright');const {spawn}=require('child_process');(async()=>{
const srv=spawn('python3',['-m','http.server','8765'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({serviceWorkers:'block',viewport:{width:390,height:844},colorScheme:'dark'});const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:require('fs').readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
await p.goto('http://localhost:8765/');await p.waitForTimeout(3000);await p.screenshot({path:'p1.png'});
await p.click('[data-au="up"]');await p.fill('#au-n','Ana');await p.fill('#au-e','ana@x.com');await p.fill('#au-p','123');await p.click('#au-go');await p.waitForTimeout(200);await p.waitForTimeout(1500);await p.evaluate(()=>{const s=document.querySelector('[data-ob="skip"]');if(s)s.click()});await p.waitForTimeout(500);console.log('weak msg:',await p.textContent('#au-msg'));
await p.fill('#au-p','secreto1');await p.click('#au-go');await p.waitForTimeout(800);await p.waitForTimeout(1500);await p.evaluate(()=>{const s=document.querySelector('[data-ob="skip"]');if(s)s.click()});await p.waitForTimeout(500);console.log('auth hidden',await p.evaluate(()=>document.getElementById('auth').style.display));
await p.screenshot({path:'p2.png'});console.log('greet',await p.evaluate(()=>document.querySelector('[data-lk="hola"]')&&document.querySelector('[data-lk="hola"]').textContent),'cats',await p.evaluate(()=>Object.keys(CATS).length),'bud',await p.evaluate(()=>budTot()));
// add expense via form
await p.evaluate(()=>{TP='out';addRow(25000,'Almuerzo','Efectivo','comida','')});await p.waitForTimeout(600);console.log('tx',await p.evaluate(()=>tx.length+' '+tx.map(t=>t.mer+':'+t.amt+':'+t.id).join()));
await p.evaluate(()=>{TP='in';addRow(1000000,'Sueldo','Efectivo','','')});await p.waitForTimeout(600);
// edit & delete
await p.evaluate(()=>{const t=tx.find(x=>x.mer==='Almuerzo');CUR=t;TP='out';updateRow(t,30000,'Almuerzo','Efectivo','comida','')});await p.waitForTimeout(800);console.log('after edit',await p.evaluate(()=>tx.map(t=>t.mer+':'+t.amt).join()));
await p.evaluate(()=>{CUR=tx.find(x=>x.mer==='Almuerzo');DELQ=true;delRow()});await p.waitForTimeout(800);console.log('after del',await p.evaluate(()=>tx.map(t=>t.mer+':'+t.amt+':'+t.id).join()));
// goal save
await p.evaluate(()=>{openGoal(-1)});await p.fill('#g-n','Viaje');await p.fill('#g-t','500000');await p.click('#gsave');await p.waitForTimeout(600);
// reload persists
console.log('db before reload',await p.evaluate(()=>Object.keys(JSON.parse(localStorage.getItem('mockdb')||'{}')).join())); await p.reload();await p.waitForTimeout(3200);console.log('T',await p.evaluate(()=>Object.keys(LKPUBT).map(k=>k+':'+LKPUBT[k].length).join()), await p.evaluate(()=>st.s));console.log('after reload',await p.evaluate(()=>tx.map(t=>t.mer).join()+' goals:'+GOALS.map(g=>g.n).join()+' auth:'+(document.getElementById('auth')?document.getElementById('auth').style.display:'none')));
await p.evaluate(()=>{tab='con';render()});await p.evaluate(()=>scrollTo(0,9999));await p.screenshot({path:'p3.png'});
// logout, second user isolation
await p.click('[data-pub="out"]');await p.click('[data-pub="out"]');await p.waitForTimeout(3300);await p.click('[data-au="up"]');await p.fill('#au-n','Beto');await p.fill('#au-e','beto@x.com');await p.fill('#au-p','secreto2');await p.click('#au-go');await p.waitForTimeout(900);await p.waitForTimeout(1500);await p.evaluate(()=>{const s=document.querySelector('[data-ob="skip"]');if(s)s.click()});await p.waitForTimeout(500);
console.log('beto sees',await p.evaluate(()=>tx.length+' goals '+GOALS.length+' name '+document.querySelector('[data-lk="hola"]').textContent));
// delete account
await p.evaluate(()=>{tab='con';render()});await p.click('[data-pub="del"]');await p.fill('#pub-pw','mala');await p.click('[data-pub="delgo"]');await p.waitForTimeout(300);console.log('bad pw',await p.textContent('#pub-msg'));
p.on('dialog',d=>d.accept());await p.fill('#pub-pw','secreto2');await p.click('[data-pub="delgo"]');await p.waitForTimeout(3500);console.log('db keys left',await p.evaluate(()=>Object.keys(JSON.parse(localStorage.getItem('mockdb')||'{}')).map(k=>k.split('/')[1]).filter((v,i,a)=>a.indexOf(v)===i).length),'auth shown',await p.evaluate(()=>document.getElementById('auth')&&document.getElementById('auth').style.display));
console.log('errs',errs);await b.close();srv.kill()})();
