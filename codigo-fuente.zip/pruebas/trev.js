const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8806'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},deviceScaleFactor:2,locale:'es-CO',serviceWorkers:'block',colorScheme:process.argv[2]||'dark'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));await ctx.route(/wa\.me/,r=>r.fulfill({body:'wa'}));
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept());const W=ms=>p.waitForTimeout(ms||300);const D='/tmp/claude-0/-home-claude/386cd89e-f2f2-549f-a9dc-a0da83d3d90b/scratchpad/rev/';fs.mkdirSync(D,{recursive:true});
let n=0;const S=async name=>{await W(350);n++;await p.screenshot({path:D+String(n).padStart(2,'0')+'-'+name+'.png'})};
const SS=async name=>{await W(350);n++;const h=await p.evaluate(()=>{const s=document.querySelector('#sh');return s.classList.contains('on')?s.scrollHeight:0});await p.screenshot({path:D+String(n).padStart(2,'0')+'-'+name+'.png'});if(h>800){await p.evaluate(()=>{document.querySelector('#sh').scrollTop=99999});await W(200);await p.screenshot({path:D+String(n).padStart(2,'0')+'-'+name+'-b.png'});await p.evaluate(()=>{document.querySelector('#sh').scrollTop=0})}};
const X=async()=>{await p.click('#ov',{position:{x:20,y:20}}).catch(()=>{});await W(350)};
await p.goto('http://localhost:8806/tienda/');await W(3000);await p.click('[data-am="up"]');await p.fill('#au-e','luis@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500);
const uid=await p.evaluate(()=>firebase.auth().currentUser.uid);
await p.evaluate(u=>{const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});
const P=[['Aceite clarita 220ml',3200,2600],['Arroz Diana 500 g',2600,2200],['Azúcar Manuelita 1 kg',4500,3900],['Gaseosa Coca-Cola 400 ml',3000,2200],['Leche Alquería 1 L',4800,4100],['Huevos AA x 30',16500,14000],['Pan tajado Bimbo',6500,5200],['Papas Margarita limón 25 g',2000,1500],['Chocoramo',2500,1900],['Jabón Rey',2800,2200],['Café Sello Rojo 250 g',9800,8300],['Panela',3000,2400],['Atún Van Camps',6900,5800],['Galletas Festival',1800,1300],['Detergente Fab 500 g',5600,4700],['Papel higiénico Familia x4',8900,7600],['Cerveza Águila lata',3500,2700],['Agua Cristal 600 ml',1800,1200],['Pony Malta 330',2500,1900],['Salchichas Zenú x 10',9500,8100]];
const PV=[['Coca cola','3001112233'],['Deditos','3002223344'],['Alpina','3003334455']];PV.forEach((v,i)=>b.set({path:'users/'+u+'/t_prov/pv'+i},{n:v[0],tel:v[1],dia:''}));
for(let i=0;i<62;i++){const q=P[i%P.length];b.set({path:'users/'+u+'/t_prod/p'+i},{n:i<P.length?q[0]:q[0]+' '+(Math.floor(i/P.length)+1),pv:q[1],pc:q[2],st:i%7===0?2:10+i%15,min:i%7===0?5:0,cod:String(7700000000000+i),u:'und',prov:'pv'+(i%3),ts:Date.now()-i*1000})}
const C=['Doña Marta','Don Jorge','Carlos Pérez','La vecina del 5','Andrea'];C.forEach((c,i)=>{b.set({path:'users/'+u+'/t_cli/c'+i},{n:c,tel:'30012345'+i+i,cupo:0});b.set({path:'users/'+u+'/t_fmov/f'+i},{cli:'c'+i,tipo:'cargo',monto:5000*(i+1),fecha:'2026-10-0'+(i+1),metodo:'fi',nota:'Compra',ts:Date.now()-86400000*(20-i)})});
b.set({path:'users/'+u+'/t_conf/conf'},{tienda:'Tienda de Luis',base:50000,margen:20,waDueno:'3137904093'});return b.commit()},uid);await p.reload();await W(3000);
// ventas de hoy
for(const k of [0,3,5]){await p.click('[data-a="venta"] >> nth=0');await W();await p.click('.pb >> nth='+k);await p.click('[data-a="guardarVenta"]');await W(300)}
await p.click('[data-a="gasto"] >> nth=0');await W();await p.fill('#g-m','12000');await p.fill('#g-n','Bolsas');await p.click('[data-a="guardarGasto"]');await W(500);
await p.click('[data-tab="caja"]');await S('caja');await p.evaluate(()=>window.scrollTo(0,9999));await S('caja-b');await p.evaluate(()=>window.scrollTo(0,0));
await p.click('[data-a="venta"] >> nth=0');await SS('venta');await p.click('.pb >> nth=1');await p.click('.pb >> nth=2');await SS('venta-carrito');
await p.evaluate(()=>{const b=[...document.querySelectorAll('#sh button')].find(x=>/Monto r/.test(x.innerText));b&&b.click()});await SS('venta-rapido');await X();
await p.click('[data-a="fiar"]');await W();await p.click('.pb >> nth=0');await p.evaluate(()=>{document.querySelector('#sh').scrollTop=99999});await p.click('#v-cli-s');await SS('fiar-buscador');await X();
await p.click('[data-a="gasto"] >> nth=0');await W();await p.click('[data-gcat="merc"]');await SS('gasto');await X();
await p.click('[data-a="cierre"]');await SS('cierre');await X();
await p.click('[data-tab="fiados"]');await S('fiados');await p.click('[data-a="abono"] >> nth=0');await p.click('#a-cli-s');await SS('abono');await X();
await p.click('#main .row >> nth=0').catch(()=>{});await SS('cliente');await X();
await p.click('[data-a="cobrar"]').catch(()=>{});await SS('cobrar');await X();
await p.click('[data-tab="inv"]');await S('inv');await p.evaluate(()=>window.scrollTo(0,9999));await S('inv-b');await p.evaluate(()=>window.scrollTo(0,0));
await p.click('[data-a="nuevoProd"]');await SS('nuevo-prod');await X();
await p.click('[data-a="entrada"]');await SS('entrada');await X();
await p.click('[data-a="pedido"]:not([data-id])').catch(()=>{});await SS('pedido');await X();
await p.click('[data-a="factura"]').catch(()=>{});await SS('factura-sin-clave');await X();
await p.click('[data-tab="gastos"]');await S('gastos');await p.click('[data-gv="prov"]');await S('proveedores');
await p.click('#main .row >> nth=0').catch(()=>{});await SS('proveedor');await X();
await p.click('[data-a="pmov"][data-t="compra"] >> nth=0');await SS('compra-credito');await X();
await p.click('[data-tab="rep"]');await S('reportes');await p.evaluate(()=>window.scrollTo(0,9999));await S('reportes-b');await p.evaluate(()=>window.scrollTo(0,0));
await p.click('[data-a="ajustes"] >> nth=0');await SS('ajustes');await X();
console.log('shots',n,'errs',errs);await b.close();srv.kill();})();
