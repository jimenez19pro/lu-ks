const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8792'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},colorScheme:process.argv[2]||'light',locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
let MODE='ok',REQ=null;const CALLS=[];let N503=0;const INV={proveedor:'Distribuidora El Sol S.A.S',numero:'FV-1234',fecha:'2026-10-19',total:165200,items:[
{nombre:'GASEOSA COLOMBIANA 400ML PET X12',codigo:null,cantidad:2,presentacion:'Paca x 12',unidades:24,costo_unidad:2200,total_linea:52800,id:null},
{nombre:'ARROZ DIANA X 500 GR',codigo:'7702511000014',cantidad:1,presentacion:'Paca x 25',unidades:25,costo_unidad:2600,total_linea:65000,id:null},
{nombre:'ACEITE GIRASOL 900 ML',codigo:null,cantidad:6,presentacion:'Unidad',unidades:6,costo_unidad:'7.900',total_linea:47400,id:null}]};
await ctx.route(/generativelanguage/,r=>{REQ=JSON.parse(r.request().postData());const model=r.request().url().split('/models/')[1].split(':')[0];CALLS.push(model+':'+MODE);if(MODE==='503all'||(MODE==='503x2'&&CALLS.length<=2))return r.fulfill({contentType:'application/json',body:JSON.stringify({error:{code:503,message:'The model is overloaded. Please try again later.',status:'UNAVAILABLE'}})});if(MODE==='429')return r.fulfill({contentType:'application/json',body:JSON.stringify({error:{code:429,message:'quota'}})});r.fulfill({contentType:'application/json',body:JSON.stringify({candidates:[{content:{parts:[{text:'```json\n'+JSON.stringify(INV)+'\n```'}]}}]})})});
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept());
const W=ms=>p.waitForTimeout(ms||300);const S=async n=>{await W(250);await p.screenshot({path:'fx'+n+'.png'})};const SF=async n=>{await W(250);await p.locator('#sh').screenshot({path:'fx'+n+'.png'})};
await p.goto('http://localhost:8792/tienda/');await W(1500);
await p.click('[data-am="up"]');await p.fill('#au-e','t@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500);
const uid=await p.evaluate(()=>firebase.auth().currentUser.uid);
await p.evaluate(u=>{const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()},uid);await W(1200);
await p.click('[data-a="ajustes"] >> nth=0');await p.fill('#s-t','Tienda Don Pacho');await p.click('[data-a="guardarAj"]');await W();
await p.click('[data-tab="inv"]');for(const [n,pv,pc,st] of [['Gaseosa Colombiana 400 ml','3000','2000','5'],['Arroz Diana 500 g','3200','2600','10'],['Arroz Roa 1000 g','5200','4300','4']]){await p.click('[data-a="nuevoProd"]');await p.fill('#p-n',n);await p.fill('#p-pv',pv);await p.fill('#p-pc',pc);await p.fill('#p-st',st);await p.click('[data-a="guardarProd"]');await W(200)}
await p.evaluate(u=>{const b=firebase.firestore().batch();b.set({path:'users/'+u+'/tabs/Ajustes__0'},{t:'Ajustes',i:0,rows:JSON.stringify([['Clave','Valor'],['gemini','AIzaSyTEST_1234567890abcdefgh']])});return b.commit()},uid);
await p.reload();await W(3500);await p.click('[data-tab="inv"]');await W();
// a) 503 dos veces y luego ok
MODE='503x2';CALLS.length=0;await p.click('[data-a="factura"]');await W(800);await p.setInputFiles('#fx-f','qr-test.png');await W(1200);console.log('a) estado intermedio:',await p.textContent('#fx-st').catch(()=>'-'));await W(6000);
console.log('a) llamadas:',CALLS.join(' | '),'| revisión abierta:',await p.evaluate(()=>!!document.querySelector('.fxl')));
await p.click('[data-a="fxCancelar"]');await W(500);
// b) siempre 503
MODE='503all';CALLS.length=0;await p.click('[data-a="factura"]');await W(800);await p.setInputFiles('#fx-f','qr-test.png');await W(25000);
console.log('b) llamadas:',CALLS.length,CALLS.map(c=>c.split(':')[0]).filter((v,i,a)=>a.indexOf(v)===i).join(','),'| mensaje:',await p.textContent('#fx-st'),'| botón reintentar:',!!(await p.$('[data-a="fxRetry"]')));
// c) reintentar ya funciona
MODE='ok';CALLS.length=0;await p.click('[data-a="fxRetry"]');await W(2500);console.log('c) revisión abierta:',await p.evaluate(()=>!!document.querySelector('.fxl')),'| llamadas:',CALLS.length);
console.log('errs',errs);await b.close();srv.kill();})();
