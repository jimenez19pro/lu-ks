const {chromium}=require('playwright');const {spawn}=require('child_process');(async()=>{
const dir=process.argv[2]||'.';const scheme=process.argv[3]||'dark';
const srv=spawn('python3',['-m','http.server','8766'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({serviceWorkers:'block',viewport:{width:390,height:844},deviceScaleFactor:2,colorScheme:scheme,locale:'es-CO'});const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:require('fs').readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const W=ms=>p.waitForTimeout(ms||400);const S=async n=>{await W(500);await p.screenshot({path:dir+'/'+n+'.png'})};
await p.goto('http://localhost:8766/');await W(2500);await S('00-inicio');
await p.click('[data-au="up"]');await p.fill('#au-n','Jose');await p.fill('#au-e','jose@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(2500);await S('01-tras-registro');
for(let i=0;i<8;i++){const s=await p.$('[data-ob="skip"],[data-ob="next"]');if(!s)break;await p.evaluate(()=>{const s=document.querySelector('[data-ob="skip"]');if(s)s.click()});await W(400)}
await p.evaluate(()=>{const add=[[0,38900,'Mercado D1','comida'],[0,12000,'Taxi','transp'],[1,89000,'Internet','serv'],[2,45000,'Cine','ocio'],[3,850000,'Arriendo','hogar'],[4,26500,'Almuerzo','comida'],[5,60000,'Farmacia','salud'],[8,120000,'Ropa','ropa']];TP='out';add.forEach(a=>{try{addRow(a[1],a[2],'Efectivo',a[3],'')}catch(e){}});TP='in';try{addRow(2500000,'Sueldo','Efectivo','','')}catch(e){}});await W(1500);
await p.evaluate(()=>window.scrollTo(0,0));await S('02-home');
await p.evaluate(()=>window.scrollTo(0,900));await S('03-home-abajo');await p.evaluate(()=>window.scrollTo(0,1800));await S('04-home-abajo2');
for(const t of ['tx','rep','con']){await p.evaluate(()=>window.scrollTo(0,0));await p.click('[data-t="'+t+'"]');await W(800);await S('05-'+t);await p.evaluate(()=>window.scrollTo(0,900));await S('06-'+t+'-abajo')}
await p.click('[data-t="home"]');await W();await p.click('.fab');await W(800);await S('07-agregar');
console.log('errs',errs);await b.close();srv.kill();})();
