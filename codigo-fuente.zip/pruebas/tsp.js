const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8770'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({serviceWorkers:'block',viewport:{width:390,height:844}});
await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('http://localhost:8770/');await p.waitForTimeout(300);
const st=()=>p.evaluate(()=>({splash:!!document.getElementById('splash'),nav:getComputedStyle(document.querySelector('nav')).visibility,app:getComputedStyle(document.getElementById('app')).visibility}));
console.log('durante splash:',JSON.stringify(await st()));await p.waitForTimeout(3500);console.log('después:',JSON.stringify(await st()));console.log('errs',errs);await b.close();srv.kill()})();
