const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8769'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({serviceWorkers:'block',viewport:{width:390,height:844},hasTouch:true,isMobile:true,colorScheme:'dark',deviceScaleFactor:2});
await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));await p.addInitScript(()=>{localStorage.setItem('luks-lang','es')});
await p.goto('http://localhost:8769/');await p.waitForTimeout(2500);await p.click('[data-au="up"]');await p.fill('#au-n','Jose');await p.fill('#au-e','k@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await p.waitForTimeout(2500);
for(let i=0;i<8;i++){await p.evaluate(()=>{const s=document.querySelector('[data-ob="skip"]');if(s)s.click()});await p.waitForTimeout(250)}
await p.evaluate(()=>{TP='out';for(let i=0;i<6;i++)addRow(10000+i,'Gasto '+i,'Efectivo','comida','')});await p.waitForTimeout(800);
await p.click('#add');await p.waitForTimeout(400);
console.log('noanim:',await p.evaluate(()=>document.getElementById('sheet').classList.contains('noanim')));
// simular teclado: el área visible queda de 470px y desplazada 120px
await p.evaluate(()=>{const v=window.visualViewport;Object.defineProperty(v,'height',{get:()=>470,configurable:true});Object.defineProperty(v,'offsetTop',{get:()=>0,configurable:true});v.dispatchEvent(new Event('resize'))});await p.waitForTimeout(300);
const r=await p.evaluate(()=>{const s=document.getElementById('sheet'),d=s.firstElementChild.getBoundingClientRect(),a=document.getElementById('f-amt').getBoundingClientRect();return{kb:s.classList.contains('kb'),sheetH:s.getBoundingClientRect().height,panelTop:Math.round(d.top),panelBottom:Math.round(d.bottom),amtTop:Math.round(a.top)}});console.log('teclado abierto:',JSON.stringify(r));
await p.screenshot({path:'kb.png',clip:{x:0,y:0,width:390,height:470}});
await p.evaluate(()=>{const v=window.visualViewport;Object.defineProperty(v,'height',{get:()=>844,configurable:true});v.dispatchEvent(new Event('resize'))});await p.waitForTimeout(200);
console.log('teclado cerrado kb:',await p.evaluate(()=>document.getElementById('sheet').classList.contains('kb')));
await p.click('#cancel');await p.waitForTimeout(300);await p.click('body',{position:{x:200,y:300}});await p.waitForTimeout(200);console.log('noanim after close:',await p.evaluate(()=>document.getElementById('sheet').classList.contains('noanim')));
console.log('errs',errs);await b.close();srv.kill();})();
