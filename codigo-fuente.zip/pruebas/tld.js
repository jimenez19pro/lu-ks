const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8793'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},colorScheme:process.argv[2]||'light',locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
await ctx.route(/openfoodfacts/,r=>{const u=r.request().url();if(u.includes('7702090000001'))return r.fulfill({contentType:'application/json',headers:{'access-control-allow-origin':'*'},body:JSON.stringify({status:1,product:{product_name:'Gaseosa Manzana',brands:'Postobón,X',quantity:'400 ml'}})});r.fulfill({contentType:'application/json',headers:{'access-control-allow-origin':'*'},body:JSON.stringify({status:0})})});
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept());
const W=ms=>p.waitForTimeout(ms||300);const S=async n=>{await W(250);await p.screenshot({path:'ld'+n+'.png'})};
const SCAN=async c=>{await p.keyboard.type(c,{delay:8});await p.keyboard.press('Enter');await W(500)};
const sh=()=>p.evaluate(()=>{const s=document.querySelector('#sh');return s.classList.contains('on')?s.innerText.replace(/\n+/g,' | ').slice(0,260):'(cerrado)'});
await p.goto('http://localhost:8793/tienda/');await W(1500);
await p.click('[data-am="up"]');await p.fill('#au-e','t@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500);
await p.evaluate(()=>{const u=firebase.auth().currentUser.uid;const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()});await W(1200);
await p.click('[data-a="ajustes"] >> nth=0');await p.fill('#s-t','Tienda Don Pacho');await p.click('[data-a="guardarAj"]');await W();
// 1) cargar inventario
await p.click('[data-tab="inv"]');await W();await S(0);await p.click('[data-a="cargar"]');await W();await S(1);
await SCAN('7702090000001');await W(600);console.log('new prod name:',await p.inputValue('#p-n'),'| cod:',await p.inputValue('#p-cod'));
// scanning another while editor open must not overwrite
await SCAN('7702090000002');console.log('cod after 2nd scan:',await p.inputValue('#p-cod'));
await p.fill('#p-pv','3000');await p.fill('#p-pc','2100');await p.fill('#p-st','24');await S(2);await p.click('[data-a="guardarProd"]');await W(500);
console.log('after save:',await sh());
await SCAN('7702090000002');await W(500);console.log('2nd new name (none online):',JSON.stringify(await p.inputValue('#p-n')));await p.fill('#p-n','Papas Margarita Limón 25 g');await p.fill('#p-pv','2000');await p.fill('#p-st','10');await p.click('[data-a="guardarProd"]');await W(500);
await SCAN('7702090000001');console.log('existing:',await sh());await S(3);await p.fill('#ld-st','20');await p.click('[data-a="ldSt"]');await W();
// cancel path
await SCAN('7702090000003');await p.click('[data-a="npBack"]');await W();console.log('after cancel:',(await sh()).slice(0,60));
console.log('final:',await sh());await S(4);await p.click('[data-a="ldFin"]');await W();
// 2) vender: en caja sin ventana abierta
await p.click('[data-tab="caja"]');await W();
await SCAN('7702090000001');await SCAN('7702090000001');await SCAN('7702090000002');
console.log('venta tot:',await p.textContent('#v-tot'),'| cart:',await p.evaluate(()=>document.querySelector('.cart').innerText.replace(/\n/g,' ')));
// focus en "con cuanto paga" y escanear: no debe ensuciar el campo
await p.click('#v-paga');await p.keyboard.type('10000',{delay:150});await SCAN('7702090000001');
console.log('paga field:',await p.inputValue('#v-paga'),'| tot:',await p.textContent('#v-tot'));await S(5);
// búsqueda con foco y escaneo
await p.click('#v-q');await SCAN('7702090000002');console.log('q field:',JSON.stringify(await p.inputValue('#v-q')),'| tot:',await p.textContent('#v-tot'));
await p.click('[data-a="guardarVenta"]');await W(600);
console.log('stock:',await p.evaluate(()=>LKT.D.prod.map(x=>x.n+':'+x.st).join(', ')));
// 3) inventario: escaneo abre producto
await p.click('[data-tab="inv"]');await W();await SCAN('7702090000002');console.log('inv open:',(await sh()).slice(0,50));await p.click('#sh [data-a="cerrar"]');await W();
// 4) llegó mercancía
await p.click('[data-a="entrada"]');await W();await SCAN('7702090000002');console.log('entrada sel:',await p.evaluate(()=>document.querySelector('#e-s').value));await p.click('#sh [data-a="cerrar"]');await W();
// 5) humano escribiendo en buscador no dispara
await p.fill('[data-q]','');await p.click('[data-q]');await p.keyboard.type('papas',{delay:120});await p.keyboard.press('Enter');await W();console.log('human search:',await p.inputValue('[data-q]'),'| sheet:',(await sh()).slice(0,20));
console.log('errs',errs);await b.close();srv.kill();})();
