const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8779'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},colorScheme:'dark',locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const WA=[];await ctx.route(/wa\.me/,r=>{WA.push(decodeURIComponent(r.request().url()));r.fulfill({body:'wa',contentType:'text/html'})});
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));const W=ms=>p.waitForTimeout(ms||300);
const grant=async(h)=>p.evaluate(h=>{const u=firebase.auth().currentUser.uid;const b=firebase.firestore().batch();b.set({path:'licencias/'+u},h?{hasta:h}:{});return b.commit()},h);
// Lu-Ks
await p.goto('http://localhost:8779/');await W(3000);await p.click('[data-au="up"] >> nth=0');await p.fill('#au-n','Ana');await p.fill('#au-e','ana@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(2000);await p.click('[data-ob="skip"]');await W(800);
await p.evaluate(()=>{tab='con';render()});await W(500);console.log('row sin licencia:',await p.evaluate(()=>{const r=document.querySelector('[data-lic=info]');return r&&r.innerText.replace(/\n/g,' ')}));
await p.click('[data-lic="info"]');await W(300);await p.screenshot({path:'lic1.png'});await p.click('#xbody [data-lic="wa"]');await W(800);if(!p.url().endsWith('/'))await p.goBack();await W(2500);console.log('WA:',WA[WA.length-1].slice(0,130));
await grant('');await W(600);await p.evaluate(()=>{tab='con';render()});await W(300);console.log('row con licencia:',await p.evaluate(()=>{const r=document.querySelector('a.srow[href="tienda/"]');return r&&r.innerText.replace(/\n/g,' ')}));
// Tienda: misma cuenta con licencia -> entra
await p.goto('http://localhost:8779/tienda/');await W(1800);console.log('tienda con licencia:',JSON.stringify(await p.evaluate(()=>LKT.state().OWN!=null)));
// otra cuenta sin licencia
await p.evaluate(()=>firebase.auth().signOut());await W(800);await p.click('[data-am="up"]');await p.fill('#au-e','beto@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500);await p.screenshot({path:'lic2.png'});console.log('paywall:',(await p.textContent('#auth')).slice(0,60),'| code shown',!!(await p.$('#pay-c')));
await p.click('#pay-wa');await W(800);if(!p.url().includes('/tienda/'))await p.goBack();await W(1500);console.log('WA2:',WA[WA.length-1].slice(0,120));
await grant('');await W(800);console.log('auto-activa:',await p.evaluate(()=>!document.querySelector('#app').classList.contains('hide')&&LKT.state().OWN!=null));
await grant('2020-01-01');await W(800);await p.screenshot({path:'lic3.png'});console.log('vencida:',(await p.textContent('#auth')).slice(0,40));
console.log('errs',errs);await b.close();srv.kill()})();
