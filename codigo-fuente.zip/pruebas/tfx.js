const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8792'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},colorScheme:process.argv[2]||'light',locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
let MODE='ok',REQ=null;const INV={proveedor:'Distribuidora El Sol S.A.S',numero:'FV-1234',fecha:'2026-10-19',total:165200,items:[
{nombre:'GASEOSA COLOMBIANA 400ML PET X12',codigo:null,cantidad:2,presentacion:'Paca x 12',unidades:24,costo_unidad:2200,total_linea:52800,id:null},
{nombre:'ARROZ DIANA X 500 GR',codigo:'7702511000014',cantidad:1,presentacion:'Paca x 25',unidades:25,costo_unidad:2600,total_linea:65000,id:null},
{nombre:'ACEITE GIRASOL 900 ML',codigo:null,cantidad:6,presentacion:'Unidad',unidades:6,costo_unidad:'7.900',total_linea:47400,id:null}]};
await ctx.route(/generativelanguage/,r=>{REQ=JSON.parse(r.request().postData());if(MODE==='429')return r.fulfill({contentType:'application/json',body:JSON.stringify({error:{code:429,message:'quota'}})});r.fulfill({contentType:'application/json',body:JSON.stringify({candidates:[{content:{parts:[{text:'```json\n'+JSON.stringify(INV)+'\n```'}]}}]})})});
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept());
const W=ms=>p.waitForTimeout(ms||300);const S=async n=>{await W(250);await p.screenshot({path:'fx'+n+'.png'})};const SF=async n=>{await W(250);await p.locator('#sh').screenshot({path:'fx'+n+'.png'})};
await p.goto('http://localhost:8792/tienda/');await W(1500);
await p.click('[data-am="up"]');await p.fill('#au-e','t@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500);
const uid=await p.evaluate(()=>firebase.auth().currentUser.uid);
await p.evaluate(u=>{const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()},uid);await W(1200);
await p.click('[data-a="ajustes"] >> nth=0');await p.fill('#s-t','Tienda Don Pacho');await p.click('[data-a="guardarAj"]');await W();
await p.click('[data-tab="inv"]');for(const [n,pv,pc,st] of [['Gaseosa Colombiana 400 ml','3000','2000','5'],['Arroz Diana 500 g','3200','2600','10'],['Arroz Roa 1000 g','5200','4300','4']]){await p.click('[data-a="nuevoProd"]');await p.fill('#p-n',n);await p.fill('#p-pv',pv);await p.fill('#p-pc',pc);await p.fill('#p-st',st);await p.click('[data-a="guardarProd"]');await W(200)}
// 1) sin clave -> pantalla de configurar
await p.click('[data-a="factura"]');await W(800);console.log('setup:',await p.evaluate(()=>document.querySelector('#sh h1').innerText));await p.fill('#ia-k','abc');await p.click('[data-a="iaSave"]');console.log('bad key msg:',await p.textContent('#ia-m'));await p.click('#sh [data-a="cerrar"]');await W();
// 2) clave importada desde Lu-Ks personal
await p.evaluate(u=>{const b=firebase.firestore().batch();b.set({path:'users/'+u+'/tabs/Ajustes__0'},{t:'Ajustes',i:0,rows:JSON.stringify([['Clave','Valor'],['tema','azul'],['gemini','AIzaSyTEST_1234567890abcdefgh']])});return b.commit()},uid);
await p.reload();await W(2500);await p.click('[data-tab="inv"]');await W();
await p.click('[data-a="factura"]');await W(800);console.log('photo sheet:',await p.evaluate(()=>document.querySelector('#sh h1').innerText));await SF(1);
// 429 first
MODE='429';await p.setInputFiles('#fx-f','qr-test.png');await W(1500);console.log('429 msg:',await p.textContent('#fx-st'));
MODE='ok';await p.setInputFiles('#fx-f','qr-test.png');await W(1500);
console.log('req key ok:',!!REQ,'img parts',REQ.contents[0].parts.filter(x=>x.inline_data).length,'prompt has products',REQ.contents[0].parts[0].text.includes('Arroz Roa'));
console.log('ia doc saved:',await p.evaluate(()=>JSON.stringify(LKT.D.conf.filter(x=>x.id==='ia')[0])));
console.log('SHEET',await p.evaluate(()=>document.querySelector('#sh').innerText.slice(0,300)),errs);const rev=await p.evaluate(()=>[...document.querySelectorAll('.fxl')].map(w=>{const s=w.querySelector('[data-fxp]');return s.options[s.selectedIndex].text+' | q='+(w.querySelector('[data-fxq]')||{}).value+' c='+(w.querySelector('[data-fxc]')||{}).value+' v='+((w.querySelector('[data-fxv]')||{}).value||'')+' | '+w.querySelector('.fxh').innerText.replace(/\n/g,' ')}));console.log(rev.join('\n'));
console.log('prov sel:',await p.evaluate(()=>{const s=document.querySelector('#fx-p');return s.options[s.selectedIndex].text}),'| dif:',await p.textContent('#fx-d'));
await SF(2);await p.evaluate(()=>document.querySelector('#sh').scrollTop=99999);await SF(3);
// edit qty live
await p.fill('.fxl >> nth=0 >> [data-fxq]','23');await W();console.log('after edit dif:',await p.textContent('#fx-d'));await p.fill('.fxl >> nth=0 >> [data-fxq]','24');await W();
// change payment to credit
await p.click('[data-fxm="cr"]');await W();
await p.click('[data-a="fxGuardar"]');await W(700);await SF(4);
console.log('done:',await p.evaluate(()=>document.querySelector('#sh').innerText.replace(/\n/g,' | ')));
const st=await p.evaluate(()=>({prod:LKT.D.prod.map(x=>x.n+':'+x.st+' pc'+x.pc+' pv'+x.pv+' cod'+(x.cod||'')+' prov'+(x.prov?'Y':'N')+' fa'+JSON.stringify(x.fa||[])),prov:LKT.D.prov.map(x=>x.n),pmov:LKT.D.pmov.map(x=>x.tipo+':'+x.monto+':'+x.nota),gasto:LKT.D.gasto.length}));console.log(JSON.stringify(st,null,1));
await p.click('[data-a="fxSube"]');await W();console.log('sube sheet:',await p.evaluate(()=>document.querySelector('#sh h1').innerText));await p.click('#ov',{position:{x:20,y:20}});await W(500);
// 3) misma factura otra vez -> alias match, pago de la caja
await p.click('[data-a="factura"]');await W(500);await p.setInputFiles('#fx-f','qr-test.png');await W(1500);
console.log('aviso duplicada:',await p.evaluate(()=>{const c=[...document.querySelectorAll('#sh .card')].find(x=>/ya la sumaste/.test(x.innerText));return c?c.innerText.replace(/\n/g,' '):'NO'}));await p.screenshot({path:'dup.png'});console.log('2nd:',await p.evaluate(()=>[...document.querySelectorAll('.fxl [data-fxp]')].map(s=>s.options[s.selectedIndex].text).join(' / ')),'| prov:',await p.evaluate(()=>{const s=document.querySelector('#fx-p');return s.options[s.selectedIndex].text}));
await p.click('[data-a="fxGuardar"]');await W(600);await p.click('#sh [data-a="cerrar"]');await W();
await p.click('[data-tab="caja"]');await W();console.log('caja:',await p.evaluate(()=>{const d=new Date(),f=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');const e=LKT.esperado(f);return 'esperado '+e.total+' gastos ef '+e.r.gEf}));
// historial de facturas
await p.click('[data-tab="inv"]');await W();await p.click('[data-a="factura"]');await W(800);await p.click('#sh [data-a="facts"]');await W(1500);
console.log('historial:',await p.evaluate(()=>document.querySelector('#fh-l').innerText.replace(/\n/g,' | ')));
await p.click('#fh-l [data-a="verFact"] >> nth=0');await W(1500);
console.log('detalle:',await p.evaluate(()=>document.querySelector('#sh').innerText.replace(/\n/g,' | ').slice(0,420)),'| foto:',await p.evaluate(()=>{const i=document.querySelector('#fv-img img');return i?i.src.slice(0,23)+' '+i.src.length+' chars':'no'}));
await p.screenshot({path:'fh1.png'});
await p.click('#fv-img img');await W(400);console.log('zoom abierto:',!!(await p.$('#fzoom')));await p.click('#fzoom button');await W(300);console.log('zoom cerrado:',!(await p.$('#fzoom')));
const fdocs=await p.evaluate(async()=>{const u=firebase.auth().currentUser.uid;const a=await firebase.firestore().collection('users').doc(u).collection('t_fact').get();const b=await firebase.firestore().collection('users').doc(u).collection('t_fimg').get();return a.docs.length+' facturas, '+b.docs.length+' fotos'});console.log('firebase:',fdocs);
// proveedor
await p.click('#sh [data-a="cerrar"]');await W();await p.click('[data-tab="gastos"]');await W();await p.click('[data-gv="prov"]').catch(()=>{});await W();await p.click('#main [data-a="prov"] >> nth=0').catch(()=>{});await W(600);
const hasBtn=await p.$('#sh [data-a="facts"][data-id]');console.log('botón en proveedor:',!!hasBtn);if(hasBtn){await hasBtn.click();await W(1200);console.log('del proveedor:',await p.evaluate(()=>document.querySelector('#fh-l').innerText.split('\n')[0]))}
// borrar
await p.click('#fh-l [data-a="verFact"] >> nth=0');await W(1200);await p.click('[data-a="factDel"]');await W(1500);console.log('tras borrar:',await p.evaluate(()=>document.querySelector('#fh-l').innerText.split('\n')[0]));
await p.click('#sh [data-a="cerrar"]');await W();
// ajustes shows active
await p.click('[data-a="ajustes"] >> nth=0');await W();console.log('ajustes ia:',await p.evaluate(()=>[...document.querySelectorAll('#sh [data-a="iaConf"]')].map(x=>x.innerText.replace(/\n/g,' '))[0]));await p.click('#sh [data-a="cerrar"]');
await p.click('[data-tab="inv"]');await W();await S(5);
console.log('errs',errs);await b.close();srv.kill();})();
