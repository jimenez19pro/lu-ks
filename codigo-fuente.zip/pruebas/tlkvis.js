const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8813'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},deviceScaleFactor:1,locale:'es-CO',serviceWorkers:'block',colorScheme:process.argv[2]||'dark'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.dismiss());await p.addInitScript(()=>{localStorage.setItem('luks-lang','es')});const W=ms=>p.waitForTimeout(ms||400);const O='/tmp/claude-0/-home-claude/386cd89e-f2f2-549f-a9dc-a0da83d3d90b/scratchpad/vis-'+(process.argv[2]||'dark')+'/';fs.mkdirSync(O,{recursive:true});let n=0;
await p.goto('http://localhost:8813/');await W(3000);await p.click('[data-au="up"]');await p.fill('#au-n','Jose');await p.fill('#au-e','jose@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(2500);
for(let i=0;i<8;i++){await p.evaluate(()=>{const s=document.querySelector('[data-ob="skip"]');if(s)s.click()});await W(250)}
await p.evaluate(()=>{const mk=o=>{AE=-1;AF=Object.assign(afNew(),o);saveAcc2()};mk({tipo:"debito",banco:"Bancolombia",ini:"2850000",pri:true});mk({tipo:"credito",banco:"Nu Colombia",color:CLR[7],cupo:"3000000",ini:"0"});mk({tipo:"efectivo",name:"Billetera",ini:"180000"})});await W(800);
await p.evaluate(()=>{const now=new Date();const ds=(m,d)=>{const x=new Date(now.getFullYear(),now.getMonth()-m,d);return x.getFullYear()+'-'+String(x.getMonth()+1).padStart(2,'0')+'-'+String(x.getDate()).padStart(2,'0')};
const base=[[2,38900,'Mercado D1','comida'],[3,12000,'Taxi','transp'],[5,89000,'Internet','serv'],[6,45000,'Cine','ocio'],[1,850000,'Arriendo','hogar'],[8,26500,'Almuerzo','comida'],[9,60000,'Farmacia','salud'],[12,120000,'Ropa','ropa'],[14,64000,'Mercado','comida'],[16,18000,'Uber','transp'],[18,230000,'Cuota tarjeta','deuda'],[19,35000,'Domicilio','comida']];
const f=[1.15,1.05,1.22,0.98,1.1];
for(let m=5;m>=1;m--){base.forEach(([d,v,n,c])=>{PFDATE=ds(m,d);TP='out';addRow(Math.round(v*f[m-1]/100)*100,n,'Bancolombia',c,'')});PFDATE=ds(m,1);TP='in';addRow(3200000,'Sueldo','Bancolombia','','')}
const today=now.getDate();base.filter(x=>x[0]<=today).forEach(([d,v,n,c])=>{PFDATE=ds(0,d);TP='out';addRow(v,n,c==='comida'?'Nu Colombia':'Bancolombia',c,'')});PFDATE=ds(0,1);TP='in';addRow(3200000,'Sueldo','Bancolombia','','')});await W(2500);
await p.evaluate(()=>{[['comida',700000],['hogar',900000],['transp',150000],['ocio',120000],['salud',100000]].forEach(([k,v])=>{BK=k;document.getElementById('b-amt').value=String(v);saveBud()})});await W(800);
await p.evaluate(()=>{GE=-1;document.getElementById('g-n').value='Viaje a Cartagena';document.getElementById('g-t').value='2500000';document.getElementById('g-s').value='1150000';document.getElementById('g-a').value='';document.getElementById('g-d').value='';saveGoal()});await W(800);

await p.evaluate(()=>{GE=-1;openGoal(-1);$("#g-n").value='Viaje';$("#g-t").value='2500000';$("#g-s").value='900000';saveGoal()});await W(600);
await p.evaluate(()=>{openDebt(-1);$("#d-n").value='Préstamo carro';$("#d-t").value='12000000';$("#d-p").value='3500000';saveDebt()});await W(600);
await p.evaluate(()=>{openRec(-1);$("#r-n").value='Netflix';$("#r-a").value='45000';$("#r-d").value='15';saveRec()});await W(600);
const off=()=>p.evaluate(()=>{document.querySelectorAll('.on').forEach(x=>{const cs=getComputedStyle(x);if(cs.position==='fixed'&&x.tagName!=='NAV')x.classList.remove('on')});window.scrollTo(0,0)});
const S=async name=>{await W(450);n++;await p.screenshot({path:O+String(n).padStart(2,'0')+'-'+name+'.png',fullPage:true})};
const V=async name=>{await W(450);n++;await p.screenshot({path:O+String(n).padStart(2,'0')+'-'+name+'.png'})};
await off();await p.click('[data-t="home"]');await W(800);await S('inicio');
await p.click('[data-hv="aho"]');await W(800);await S('ahorros-deudas');await p.click('[data-hv="fin"]').catch(()=>{});
await p.click('[data-t="tx"]');await W(900);await S('movimientos');
await p.click('[data-t="rep"]');await W(1200);await S('reportes');
await p.click('[data-t="con"]');await W(900);await S('ajustes');
await off();await p.click('[data-t="home"]');await W(500);await p.click('#add');await W(600);await V('form-gasto');
await p.click('#fo-cat');await W(500);await V('elegir-categoria');await off();
await p.click('#add');await W(500);await p.click('#fo-acc');await W(500);await V('elegir-cuenta');await off();
await p.click('#add');await W(500);await p.click('#fo-tp');await p.click('#fo-tp');await W(300);await V('form-transferencia');await off();
await p.click('#add');await W(500);await p.click('#f-ai');await W(500);await V('notas-ai');await off();
await p.evaluate(()=>openBud('comida'));await V('presupuesto');await off();
await p.evaluate(()=>openGoal(0));await V('meta');await off();
await p.evaluate(()=>openDebt(0));await V('deuda');await off();
await p.evaluate(()=>openRec(0));await V('recurrente');await off();
await p.click('[data-t="tx"]');await W(800);await p.click('#app .row[data-id] >> nth=0');await V('detalle-movimiento');await off();
await p.click('[data-t="home"]');await W(600);await p.evaluate(()=>{const b=document.getElementById('aadd')||[...document.querySelectorAll('#app button,#app .lnk')].find(x=>/agregar cuenta|nueva cuenta|\+ cuenta/i.test(x.textContent));b&&b.click()});await W(600);await V('nueva-cuenta');await off();
await p.evaluate(()=>{const b=document.querySelector('#navopen');b&&b.click()});await W(600);await V('menu-navegacion');await off();
await p.click('[data-t="rep"]');await W(900);await p.evaluate(()=>{const b=[...document.querySelectorAll('#app button')].find(x=>/Simulador/i.test(x.textContent));b&&b.click()});await W(700);await V('simulador');await off();
console.log('fotos',n,'errs',errs);await b.close();srv.kill()})();