const {chromium}=require('playwright');const {spawn}=require('child_process');(async()=>{
const srv=spawn('python3',['-m','http.server','8766'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({serviceWorkers:'block',viewport:{width:390,height:844},colorScheme:'dark'});const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:require('fs').readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
await p.goto('http://localhost:8766/');await p.waitForTimeout(3000);await p.click('[data-au="up"]');await p.fill('#au-n','Jose');await p.fill('#au-e','j@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await p.waitForTimeout(900);await p.waitForTimeout(1500);await p.evaluate(()=>{const s=document.querySelector('[data-ob="skip"]');if(s)s.click()});await p.waitForTimeout(500);
await p.evaluate(()=>{tab='con';render()});await p.click('[data-pub="imp"]');await p.setInputFiles('#imp-f','lu-ks-mis-datos.json');await p.waitForTimeout(300);await p.screenshot({path:'imp1.png'});
await p.click('#imp-go');await p.waitForTimeout(1200);console.log('ACC',await p.evaluate(()=>ACC.map(a=>a.n+':'+a.ini+':'+accBal(a)).join(' | ')),'tx',await p.evaluate(()=>tx.length));
// second import with all sections
await p.evaluate(()=>{document.querySelector('.lk-cel')&&document.querySelector('.lk-cel').click()});await p.waitForTimeout(400);
await p.click('[data-pub="imp"]');await p.setInputFiles('#imp-f','lu-ks-mis-datos.json');await p.waitForTimeout(300);
for(const t of ['Gastos','Presupuestos','Recurrentes','Deudas']) await p.click(`[data-imp="${t}"]`);await p.click('#imp-go');await p.waitForTimeout(1200);
console.log('bal after all',await p.evaluate(()=>ACC.map(a=>a.n+':'+a.ini).join(' | ')));console.log('after all: acc',await p.evaluate(()=>ACC.length),'tx',await p.evaluate(()=>tx.length),'rec',await p.evaluate(()=>REC.length),'debts',await p.evaluate(()=>DEBTS.length),'bud',await p.evaluate(()=>budTot()));
await p.reload();await p.waitForTimeout(3200);console.log('persist acc',await p.evaluate(()=>ACC.length+' tx '+tx.length));
await p.evaluate(()=>{tab='home';render()});await p.waitForTimeout(500);await p.screenshot({path:'imp2.png'});
console.log('errs',errs);await b.close();srv.kill()})();
