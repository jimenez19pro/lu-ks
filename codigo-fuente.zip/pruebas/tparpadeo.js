const {chromium}=require(process.env.PW||'playwright');const {spawn}=require('child_process');const fs=require('fs');
const src=fs.readFileSync((process.env.LUKSAPP||'../lu-ks-app')+'/puente.js','utf8').replace(/^export function puente/m,'function puente')+'\nmodule.exports=puente;';
const m={exports:{}};new Function('module','exports',src)(m,m.exports);const BR=m.exports({version:'1',os:'ios',recordatorios:true,sinSplash:false,formNativo:true});
(async()=>{const srv=spawn('python3',['-m','http.server','8819'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},serviceWorkers:'block'});
await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const p=await ctx.newPage();p.on('dialog',d=>d.accept());await p.addInitScript(()=>{localStorage.setItem('luks-lang','es');window.ReactNativeWebView={postMessage:()=>{}}});await p.addInitScript(BR);
await p.goto('http://localhost:8819/');await p.waitForTimeout(3000);await p.click('[data-au="up"]');await p.fill('#au-n','Jose');await p.fill('#au-e','j@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await p.waitForTimeout(2500);
for(let i=0;i<8;i++){await p.evaluate(()=>{const s=document.querySelector('[data-ob="skip"]');if(s)s.click()});await p.waitForTimeout(200)}
await p.evaluate(()=>{document.querySelector('nav .tab[data-t="con"]').click()});await p.waitForTimeout(1200);
console.log('fila antes:',await p.evaluate(()=>!!document.getElementById('lkapp-rem')));
// cuántos cuadros (frames) seguidos se pinta Ajustes SIN la fila, al tocar colores
const r=await p.evaluate(async()=>{let faltas=0;const bs=[...document.querySelectorAll('[data-acc]')];for(const b of bs){b.click();await new Promise(res=>requestAnimationFrame(()=>{if(!document.getElementById('lkapp-rem'))faltas++;res()}));await new Promise(res=>setTimeout(res,150));await new Promise(res=>requestAnimationFrame(()=>{if(!document.getElementById("lkapp-rem"))faltas++;res()}))}return{colores:bs.length,faltas}});
console.log(JSON.stringify(r));await b.close();srv.kill()})();
