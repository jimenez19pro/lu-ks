// Prueba de "abrir más rápido": arma la copia de la página con los scripts
// adentro (copia.js → armar) y la abre SIN acceso a config.js ni a Firebase de
// internet, para comprobar que todo quedó incluido y que la sesión funciona.
const {chromium}=require(process.env.PW||'playwright');const fs=require('fs');
const APPDIR=process.env.LUKSAPP||'../lu-ks-app';
const src=fs.readFileSync(APPDIR+'/copia.js','utf8');
const cut=s=>s.replace(/^import .*$/mg,'').replace(/^export /mg,'');
const mod={};new Function('mod','fetch','AbortController',cut(src)+'\nmod.armar=armar;mod.absoluta=absoluta;mod.BASE=BASE;')(mod,null,function(){});
(async()=>{let ok=0,bad=0;const CK=(n,c,i)=>{c?ok++:bad++;console.log(c?'  ✔':'  ✘',n,i===undefined?'':i)};
CK('ruta relativa',mod.absoluta('config.js')===mod.BASE+'config.js',mod.absoluta('config.js'));
CK('ruta absoluta',mod.absoluta('https://www.gstatic.com/x.js')==='https://www.gstatic.com/x.js');
CK('ruta desde la raíz',mod.absoluta('/otra.js')==='https://jimenez19pro.github.io/otra.js',mod.absoluta('/otra.js'));
const html=fs.readFileSync('pub/index.html','utf8');const pedidos=[];
const traer=async u=>{pedidos.push(u);if(/config\.js$/.test(u))return 'window.LUKS_FB={apiKey:"x"};/* config */';if(/firebase-app-compat/.test(u))return fs.readFileSync('mockfb.js','utf8')+'\n/* "</script>" de prueba */';return '/* '+u.split('/').pop()+' */ void 0;'};
const r=await mod.armar(html,traer);
CK('5 scripts incluidos',r.scripts.length===5,r.scripts.join(' '));CK('ya no pide scripts afuera',!/<script\s+src=/.test(r.html));
CK('sin tipografías de Google',!/fonts\.googleapis/.test(r.html));CK('"</script" escapado',r.html.indexOf('"<\\/script>" de prueba')>0);
CK('tamaño razonable',r.html.length>html.length,html.length+' → '+r.html.length);
// abrir la copia con la dirección de siempre, sin internet para scripts
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},serviceWorkers:'block',locale:'es-CO'});
const fuera=[];await ctx.route('**/*',rt=>{const u=rt.request().url();if(u==='http://lu-ks.test/'||u==='http://lu-ks.test/index.html')return rt.fulfill({body:r.html,contentType:'text/html'});fuera.push(u);return rt.abort()});
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept());
await p.addInitScript(()=>{window.LKNV_OFF=1});await p.goto('http://lu-ks.test/');await p.waitForTimeout(3000);
CK('carga y muestra la entrada',await p.evaluate(()=>!!document.getElementById('auth')&&getComputedStyle(document.getElementById('auth')).display!=='none'));
await p.click('[data-au="up"]');await p.fill('#au-n','Jose');await p.fill('#au-e','jose@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await p.waitForTimeout(2500);
for(let i=0;i<8;i++){await p.evaluate(()=>{const s=document.querySelector('[data-ob="skip"]');if(s)s.click()});await p.waitForTimeout(200)}
CK('entra a la app',await p.evaluate(()=>!!document.querySelector('#app .hd')));
await p.reload();await p.waitForTimeout(3000);
CK('la sesión sigue al volver a abrir',await p.evaluate(()=>!!document.querySelector('#app .hd')));
const scr=fuera.filter(u=>/\.js(\?|$)/.test(u));CK('no pidió scripts a internet',scr.length===0,scr.join(' '));
CK('sin errores de página',errs.length===0,errs.slice(0,3).join(' | '));
console.log('\n'+ok+' bien, '+bad+' mal');await b.close();process.exit(bad?1:0)})();
