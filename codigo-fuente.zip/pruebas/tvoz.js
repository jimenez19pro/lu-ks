const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8804'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();
for(const modo of ['voz']){
const ctx=await b.newContext({viewport:{width:390,height:844},colorScheme:'dark',locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
await ctx.addInitScript(m=>{if(m==='tecla'){delete window.webkitSpeechRecognition;delete window.SpeechRecognition}else{var F=function(){var s=this;s.start=function(){setTimeout(function(){s.onresult&&s.onresult({resultIndex:0,results:[Object.assign([{transcript:'me pagaron un millón doscientos mil en nequi'}],{isFinal:true})]});setTimeout(function(){s.onend&&s.onend()},50)},200)};s.stop=function(){}};Object.defineProperty(window,'webkitSpeechRecognition',{value:F,configurable:true,writable:true});Object.defineProperty(window,'SpeechRecognition',{value:F,configurable:true,writable:true})}},modo);
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));const W=ms=>p.waitForTimeout(ms||300);
await p.goto('http://localhost:8804/');await W(3000);await p.click('[data-au="up"] >> nth=0');await p.fill('#au-n','Jose');await p.fill('#au-e','v@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(2000);await p.click('[data-ob="skip"]');await W(800);
await p.evaluate(()=>{const d=JSON.parse(localStorage.mockdb);const key=Object.keys(d).find(x=>x.includes('/tabs/Cuentas__'));const cur=JSON.parse(d[key].rows);d[key].rows=JSON.stringify([cur[0],["Billetera","Efectivo",2900,"","","","","","","","",""],["Nequi","Débito",126000,"","Nequi","","","","","","",""]]);localStorage.mockdb=JSON.stringify(d)});await p.reload();await W(3500);
await p.evaluate(()=>{tab='home';render();scrollTo(0,0)});await W(300);console.log(modo,'mic en inicio',!!(await p.$('#lkmic')));await p.screenshot({path:'voz0-'+modo+'.png'});
await p.click('#lkmic');await W(400);
if(modo==='tecla'){await p.fill('#lkv-t','almuerzo doce mil en Nequi');await W(200)}else{await p.click('#lkv-btn');await W(800)}
await p.screenshot({path:'voz1-'+modo+'.png'});console.log(modo,'preview:',(await p.textContent('#lkv-pv')).replace(/\s+/g,' '));
await p.click('#lkv-ok');await W(700);console.log(modo,'form:',JSON.stringify(await p.evaluate(()=>({amt:$("#f-amt").value,mer:$("#f-mer")&&$("#f-mer").value,acc:$("#f-acc")&&$("#f-acc").value,tp:TP,open:$("#sheet").classList.contains("on")}))));await p.screenshot({path:'voz2-'+modo+'.png'});
if(modo==='tecla'){await p.click('#lkv-open');await W(400);await p.fill('#lkv-t','taxi 8 mil efectivo');await W(150);console.log('efectivo->',(await p.textContent('#lkv-pv')).replace(/\s+/g,' '))}
console.log(modo,'errs',errs);await ctx.close()}
await b.close();srv.kill()})();
