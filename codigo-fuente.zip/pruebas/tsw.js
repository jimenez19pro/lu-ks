// La web nueva se ve al instante: aunque el servidor diga "guarda 10 minutos" (como GitHub Pages),
// el service worker pide la página sin la memoria del navegador.
const {chromium}=require(process.env.PW||'playwright');const http=require('http');const fs=require('fs');const path=require('path');
const DIR=process.cwd()+'/pub';let marca='A';
const srv=http.createServer((q,r)=>{let f=decodeURIComponent(q.url.split('?')[0]);if(f.endsWith('/'))f+='index.html';const p=path.join(DIR,f);if(!fs.existsSync(p)){r.writeHead(404);return r.end()}
 let b=fs.readFileSync(p);if(f.endsWith('index.html'))b=Buffer.from(b.toString().replace('<title>','<meta name="marca" content="'+marca+'"><title>'));
 r.writeHead(200,{'Content-Type':f.endsWith('.js')?'application/javascript':f.endsWith('.html')?'text/html':f.endsWith('.json')?'application/json':'application/octet-stream','Cache-Control':'max-age=600'});r.end(b)}).listen(8851);
(async()=>{const b=await chromium.launch();let ok=0,bad=0;const CK=(n,c,i)=>{c?ok++:bad++;console.log(c?'  ✔':'  ✘',n,i===undefined?'':i)};
const ctx=await b.newContext({viewport:{width:390,height:844}});
await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/fonts\.g/,r=>r.abort());
const p=await ctx.newPage();await p.goto('http://localhost:8851/');await p.waitForTimeout(2500);
await p.evaluate(()=>navigator.serviceWorker.ready);await p.reload();await p.waitForTimeout(1500);
CK('el service worker está activo',await p.evaluate(()=>!!navigator.serviceWorker.controller));
CK('primera versión',await p.evaluate(()=>document.querySelector('meta[name=marca]').content)==='A');
await p.goto('http://localhost:8851/index.html');await p.waitForTimeout(1200);
marca='B';await p.goto('http://localhost:8851/');await p.waitForTimeout(1500);
CK('al subir una versión nueva se ve al abrir (sin esperar 10 minutos)',await p.evaluate(()=>document.querySelector('meta[name=marca]').content)==='B');
await p.goto('http://localhost:8851/index.html');await p.waitForTimeout(1500);
CK('también abriendo index.html',await p.evaluate(()=>document.querySelector('meta[name=marca]').content)==='B');
console.log('\n'+ok+' bien, '+bad+' mal');await b.close();srv.close();process.exit(bad?1:0)})();
