window.XLSX={utils:{book_new:()=>({S:[],N:[]}),book_append_sheet:(wb,ws,n)=>{wb.S.push(ws);wb.N.push(n)},json_to_sheet:r=>({rows:r}),aoa_to_sheet:a=>({aoa:a}),sheet_to_json:(ws,o)=>ws.aoa},
read:(b)=>{const t=new TextDecoder().decode(new Uint8Array(b));const aoa=t.trim().split(/\r?\n/).map(l=>l.split(';'));return{SheetNames:['P'],Sheets:{P:{aoa}}}},
writeFile:(wb,name)=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(wb.S[0])]));a.download=name;document.body.appendChild(a);a.click()}};
