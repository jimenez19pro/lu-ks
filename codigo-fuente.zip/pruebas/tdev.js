const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8775'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},colorScheme:'dark',locale:'es-CO'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
await ctx.addInitScript(()=>{const N={permission:'granted',requestPermission:()=>Promise.resolve('granted')};Object.defineProperty(window,'Notification',{value:N,configurable:true});Object.defineProperty(navigator,'standalone',{value:true})});
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('http://localhost:8775/');await p.waitForTimeout(3000);await p.click('[data-au="up"] >> nth=0');await p.fill('#au-n','Jose');await p.fill('#au-e','j@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await p.waitForTimeout(2000);await p.click('[data-ob="skip"]');await p.waitForTimeout(800);
await p.evaluate(()=>{tab='con';render()});await p.click('[data-pub="push"]');await p.waitForTimeout(1500);
const txt=()=>p.evaluate(()=>document.querySelector('#xbody').innerText.replace(/\n+/g,' | '));
console.log('simple:',await txt());await p.screenshot({path:'dev1.png'});
for(let i=0;i<7;i++)await p.click('#pd-bell');await p.waitForTimeout(500);
console.log('tec:',await txt(),await p.evaluate(()=>JSON.stringify(LKPUBT.Ajustes)));
for(let i=0;i<7;i++)await p.click("#pd-bell");await p.waitForTimeout(500);console.log("off:",await txt(),await p.evaluate(()=>localStorage.getItem("luks-dev")+" "+ajG("dev")));console.log("errs",errs);await b.close();srv.kill()})();
