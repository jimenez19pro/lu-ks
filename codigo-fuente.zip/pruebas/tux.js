const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8767'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();
const mk=async(lang)=>{const ctx=await b.newContext({serviceWorkers:'block',viewport:{width:390,height:844},hasTouch:true,isMobile:true,colorScheme:'dark',locale:lang==='en'?'en-US':'es-CO'});
await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));await p.addInitScript(l=>{try{localStorage.setItem('luks-lang',l)}catch(e){}},lang);
await p.goto('http://localhost:8767/');await p.waitForTimeout(2500);await p.click('[data-au="up"]');await p.fill('#au-n','Jose');await p.fill('#au-e','j'+lang+'@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await p.waitForTimeout(2500);
for(let i=0;i<8;i++){await p.evaluate(()=>{const s=document.querySelector('[data-ob="skip"]');if(s)s.click()});await p.waitForTimeout(250)}
await p.evaluate(()=>{TP='out';[[38900,'Mercado','comida'],[850000,'Arriendo','hogar'],[60000,'Farmacia','salud']].forEach(a=>addRow(a[0],a[1],'Efectivo',a[2],''));TP='in';addRow(2500000,'Sueldo','Efectivo','','')});await p.waitForTimeout(1500);
return {ctx,p,errs}};
const W=(p,ms)=>p.waitForTimeout(ms||300);
const touch=(p,sel,dx,dy,steps)=>p.evaluate(([sel,dx,dy,steps])=>{const el=document.querySelector(sel);const r=el.getBoundingClientRect();const x0=r.left+r.width/2,y0=r.top+Math.min(20,r.height/2);const mkT=(x,y)=>new Touch({identifier:1,target:el,clientX:x,clientY:y});el.dispatchEvent(new TouchEvent('touchstart',{bubbles:true,touches:[mkT(x0,y0)],changedTouches:[mkT(x0,y0)]}));for(let i=1;i<=steps;i++){const t=mkT(x0+dx*i/steps,y0+dy*i/steps);el.dispatchEvent(new TouchEvent('touchmove',{bubbles:true,touches:[t],changedTouches:[t]}))}const te=mkT(x0+dx,y0+dy);el.dispatchEvent(new TouchEvent('touchend',{bubbles:true,touches:[],changedTouches:[te]}))},[sel,dx,dy,steps]);
// ===== español
let {ctx,p,errs}=await mk('es');
console.log('hero:',await p.evaluate(()=>document.querySelector('.hero').innerText.replace(/\n/g,' | ')));
console.log('header:',await p.evaluate(()=>document.querySelector('.hd').innerText.replace(/\n/g,' | ')),'| sync dot ok:',await p.evaluate(()=>!document.querySelector('.sdot').classList.contains('off')),'| banner text:',await p.evaluate(()=>[...document.querySelectorAll('#app > .mut')].map(x=>x.innerText).join('/')));
console.log('icons in rows:',await p.evaluate(()=>document.querySelectorAll('#app .row .ci svg').length),'| red expense amounts:',await p.evaluate(()=>[...document.querySelectorAll('#app .row .amt.neg')].length));
// count-up: switch tab and back
await p.click('[data-t="tx"]');await W(p,200);console.log('tab anim class:',await p.evaluate(()=>document.getElementById('app').classList.contains('lk-tab')));await p.click('[data-t="home"]');await W(p,120);const mid=await p.textContent('.hero-v');await W(p,900);console.log('countup mid:',mid,'→ end:',await p.textContent('.hero-v'));
// FAB opens form directly
await p.click('#add');await W(p,400);console.log('fab → form on:',await p.evaluate(()=>document.getElementById('sheet').classList.contains('on')),'| choice sheet on:',await p.evaluate(()=>document.getElementById('hsheet').classList.contains('on')),'| focus:',await p.evaluate(()=>document.activeElement&&document.activeElement.id),'| ai btn:',await p.evaluate(()=>getComputedStyle(document.getElementById('f-ai')).display));
await p.click('#f-ai');await W(p,300);console.log('ai → notes sheet:',await p.evaluate(()=>document.getElementById('nsheet').classList.contains('on')),'form closed:',await p.evaluate(()=>!document.getElementById('sheet').classList.contains('on')));await p.click('#nclose');await W(p);
// drag to close
await p.click('#add');await W(p,400);await touch(p,'#sheet > div .handle',0,220,8);await W(p,500);console.log('drag closes form:',await p.evaluate(()=>!document.getElementById('sheet').classList.contains('on')));
// small drag returns
await p.click('#add');await W(p,400);await touch(p,'#sheet > div .handle',0,60,4);await W(p,400);console.log('small drag stays open:',await p.evaluate(()=>document.getElementById('sheet').classList.contains('on')),'transform reset:',await p.evaluate(()=>document.querySelector('#sheet>div').style.transform||'none'));await p.click('#cancel');await W(p);
// swipe row in movements
await p.click('[data-t="tx"]');await W(p,500);await touch(p,'#txlist .row[data-id]',-150,4,8);await W(p,500);console.log('swipe → edit sheet:',await p.evaluate(()=>document.getElementById('csheet').classList.contains('on')),await p.evaluate(()=>document.getElementById('ct').textContent));await p.evaluate(()=>document.getElementById('csheet').classList.remove('on'));
// edit hides AI buttons
await p.evaluate(()=>{CUR=tx[0];startEdit()});await W(p,300);console.log('edit: ai hidden:',await p.evaluate(()=>getComputedStyle(document.getElementById('f-ai')).display==='none'));await p.click('#cancel');await W(p);
// pull to refresh
await p.click('[data-t="home"]');await W(p,400);await p.evaluate(()=>window.scrollTo(0,0));await touch(p,'#app .hero',0,140,8);await W(p,200);console.log('ptr:',await p.evaluate(()=>{const e=document.querySelector('.ptr');return e?e.textContent+' '+e.classList.contains('on'):'none'}));
await p.click('[data-t="rep"]');await W(p,500);console.log('rep seg:',await p.evaluate(()=>[...document.querySelectorAll('[data-rt]')].map(x=>x.textContent).join('/')),'| nav:',await p.evaluate(()=>[...document.querySelectorAll('nav .tab')].map(x=>x.textContent.trim()).join('/')));
await p.screenshot({path:'ux-rep.png'});
console.log('errs es',errs);await ctx.close();
// ===== inglés
({ctx,p,errs}=await mk('en'));
console.log('EN hero:',await p.evaluate(()=>document.querySelector('.hero').innerText.replace(/\n/g,' | ')),'| hd:',await p.evaluate(()=>document.querySelector('.hd').innerText.replace(/\n/g,' | ')));
console.log('EN cards:',await p.evaluate(()=>document.querySelector('.duo').innerText.replace(/\n/g,' | ')),'| nav:',await p.evaluate(()=>[...document.querySelectorAll('nav .tab')].map(x=>x.textContent.trim()).join('/')));
await p.click('#add');await W(p,400);console.log('EN form btns:',await p.evaluate(()=>document.getElementById('f-ai').textContent));await p.click('#cancel');
await p.click('[data-t="rep"]');await W(p,500);console.log('EN rep:',await p.evaluate(()=>[...document.querySelectorAll('[data-rt]')].map(x=>x.textContent).join('/')),'|',await p.evaluate(()=>{const e=document.querySelector('.empt');return e?e.innerText.replace(/\n/g,' | '):'-'}));
await p.click('[data-t="home"]');await W(p,1000);await p.screenshot({path:'ux-en.png'});
console.log('errs en',errs);await b.close();srv.kill();})();
