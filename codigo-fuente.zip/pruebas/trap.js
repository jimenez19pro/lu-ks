const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8796'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},locale:'es-CO',serviceWorkers:'block',colorScheme:'dark'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept());const W=ms=>p.waitForTimeout(ms||300);
await p.goto('http://localhost:8796/tienda/');await W(3000);await p.click('[data-am="up"]');await p.fill('#au-e','r@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500);
await p.evaluate(()=>{const u=firebase.auth().currentUser.uid;const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()});await W(1200);
await p.click('[data-tab="inv"]');await p.click('[data-a="nuevoProd"]');await p.fill('#p-n','Gaseosa');await p.fill('#p-pv','3000');await p.fill('#p-pc','2000');await p.fill('#p-st','10');await p.click('[data-a="guardarProd"]');await W();
await p.click('[data-tab="caja"]');await p.click('[data-a="venta"] >> nth=0');await W();await p.click('[data-vm="rap"]');await W();
await p.fill('#v-rap','2000');await p.fill('#v-nota','Pan');await p.click('[data-a="rapAdd"]');await W();
await p.click('[data-vadd="1000"]');await p.click('[data-vadd="2000"]');await p.fill('#v-nota','Gaseosa suelta');await p.click('[data-a="rapAdd"]');await W();
await p.fill('#v-rap','2000');await p.fill('#v-nota','pan');await p.click('[data-a="rapAdd"]');await W();
await p.click('[data-a="rapAdd"]');await W();console.log('sin valor:',await p.textContent('#toast'));
await p.fill('#v-rap','1500');await p.fill('#v-nota','');await p.click('[data-a="rapAdd"]');await W();
console.log('total:',await p.textContent('#v-tot'),'| carrito:',await p.evaluate(()=>document.querySelector('.cart').innerText.replace(/\n/g,' ')));
await p.evaluate(()=>document.getElementById('sh').scrollTop=0);await W(300);await p.screenshot({path:'rap0.png'});console.log('ayuda:',await p.evaluate(()=>[...document.querySelectorAll('#sh .s')].map(x=>x.textContent).find(t=>/Llevas/.test(t))));
// también uno de inventario
await p.click('[data-vm="prod"]');await W();await p.click('.pb >> text=Gaseosa');await W();
await p.fill('#v-paga','20000');await W();await p.screenshot({path:'rap1.png'});console.log('total+inv:',await p.textContent('#v-tot'));
await p.click('[data-a="guardarVenta"]');await W(600);
const st=await p.evaluate(()=>{const v=LKT.D.venta[0];return{total:v.total,costo:v.costo,items:v.items.map(i=>i.n+' x'+i.q+' $'+i.pv).join(', '),stock:LKT.D.prod[0].st}});console.log('venta:',JSON.stringify(st));
// venta simple (como antes)
await p.click('[data-a="venta"] >> nth=0');await W();await p.click('[data-vm="rap"]');await p.fill('#v-rap','7000');await p.click('[data-a="guardarVenta"]');await W(500);
console.log('simple:',await p.evaluate(()=>{const v=LKT.D.venta.find(x=>x.total===7000);return v?v.items.length+' items, total '+v.total:'no'}));
await p.click('[data-tab="rep"]');await W(800);console.log('más vendidos:',await p.evaluate(()=>{const h=[...document.querySelectorAll('#main h2')].find(x=>/vende/i.test(x.textContent));return h?h.nextElementSibling.innerText.replace(/\n/g,' ').slice(0,200):'-'}));
console.log('errs',errs);await b.close();srv.kill()})();
