const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8799'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/unpkg/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const WA=[];await ctx.route(/wa\.me/,r=>{WA.push(decodeURIComponent(r.request().url()));r.fulfill({body:'<html>wa</html>',contentType:'text/html'})});
let p=await ctx.newPage();const errs=[];const hook=pg=>{pg.on('pageerror',e=>errs.push(e.message));pg.on('dialog',d=>d.accept(d.type()==='prompt'?'':undefined))};hook(p);
const S=async n=>{await p.waitForTimeout(300);await p.screenshot({path:'n'+n+'.png'})};const W=ms=>p.waitForTimeout(ms||300);
const back=async()=>{if(!p.url().includes('/tienda/')){await p.goBack();await W(1500)}};
const login=async(e,up)=>{await p.waitForSelector('#au-e');await p.click(up?'[data-am="up"]':'[data-am="in"]');await p.fill('#au-e',e);await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500)};
await p.goto('http://localhost:8799/tienda/');await W(1200);await login('t@x.com',1);await p.evaluate(()=>{const u=firebase.auth().currentUser.uid;const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()});await W(1200);
await p.click('[data-tab="inv"]');
for(const [n,c] of [['Aceite clarita 220ml','111'],['Arroz Diana 500 g','222'],['Azúcar 1 kg','333444']]){await p.click('[data-a="nuevoProd"]');await p.fill('#p-n',n);await p.fill('#p-pv','3000');await p.fill('#p-st','10');await p.fill('#p-cod',c);await p.click('[data-a="guardarProd"]');await W(200)}
await p.click('[data-a="entrada"]');await W();const L=()=>p.evaluate(()=>[...document.querySelectorAll('#e-l .row')].map(r=>r.innerText.split('\n')[0]).join(' / '));
console.log('inicial:',await L());await S('e1');
await p.fill('#e-s','arr');await W(200);console.log('busca arr:',await L());
await p.click('#e-l [data-a="ePick"]');await W(200);console.log('elegido:',await p.inputValue('#e-s'),'| lista:',await L());
await p.fill('#e-q','12');await p.click('[data-a="guardarEntrada"]');await W(300);console.log('toast:',await p.textContent('#toast'));
await p.fill('#e-s','Leche Alquería 1L');await W(200);console.log('busca nueva:',await L());await S('e2');
await p.click('[data-a="guardarEntrada"]');await W(200);console.log('msg sin elegir:',await p.textContent('#e-msg'));
await p.click('[data-a="eNuevo"]');await W(300);console.log('form nombre:',await p.inputValue('#p-n'));await p.fill('#p-pv','4500');await p.fill('#p-pc','3800');await p.fill('#p-st','6');await p.click('[data-a="guardarProd"]');await W(400);
console.log('volvió a entrada?',await p.$('#e-s')!==null,'| toast:',await p.textContent('#toast'));
await p.fill('#e-s','Galletas');await W();await p.click('[data-a="eNuevo"]');await W(300);await p.fill('#p-pv','1000');await p.click('[data-a="guardarProd"]');await W(400);console.log('nuevo sin stock seleccionado:',await p.inputValue('#e-s'));
await p.evaluate(()=>document.activeElement.blur());await p.keyboard.type('333444',{delay:8});await p.keyboard.press('Enter');await W();console.log('scan existente:',await p.inputValue('#e-s'));
await p.evaluate(()=>document.activeElement.blur());await p.keyboard.type('7701234567890',{delay:8});await p.keyboard.press('Enter');await W(300);console.log('scan nuevo -> form cod:',await p.inputValue('#p-cod').catch(()=>'-'));
await p.click('#sh [data-a="cerrar"]').catch(()=>{});await W(300);
console.log('stock:',await p.evaluate(()=>LKT.D.prod.map(x=>x.n+':'+x.st).join(', ')));
console.log('errs',errs);await b.close();srv.kill();})();