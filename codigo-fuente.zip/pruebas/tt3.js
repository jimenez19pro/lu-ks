const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8792'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/unpkg/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const WA=[];await ctx.route(/wa\.me/,r=>{WA.push(decodeURIComponent(r.request().url()));r.fulfill({body:'<html>wa</html>',contentType:'text/html'})});
let p=await ctx.newPage();const errs=[];const hook=pg=>{pg.on('pageerror',e=>errs.push(e.message));pg.on('dialog',d=>d.accept(d.type()==='prompt'?'':undefined))};hook(p);
const S=async n=>{await p.waitForTimeout(300);await p.screenshot({path:'n'+n+'.png'})};const W=ms=>p.waitForTimeout(ms||300);
const back=async()=>{if(!p.url().includes('/tienda/')){await p.goBack();await W(1500)}};
const login=async(e,up)=>{await p.waitForSelector('#au-e');await p.click(up?'[data-am="up"]':'[data-am="in"]');await p.fill('#au-e',e);await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500)};
await p.goto('http://localhost:8792/tienda/');await W(1200);await login('t@x.com',1);await p.evaluate(()=>{const u=firebase.auth().currentUser.uid;const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()});await p.waitForTimeout(1200);
await p.click('[data-a="ajustes"] >> nth=0');await p.fill('#s-t','Tienda Don Pacho');await p.fill('#s-b','50000');await p.fill('#s-wa','3001112233');await p.click('[data-a="guardarAj"]');await W();
// proveedor
await p.click('[data-tab="gastos"]');await p.click('[data-gv="prov"]');await p.click('[data-a="nuevoProv"]');await p.fill('#v-n','Distribuidora El Sol');await p.fill('#v-t','3009998877');await p.selectOption('#v-d',String(new Date().getDay()));await p.click('[data-a="guardarProv"]');await W();await p.click('#sh [data-a="cerrar"]');await W();
// productos (uno con escáner -> código manual)
await p.click('[data-tab="inv"]');
await p.click('[data-a="nuevoProd"]');await p.fill('#p-n','Arroz Diana 500 g');await p.fill('#p-pv','3200');await p.fill('#p-pc','2600');await p.fill('#p-st','20');await p.fill('#p-min','5');await p.click('[data-a="scanProd"]');await W(400);console.log('scanmsg:',await p.textContent('#scan-m'));await p.fill('#scan-in','7702001001');await p.click('#scan-ok');await W();console.log('cod field',await p.inputValue('#p-cod'));await p.selectOption('#p-prov',{label:'Distribuidora El Sol'});await p.click('[data-a="guardarProd"]');await W();
await p.click('[data-a="nuevoProd"]');await p.fill('#p-n','Gaseosa 400 ml');await p.fill('#p-pv','2500');await p.fill('#p-pc','1700');await p.fill('#p-st','4');await p.fill('#p-min','6');await p.selectOption('#p-prov',{label:'Distribuidora El Sol'});await p.click('[data-a="guardarProd"]');await W();
await p.click('[data-a="nuevoProd"]');await p.fill('#p-n','Queso costeño');await p.click('[data-pu="lb"]');await p.fill('#p-pv','14000');await p.fill('#p-pc','11000');await p.fill('#p-st','10');await p.fill('#p-min','3');await p.click('[data-a="guardarProd"]');await W();await S(1);
// venta: escanear arroz, queso 1/2 lb, queso por valor 3000
await p.click('[data-tab="caja"]');await p.click('[data-a="venta"] >> nth=0');await W();await p.click('[data-a="scanVenta"]');await p.fill('#scan-in','7702001001');await p.keyboard.press('Enter');await W();console.log('multi cart:',await p.textContent('#scan-tot'));await p.click('#scan-done');await W();
await p.click('.pb >> text=Queso');await W();await S(2);await p.click('[data-wq="0.5"]');await W();await p.click('.pb >> text=Queso');await p.fill('#w-v','3000');await W(100);console.log('w hint',await p.textContent('#w-h'));await p.click('[data-a="wAdd"]');await W();
console.log('total',await p.textContent('#v-tot'));await p.click('[data-vpaga="20000"]');console.log('vuelto',await p.textContent('#v-vuelto'));await S(3);await p.click('[data-a="guardarVenta"]');await W(500);await S(4);console.log('snack',await p.textContent('#snack-t'));await p.click('#snack-b');await W(500);await p.waitForSelector('#sh [data-a="shTxt"]');await p.click('#sh [data-a="shTxt"]');await W(800);await back();
console.log('RECIBO:\n'+WA[WA.length-1]);
console.log('stock',await p.evaluate(()=>LKT.D.prod.map(x=>x.n+':'+x.st).join(', ')));
// fiado a cliente con fecha vieja -> cobrar
await p.click('[data-a="fiar"] >> nth=0');await W();await p.click('[data-vm="rap"]');await p.fill('#v-rap','25000');await p.selectOption('#v-cli','__new');await p.fill('#v-cn','Doña Marta');await p.fill('#v-ct','3001234567');await p.click('[data-a="guardarVenta"]');await W(500);
await p.evaluate(()=>{const d=JSON.parse(localStorage.mockdb);for(const k in d)if(k.includes('/t_fmov/')){d[k].ts-=20*864e5}localStorage.mockdb=JSON.stringify(d)});await p.reload();await W(1800);await S(5);
console.log('cobrar card',await p.evaluate(()=>{const b=document.querySelector('#main [data-a=cobrar]');return b&&b.innerText}));await p.click('#main [data-a="cobrar"]');await W();await S(6);await p.click('#sh [data-a="wa"]');await W(500);await p.waitForSelector('#sh [data-a="shTxt"]');await p.click('#sh [data-a="shTxt"]');await W(800);await back();console.log('COBRO:',WA[WA.length-1].slice(0,140));
console.log('cobrar after',await p.evaluate(()=>!!document.querySelector('#main [data-a=cobrar]')));
// pedido
await p.click('#main [data-a="pedido"] >> nth=0');await W();await S(7);await p.click('[data-pdq] >> nth=0');await p.fill('#pd-n','Si no hay, traer Postobón');await p.click('[data-a="pdEnviar"]');await W(500);await p.waitForSelector('#sh [data-a="shTxt"]');await p.click('#sh [data-a="shTxt"]');await W(800);await back();console.log('PEDIDO:\n'+WA[WA.length-1]);
// precio subió
await p.click('[data-tab="inv"]');await p.click('[data-a="entrada"]');await p.fill('#e-s','Arroz');await p.waitForTimeout(150);await p.click('#e-l [data-a="ePick"] >> nth=0');await p.fill('#e-q','24');await p.fill('#e-c','2800');await p.click('[data-a="guardarEntrada"]');await W();await S(8);console.log('subio:',await p.evaluate(()=>[...document.querySelectorAll('#sh [data-a=nuevoPv]')].map(x=>x.innerText).join(' | ')));await p.click('#sh [data-a="nuevoPv"] >> nth=0');await W();console.log('arroz pv',await p.evaluate(()=>LKT.D.prod.find(x=>x.n.startsWith('Arroz')).pv));
// equipo: invitar
await p.click('[data-a="ajustes"] >> nth=0');await W();await p.click('[data-a="invitar"]');await W();const link=await p.textContent('#sh .code');console.log('link',link);await S(9);
await p.click('#sh [data-a="ajustes"]');await W();await p.click('#sh [data-a="salir"]');await W(1000);
// empleado
await p.goto(link.replace('https://','http://').replace(/^http:\/\/[^/]+/,'http://localhost:8792'));await W(1200);await S(10);await login('juan@x.com',1);await W(500);await S(11);await p.fill('#j-n','Juan');await p.click('#j-go');await W(1200);await S(12);console.log('pend:',(await p.textContent('#auth')).slice(0,80));
await p.click('#j-out');await W(800);
// dueño aprueba
await login('t@x.com',0);await W(800);await W(800);await S('17');console.log('sol card',await p.evaluate(()=>{const c=[...document.querySelectorAll('#main .card')].find(x=>x.innerText.includes('unirse'));return c&&c.innerText}));await p.click('[data-a="ajustes"] >> nth=0');await W();await S(13);await p.click('[data-a="aprobar"]');await W(600);console.log('miem',await p.evaluate(()=>LKT.D.miem.map(x=>x.n)));await p.click('#sh [data-a="salir"]');await W(1000);
// empleado entra
await login('juan@x.com',0);await W(1500);console.log('emp state',JSON.stringify(await p.evaluate(()=>LKT.state())),'rep hidden',await p.evaluate(()=>getComputedStyle(document.querySelector('#nav-rep')).display));await S(14);await p.click('[data-tab="caja"]');await W();
await p.click('[data-a="venta"] >> nth=0');await W();await p.click('.pb >> text=Gaseosa');await p.click('[data-a="guardarVenta"]');await W(500);
await p.click('[data-a="cierre"]');await p.fill('#k-c','60000');await p.click('[data-a="guardarCierre"]');await W(500);await S(15);await p.click('[data-a="waResumen"]');await W(500);await p.waitForSelector('#sh [data-a="shTxt"]');await p.click('#sh [data-a="shTxt"]');await W(800);await back();console.log('RESUMEN EMP to:',WA[WA.length-1].slice(0,60));
console.log('emp sees ganancia?',(await p.textContent('#main')).includes('Ganancia'));
await p.click('[data-a="ajustes"] >> nth=0');await W();await p.click('#sh [data-a="salir"]');await W(1000);
await login('t@x.com',0);await W(1200);await p.click('[data-tab="caja"]');await W();await S(16);console.log('owner movs:',(await p.textContent('#main')).match(/👷 Juan/g));
// quitar empleado
await p.click('[data-a="ajustes"] >> nth=0');await W();await p.click('[data-a="quitarMiem"]');await W(400);await p.click('#sh [data-a="salir"]');await W(1000);await login('juan@x.com',0);await W(1500);console.log('after remove:',(await p.textContent('#auth')).slice(0,60),JSON.stringify(await p.evaluate(()=>LKT.state().ROLE)));
console.log('errs',errs);await b.close();srv.kill()})();
