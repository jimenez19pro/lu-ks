const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8791'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},colorScheme:process.argv[2]||'light',locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const WA=[];await ctx.route(/wa\.me/,r=>{WA.push(decodeURIComponent(r.request().url()));r.fulfill({body:'wa',contentType:'text/html'})});
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept());
const W=ms=>p.waitForTimeout(ms||300);const S=async n=>{await W(250);await p.screenshot({path:'pk'+n+'.png'})};
await p.goto('http://localhost:8791/tienda/');await W(1500);
await p.click('[data-am="up"]');await p.fill('#au-e','t@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500);await p.evaluate(()=>{const u=firebase.auth().currentUser.uid;const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()});await W(1200);
await p.click('[data-a="ajustes"] >> nth=0');await p.fill('#s-t','Tienda Don Pacho');await p.click('[data-a="guardarAj"]');await W();
await p.click('[data-tab="inv"]');await p.click('[data-a="nuevoProd"]');await p.fill('#p-n','Gaseosa 400 ml');await p.fill('#p-pv','3000');await p.fill('#p-pc','2200');await p.fill('#p-st','40');
await p.click('[data-a="pkAdd"]');await p.fill('.pkw >> nth=0 >> [data-pkn]','Paca');await p.fill('.pkw >> nth=0 >> [data-pkq]','12');await p.fill('.pkw >> nth=0 >> [data-pkv]','32000');
await p.click('[data-a="pkAdd"]');await p.fill('.pkw >> nth=1 >> [data-pkn]','Media docena');await p.fill('.pkw >> nth=1 >> [data-pkq]','6');await p.fill('.pkw >> nth=1 >> [data-pkv]','17000');
console.log('hints:',await p.$$eval('.pkh',x=>x.map(e=>e.innerText)));
await p.locator('.pkw >> nth=0').scrollIntoViewIfNeeded();await S(1);
// validation: incomplete row
await p.click('[data-a="pkAdd"]');await p.fill('.pkw >> nth=2 >> [data-pkn]','Caja');await p.click('[data-a="guardarProd"]');await W();console.log('msg:',await p.textContent('#p-msg'));
await p.click('.pkw >> nth=2 >> [data-a="pkDel"]');await p.click('[data-a="guardarProd"]');await W();
const prod=await p.evaluate(()=>LKT.state?null:null);
console.log('inv row:',await p.evaluate(()=>[...document.querySelectorAll('#main .row')].map(r=>r.innerText.replace(/\n/g,' ')).join(' || ')));
// sell 13 units => 1 paca + 1 und = 35000 ; 19 => paca + media + 1 = 52000
await p.click('[data-tab="caja"]');await p.click('[data-a="venta"] >> nth=0');await W();
console.log('plist:',await p.textContent('.pb'));
for(let i=0;i<13;i++)await p.click('.pb >> text=Gaseosa');
console.log('tot13',await p.textContent('#v-tot'));console.log('cart:',await p.textContent('.cart'));
await p.click('[data-vpk="0"][data-q="6"]');await W();console.log('tot19',await p.textContent('#v-tot'));await S(2);
await p.click('[data-vq="0"][data-d="-1"]');await W();console.log('tot18',await p.textContent('#v-tot'));
await p.click('[data-vpaga="100000"]');await p.click('[data-a="guardarVenta"]');await W(600);
const v=await p.evaluate(()=>{const s=document.body.innerText;return s.match(/Venta de \$[\d.]+/)?.[0]});console.log('snack',v);
await p.click('#snack-b');await W(600);await p.waitForSelector('#sh [data-a="shTxt"]');await S(3);await p.click('#sh [data-a="shTxt"]');await W(800);if(!p.url().includes('/tienda/')){await p.goBack();await W(1500)}
console.log('WA:\n'+WA[WA.length-1].split('text=')[1].slice(0,700));
// stock after: 40-18=22
await p.click('[data-tab="inv"]');await W();console.log('inv after:',await p.evaluate(()=>[...document.querySelectorAll('#main .row')].map(r=>r.innerText.replace(/\n/g,' ')).join(' || ')));
// edit product shows packs
await p.click('#main .row >> text=Gaseosa');await W();console.log('edit pk rows',await p.$$eval('.pkw [data-pkn]',x=>x.map(e=>e.value)));await S(4);await p.click('[data-a="cerrar"]');await W();
// reports
await p.click('[data-tab="rep"]').catch(()=>{});await W();console.log('rep:',await p.evaluate(()=>document.querySelector('#main').innerText.replace(/\n/g,' | ').slice(0,400)));
console.log('errs',errs);await b.close();srv.kill();})();
