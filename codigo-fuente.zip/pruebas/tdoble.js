// Un pago en el buzón con Lu-Ks abierta en dos dispositivos: debe guardarse una sola vez.
const {chromium}=require(process.env.PW||'playwright');const {spawn}=require('child_process');const fs=require('fs');
(async()=>{const srv=spawn('python3',['-m','http.server','8849'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},serviceWorkers:'block'});
await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x",projectId:"lu-ks-ia"}',contentType:'application/javascript'}));
const p=await ctx.newPage();await p.addInitScript(()=>{window.LKNV_OFF=1});await p.addInitScript(()=>localStorage.setItem('luks-lang','es'));
await p.goto('http://localhost:8849/');await p.waitForTimeout(2000);await p.click('[data-au="up"]');await p.fill('#au-n','Ana');await p.fill('#au-e','d@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await p.waitForTimeout(2500);
for(let i=0;i<8;i++){await p.evaluate(()=>{const s=document.querySelector('[data-ob="skip"]');if(s)s.click()});await p.waitForTimeout(200)}
const key=await p.evaluate(()=>window.LKAUTO.asegurar());await p.waitForTimeout(500);
await p.close();
// dejar un pago esperando en el buzón (como si llegara con la app cerrada)
const p0=await ctx.newPage();await p0.goto('http://localhost:8849/privacidad.html');
await p0.evaluate(k=>{const d=JSON.parse(localStorage.getItem('mockdb'));d['buzon/'+k+'/items/ap~$ 45.000~Panaderia~Visa~2026-11-01T10:00:00-05:00']={};localStorage.setItem('mockdb',JSON.stringify(d))},key);await p0.close();
const a=await ctx.newPage(),c=await ctx.newPage();await a.goto('http://localhost:8849/');await c.goto('http://localhost:8849/');await a.waitForTimeout(9000);
const n=await a.evaluate(()=>{const d=JSON.parse(localStorage.getItem('mockdb'));let n=0;Object.keys(d).forEach(k=>{if(/\/tabs\/Gastos__/.test(k)&&JSON.stringify(d[k]).indexOf('Panader')>=0)n+=(JSON.stringify(d[k]).match(/Panader/g)||[]).length});return n});
const queda=await a.evaluate(k=>Object.keys(JSON.parse(localStorage.getItem('mockdb'))).some(x=>x.indexOf('buzon/'+k+'/items/')===0),key);
console.log(n===1&&!queda?'  ✔':'  ✘','con dos dispositivos abiertos el pago se guarda una sola vez',JSON.stringify({veces:n,quedaEnBuzon:queda}));
await b.close();srv.kill();process.exit(n===1&&!queda?0:1)})();
