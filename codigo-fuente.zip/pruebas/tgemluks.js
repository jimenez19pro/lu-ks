const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8771'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({serviceWorkers:'block',viewport:{width:390,height:844}});
await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
let MODE='ok',CALLS=[];await ctx.addInitScript(()=>{window.__gTmo=2500;window.__gMax=9000;try{localStorage.setItem('luks-lang','es')}catch(e){}});
await ctx.route(/generativelanguage/,r=>{const mdl=r.request().url().split('/models/')[1].split(':')[0];CALLS.push(MODE+':'+mdl);if(MODE==='hang1'&&mdl==='gemini-flash-latest')return;if(MODE==='hangall')return;if(MODE==='net1'){MODE='ok';return r.abort('failed')}
r.fulfill({contentType:'application/json',body:JSON.stringify({candidates:[{content:{parts:[{text:'{"tipo":"gasto","monto":38000,"categoria":"Comida","comercio":"Almuerzo","cuenta":"","destino":""}'}]}}]})})});
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));const W=ms=>p.waitForTimeout(ms||300);
await p.goto('http://localhost:8771/');await W(2500);await p.click('[data-au="up"]');await p.fill('#au-n','Jose');await p.fill('#au-e','g@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(2500);
for(let i=0;i<8;i++){await p.evaluate(()=>{const s=document.querySelector('[data-ob="skip"]');if(s)s.click()});await W(250)}
const uid=await p.evaluate(()=>firebase.auth().currentUser.uid);
await p.evaluate(u=>{const b=firebase.firestore().batch();b.set({path:'users/'+u+'/tabs/Ajustes__0'},{t:'Ajustes',i:0,rows:JSON.stringify([['Clave','Valor'],['gemini','AIzaSyTEST_1234567890abcdefgh']])});return b.commit()},uid);await p.reload();await W(3000);
const ask=()=>p.evaluate(()=>claude.use("sample").then(sm=>sm("Almuerzo 38 mil")).then(r=>'OK '+r.text.slice(0,30),e=>'ERR '+(e&&e.code)));
for(const md of ['ok','hang1','net1','hangall']){MODE=md;CALLS=[];const t0=Date.now();const r=await ask();console.log(md,'->',r,'|',Math.round((Date.now()-t0)/1000)+'s |',CALLS.join(','))}
// volver a la app
MODE='hangall';CALLS=[];const pr=ask();await W(800);await p.evaluate(()=>{Object.defineProperty(document,'hidden',{configurable:true,get:()=>true});document.dispatchEvent(new Event('visibilitychange'))});await W(1500);await W(2000);MODE='ok';
await p.evaluate(()=>{Object.defineProperty(document,'hidden',{configurable:true,get:()=>false});document.dispatchEvent(new Event('visibilitychange'))});console.log('volver ->',await pr,'|',CALLS.join(','));
// UI: notas AI con todo colgado
MODE='hangall';for(let i=0;i<8;i++){await p.evaluate(()=>{const s=document.querySelector('[data-ob="skip"]');if(s)s.click()});await W(250)}await p.click('#add');await W(500);await p.click('#f-ai');await W(400);await p.fill('#n-t','Almuerzo 38 mil');await p.click('#nrun');await W(10500);console.log('UI nota:',await p.evaluate(()=>document.querySelector('#nsheet').innerText.split('\n').slice(-2).join(' | ')));
console.log('errs',errs);await b.close();srv.kill();})();
