const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8794'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch({args:['--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream']});
const run=async(mode)=>{const ctx=await b.newContext({viewport:{width:390,height:844},locale:'es-CO',serviceWorkers:'block',permissions:['camera']});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const LOG=[];const FAKE='window.__dims=[];globalThis.BarcodeDetector=class{constructor(o){window.__fmt=o&&o.formats}async detect(c){window.__dims.push(c.width+"x"+c.height);return window.__dims.length>=3?[{rawValue:"7702090000001",format:"ean_13"}]:[]}}';
await ctx.route(/barcode-detector/,r=>{const u=r.request().url();LOG.push(u.includes('jsdelivr')?'jsd':'unpkg');if(mode==='ok'&&u.includes('jsdelivr'))return r.fulfill({body:FAKE,contentType:'application/javascript'});if(mode==='unpkg'&&u.includes('unpkg'))return r.fulfill({body:FAKE,contentType:'application/javascript'});r.fulfill({status:404,body:''})});
await ctx.route(/@zxing/,r=>{LOG.push('zxing');r.fulfill({status:404,body:''})});
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept());const W=ms=>p.waitForTimeout(ms||300);
await p.goto('http://localhost:8794/tienda/');await W(1500);await p.click('[data-am="up"]');await p.fill('#au-e','t@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500);
await p.evaluate(()=>{const u=firebase.auth().currentUser.uid;const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()});await W(1200);
await p.click('[data-tab="inv"]');await p.click('[data-a="nuevoProd"]');await p.fill('#p-n','Gaseosa');await p.fill('#p-pv','3000');await p.fill('#p-st','10');await p.click('[data-a="guardarProd"]');await W();
await p.click('[data-a="nuevoProd"]');await p.click('[data-a="scanProd"]');await W(2500);
const cod=await p.inputValue('#p-cod').catch(()=>'');const msg=await p.textContent('#scan-m');const on=await p.evaluate(()=>document.querySelector('#scan').classList.contains('on'));
console.log(mode,'| loads:',LOG.join(','),'| cod:',cod,'| overlay on:',on,'| msg:',msg,'| dims:',await p.evaluate(()=>(window.__dims||[]).slice(0,4).join(' ')),'| fmt:',await p.evaluate(()=>JSON.stringify(window.__fmt||null)),'| errs',errs);
if(mode==='ok'){await p.screenshot({path:'cam1.png'})}
await ctx.close()};
await run('ok');await run('unpkg');await run('fail');
await b.close();srv.kill();})();
