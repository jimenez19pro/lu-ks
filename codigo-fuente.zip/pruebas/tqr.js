const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8806'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/unpkg/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const WA=[];await ctx.route(/wa\.me/,r=>{WA.push(decodeURIComponent(r.request().url()));r.fulfill({body:'wa',contentType:'text/html'})});
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept());const W=ms=>p.waitForTimeout(ms||300);const back=async()=>{if(!p.url().includes('/tienda/')){await p.goBack();await W(1500)}};
await p.goto('http://localhost:8806/tienda/');await W(1200);await p.click('[data-am="up"]');await p.fill('#au-e','q@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500);
await p.evaluate(()=>{const u=firebase.auth().currentUser.uid;const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()});await W(1200);
// sin datos: pantalla de aviso
await p.click('[data-a="venta"] >> nth=0');await p.click('[data-vm="rap"]');await p.fill('#v-rap','15000');await p.click('[data-vmet="tr"]');await p.click('[data-a="ventaQR"]');await W(300);console.log('sin datos:',(await p.textContent('#sh')).replace(/\s+/g,' ').slice(0,140));await p.click('#sh [data-a="qrVolver"]').catch(()=>{});await W(300);await p.click('#sh [data-a="cerrar"]').catch(()=>{});await W(300);
// configurar
await p.click('[data-a="ajustes"] >> nth=0');await W(300);await p.fill('#s-t','Tienda Don Pacho');await p.fill('#s-llave','@tiendadonpacho');await p.fill('#s-nq','3001234567');await p.fill('#s-tit','Francisco Pérez');await p.setInputFiles('#s-qr','qr-test.png');await W(1200);console.log('qr pv',!!(await p.$('#s-qrpv img')));await p.screenshot({path:'qr1.png',fullPage:false});await p.click('[data-a="guardarAj"]');await W(400);
console.log('conf',JSON.stringify(await p.evaluate(()=>{const c=LKT.D.conf.find(x=>x.id==='conf');const q=LKT.D.conf.find(x=>x.id==='qr');return{llave:c.llave,nequi:c.nequi,tit:c.titular,qr:q&&q.img.length}})));
// venta por transferencia con QR
await p.click('[data-a="venta"] >> nth=0');await p.click('[data-vm="rap"]');await p.fill('#v-rap','23500');await p.fill('#v-nota','Mercado');await p.click('[data-vmet="tr"]');await p.click('[data-a="ventaQR"]');await W(400);await p.screenshot({path:'qr2.png'});
await p.click('#sh [data-a="qrPagado"]');await W(600);console.log('venta',JSON.stringify(await p.evaluate(()=>LKT.D.venta.map(v=>[v.total,v.metodo,v.nota]))));
// fiado + QR + abono
await p.click('[data-a="fiar"] >> nth=0');await p.click('[data-vm="rap"]');await p.fill('#v-rap','40000');await p.selectOption('#v-cli','__new');await p.fill('#v-cn','Doña Marta');await p.fill('#v-ct','3005556677');await p.click('[data-a="guardarVenta"]');await W(500);
await p.click('[data-tab="fiados"]');await p.click('[data-a="cli"]');await W();await p.click('#sh [data-a="cliQR"]');await W(400);await p.screenshot({path:'qr3.png'});await p.click('#sh [data-a="qrPagado"]');await W(500);console.log('abono form',await p.inputValue('#a-m'),await p.evaluate(()=>document.querySelector('[data-amet][aria-pressed=true]').dataset.amet));
await p.fill('#a-m','10000');await p.click('[data-a="guardarAbono"]');await W(500);console.log('saldo',await p.evaluate(()=>LKT.D.fmov.map(x=>x.tipo+':'+x.monto+':'+x.metodo)));
await p.click('#sh [data-a="cerrar"]').catch(()=>{});await W(300);await p.click('[data-tab="fiados"]');await W();
// cobro texto incluye llave
await p.click('[data-a="cli"]');await W();await p.click('#sh [data-a="cliQR"]');await W(300);await p.click('#sh [data-a="qrWa"]');await W(800);console.log('WA pago:\n'+WA[WA.length-1]);await back();await p.click('[data-a="cli"]');await W();await p.click('#sh [data-a="wa"]');await W(500);await p.click('#sh [data-a="shTxt"]');await W(800);console.log('COBRO:\n'+WA[WA.length-1]);
console.log('errs',errs);await b.close();srv.kill()})();
