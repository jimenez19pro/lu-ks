const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8777'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},colorScheme:process.argv[2]||'light',locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error')errs.push('c:'+m.text())});p.on('dialog',d=>d.accept(d.type()==='prompt'?(d.message().includes('BORRAR')?'BORRAR':'30000'):undefined));
const S=async n=>{await p.waitForTimeout(250);await p.screenshot({path:'tt'+n+'.png'})};const T=()=>p.evaluate(()=>document.body.innerText.replace(/\n+/g,' | ').slice(0,600));
await p.goto('http://localhost:8777/tienda/');await p.waitForTimeout(1500);await S(0);
await p.click('[data-am="up"]');await p.fill('#au-e','t@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await p.waitForTimeout(1500);await p.evaluate(()=>{const u=firebase.auth().currentUser.uid;const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()});await p.waitForTimeout(1200);await S(1);
// ajustes
await p.click('[data-a="ajustes"] >> nth=0');await p.fill('#s-t','Tienda Don Pacho');await p.fill('#s-b','50000');await p.click('[data-a="guardarAj"]');await p.waitForTimeout(300);
// productos
await p.click('[data-tab="inv"]');for(const [n,pv,pc,st,mi] of [['Arroz Diana 500 g','3200','2600','20','5'],['Gaseosa 400 ml','2500','1700','4','6'],['Pan tajado','6500','5000','10','2']]){await p.click('[data-a="nuevoProd"]');await p.fill('#p-n',n);await p.fill('#p-pv',pv);await p.fill('#p-pc',pc);await p.fill('#p-st',st);await p.fill('#p-min',mi);await p.click('[data-a="guardarProd"]');await p.waitForTimeout(200)}
await S(2);
// venta con productos y vuelto
await p.click('[data-tab="caja"]');await p.click('[data-a="venta"] >> nth=0');await p.waitForTimeout(300);await p.click('.pb >> text=Arroz');await p.click('.pb >> text=Arroz');await p.click('.pb >> text=Gaseosa');await p.fill('#v-paga','10000');await S(3);await p.click('[data-a="guardarVenta"]');await p.waitForTimeout(400);
// venta rápida transferencia
await p.click('[data-a="venta"] >> nth=0');await p.click('[data-vm="rap"]');await p.fill('#v-rap','15000');await p.click('[data-vmet="tr"]');await p.click('[data-a="guardarVenta"]');await p.waitForTimeout(300);
// fiado cliente nuevo
await p.click('[data-a="fiar"] >> nth=0');await p.click('.pb >> text=Pan');await p.selectOption('#v-cli','__new');await p.fill('#v-cn','Doña Marta');await p.fill('#v-ct','3001234567');await S(4);await p.click('[data-a="guardarVenta"]');await p.waitForTimeout(300);
// gasto efectivo
await p.click('[data-a="gasto"] >> nth=0');await p.fill('#g-m','8000');await p.click('[data-gcat="trans"]');await p.fill('#g-n','Domicilio');await p.click('[data-a="guardarGasto"]');await p.waitForTimeout(300);
await S(5);console.log('caja:',await T());
// fiados: abono
await p.click('[data-tab="fiados"]');await p.waitForTimeout(200);await S(6);await p.click('[data-a="cli"]');await p.waitForTimeout(200);await p.click("#sh [data-a=abono]");await p.fill('#a-m','3000');await p.click('[data-a="guardarAbono"]');await p.waitForTimeout(300);await S(7);
await p.click('[data-a="cerrar"]');
// proveedor
await p.click('[data-tab="gastos"]');await p.click('[data-gv="prov"]');await p.click('[data-a="nuevoProv"]');await p.fill('#v-n','Distribuidora El Sol');await p.selectOption('#v-d','1');await p.click('[data-a="guardarProv"]');await p.waitForTimeout(200);await p.click("#sh [data-a=pmov][data-t=compra]");await p.fill('#m-m','120000');await p.click('[data-a="guardarPmov"]');await p.waitForTimeout(200);await p.click("#sh [data-a=pmov][data-t=pago]");await p.fill('#m-m','20000');await p.click('[data-a="guardarPmov"]');await p.waitForTimeout(300);await S(8);await p.click('[data-a="cerrar"]');await p.waitForTimeout(200);await S(9);
// cierre
await p.click('[data-tab="caja"]');await p.click('[data-a="cierre"]');await p.waitForTimeout(200);await p.fill('#k-c','48000');await S(10);await p.click("[data-a=guardarCierre]");await p.waitForTimeout(400);await S("13");console.log("resumen:",await p.evaluate(()=>document.querySelector("#sh .card").innerText));await p.click("#sh [data-a=cerrar]");await p.waitForTimeout(300);
console.log('esperado',await p.evaluate(()=>JSON.stringify(LKT.esperado(new Date().toISOString().slice(0,10)).total)));
await p.click('[data-tab="rep"]');await p.waitForTimeout(200);await S(11);console.log('rep:',await T());
await p.click('[data-tab="inv"]');await p.waitForTimeout(200);await S(12);
await p.reload();await p.waitForTimeout(1800);console.log('reload:',await p.evaluate(()=>LKT.D.venta.length+' ventas '+LKT.D.prod.map(x=>x.n+':'+x.st).join(',')));
console.log('errs',errs);await b.close();srv.kill()})();
