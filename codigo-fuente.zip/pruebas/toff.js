// Escáner sin internet: la app guarda el lector en el celular (service worker) y funciona offline.
const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8797'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch({args:['--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream']});
const ctx=await b.newContext({viewport:{width:390,height:844},locale:'es-CO',serviceWorkers:'allow',permissions:['camera']});
const LOG=[];const H={'access-control-allow-origin':'*'};
const FAKE='window.__det=0;globalThis.BarcodeDetector=class{constructor(){fetch("https://fastly.jsdelivr.net/npm/zxing-wasm@2.2.4/dist/reader/zxing_reader.wasm").then(r=>r.arrayBuffer()).then(b=>{window.__wasm=b.byteLength}).catch(e=>{window.__wasm="ERR "+e})}async detect(c){window.__det++;return window.__det>=3?[{rawValue:"7702090000001"}]:[]}}';
await ctx.route(/fonts\.g/,r=>r.abort());
await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript',headers:H}));
await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript',headers:H}));
await ctx.route(/barcode-detector@3\.0\.8/,r=>{LOG.push('red:polyfill');r.fulfill({body:FAKE,contentType:'application/javascript',headers:H})});
await ctx.route(/zxing_reader\.wasm/,r=>{LOG.push('red:wasm');r.fulfill({body:Buffer.alloc(4096,1),contentType:'application/wasm',headers:H})});
await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept());const W=ms=>p.waitForTimeout(ms||300);
await p.goto('http://localhost:8797/tienda/');await W(4000);
const sw=await p.evaluate(async()=>{const r=await navigator.serviceWorker.getRegistration();return r&&r.active?r.active.state:'none'});
const cached=await p.evaluate(async()=>{const ks=await caches.keys();const out={};for(const k of ks){const c=await caches.open(k);out[k]=(await c.keys()).map(r=>r.url.replace(/^https?:\/\//,'').slice(0,60))}return out});
console.log('SW:',sw,'| guardado:',JSON.stringify(cached));
console.log('descargas con internet:',LOG.join(','));LOG.length=0;
// sin internet
await ctx.setOffline(true);
await p.evaluate(()=>{delete window.BarcodeDetector;document.querySelectorAll('script[src*="barcode-detector"]').forEach(s=>s.remove())});
const r=await p.evaluate(async()=>{try{const a=await fetch('https://cdn.jsdelivr.net/npm/barcode-detector@3.0.8/dist/iife/polyfill.min.js');const b=await fetch('https://fastly.jsdelivr.net/npm/zxing-wasm@2.2.4/dist/reader/zxing_reader.wasm');return 'polyfill '+a.status+' ('+(await a.text()).length+' b) · wasm '+b.status+' ('+(await b.arrayBuffer()).byteLength+' b)'}catch(e){return 'ERR '+e}});
console.log('sin internet desde el celular:',r,'| pedidos a la red:',LOG.length);
console.log('errs',errs);await b.close();srv.kill()})();
