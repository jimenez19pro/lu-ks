// Prueba de los avisos que programa la app (recordatorios.js → armarAvisos)
// con los pagos que manda la web (snaps/rem.json de tinicio.js).
const fs=require('fs');const APPDIR=process.env.LUKSAPP||'../lu-ks-app';const SN=process.env.SNAPS||'snaps';
let src=fs.readFileSync(APPDIR+'/recordatorios.js','utf8');
src=src.replace(/^import .*$/mg,'').replace(/Notifications\.setNotificationHandler\(\{[\s\S]*?\n\}\);/,'').replace(/^export /mg,'');
const mod={};new Function('mod',src+'\nmod.armarAvisos=armarAvisos;mod.plata=plata;')(mod);
let ok=0,bad=0;const CK=(n,c,i)=>{c?ok++:bad++;console.log(c?'  ✔':'  ✘',n,i===undefined?'':i)};
CK('formato de plata',mod.plata(1234567)==='$1.234.567'&&mod.plata(0)==='$0'&&mod.plata(-45000)==='$45.000',mod.plata(1234567));
const R=JSON.parse(fs.readFileSync(SN+'/rem.json','utf8'));
const ahora=new Date();ahora.setHours(10,0,0,0);
const A=mod.armarAvisos(R.items,{hide:false,lang:'es'},ahora);
A.slice(0,8).forEach(a=>console.log('     ',a.cuando.toLocaleString('es-CO'),'·',a.title,'·',a.body));
CK('hay avisos',A.length>0,A.length+' avisos');
CK('todos en el futuro',A.every(a=>a.cuando>ahora));
CK('ordenados por fecha',A.every((a,i)=>!i||A[i-1].cuando<=a.cuando));
CK('máximo 60',A.length<=60);
CK('ids únicos',new Set(A.map(a=>a.id)).size===A.length);
const nf=A.find(a=>/Hoy pagas Netflix/.test(a.title));CK('Netflix: aviso el día a las 8:00 con monto',nf&&nf.cuando.getHours()===8&&/\$45\.000/.test(nf.body),nf&&nf.title+' '+nf.body);
const nf0=A.find(a=>/Mañana pagas Netflix/.test(a.title));CK('Netflix: aviso la víspera ya pasó si es mañana (se omite o es 19:00 de hoy)',!nf0||nf0.cuando.getHours()===19,nf0&&nf0.cuando.toString());
CK('cuota con número',A.some(a=>/cuota 3 de 12 de Celular/.test(a.title)),(A.find(a=>/cuota/.test(a.title))||{}).title);
CK('garantía 30 y 7 días y el día',['30 días','7 días','Hoy vence'].every(k=>A.some(a=>a.title.indexOf(k)>=0&&/Nevera/.test(a.title))));
CK('tarjeta de crédito',A.some(a=>/tarjeta Nu Colombia/.test(a.title)));
const H=mod.armarAvisos(R.items,{hide:true,lang:'es'},ahora);CK('montos ocultos si el ojito está cerrado',H.every(a=>!/\$\d/.test(a.title+a.body)));
const E=mod.armarAvisos(R.items,{hide:false,lang:'en'},ahora);CK('en inglés',E.some(a=>/Today you pay Netflix/.test(a.title)),(E[0]||{}).title);
const tarde=new Date(ahora);tarde.setHours(23,0);const T2=mod.armarAvisos([{k:'rec',id:'x',n:'Hoy',amt:1,date:tarde.getFullYear()+'-'+('0'+(tarde.getMonth()+1)).slice(-2)+'-'+('0'+tarde.getDate()).slice(-2)}],{},tarde);CK('no programa avisos de horas ya pasadas',T2.length===0);
console.log('\n'+ok+' bien, '+bad+' mal');process.exit(bad?1:0);
