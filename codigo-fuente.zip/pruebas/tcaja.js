const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8795'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch({args:['--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream']});
const ctx=await b.newContext({viewport:{width:390,height:844},locale:'es-CO',serviceWorkers:'block',permissions:['camera'],colorScheme:process.argv[2]||'light'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
await ctx.route(/openfoodfacts/,r=>r.fulfill({contentType:'application/json',body:'{"status":0}'}));
const FAKE='window.__cur=null;globalThis.BarcodeDetector=class{async detect(c){await new Promise(r=>setTimeout(r,15));return window.__cur?[{rawValue:window.__cur}]:[]}}';
await ctx.route(/barcode-detector/,r=>r.fulfill({body:FAKE,contentType:'application/javascript'}));
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept());const W=ms=>p.waitForTimeout(ms||300);
const cur=c=>p.evaluate(c=>{window.__cur=c},c);const cart=()=>p.evaluate(()=>document.querySelector('#scan-last').innerText+' || '+document.querySelector('#scan-tot').innerText);
await p.goto('http://localhost:8795/tienda/');await W(1500);await p.click('[data-am="up"]');await p.fill('#au-e','t@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500);
await p.evaluate(()=>{const u=firebase.auth().currentUser.uid;const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()});await W(1200);
console.log('btn before codes:',await p.$('[data-a="ventaCam"]')!==null);
await p.click('[data-tab="inv"]');for(const [n,pv,st,cod] of [['Gaseosa 400 ml','3000','20','111111111111'],['Papas 25 g','2000','10','222222222222']]){await p.click('[data-a="nuevoProd"]');await p.fill('#p-n',n);await p.fill('#p-pv',pv);await p.fill('#p-st',st);await p.fill('#p-cod',cod);await p.click('[data-a="guardarProd"]');await W(200)}
await p.click('[data-tab="caja"]');await W();console.log('btn after codes:',await p.$('[data-a="ventaCam"]')!==null);await p.screenshot({path:'cj0.png'});
await p.click('[data-a="ventaCam"]');await W(1500);console.log('overlay:',await p.evaluate(()=>document.querySelector('#scan').classList.contains('on')),'|',await cart());
await cur('111111111111');await W(1500);console.log('held 1.5s:',await cart());
await cur(null);await W(800);await cur('111111111111');await W(1000);console.log('2nd gaseosa:',await cart());await p.screenshot({path:'cj1.png'});
await cur('222222222222');await W(1000);console.log('papas:',await cart());
await cur(null);await p.click('#scan-undo');await W(300);console.log('undo:',await cart());
await cur('222222222222');await W(1000);await cur(null);await W(700);await cur('222222222222');await W(1000);console.log('2 papas:',await cart());
// manual typed code
await cur(null);await p.fill('#scan-in','111111111111');await p.click('#scan-ok');await W(300);console.log('typed:',await cart());await p.screenshot({path:'cj2.png'});
await p.click('#scan-done');await W(400);console.log('after cobrar overlay:',await p.evaluate(()=>document.querySelector('#scan').classList.contains('on')),'| tot',await p.textContent('#v-tot'),'| cart',await p.evaluate(()=>document.querySelector('.cart').innerText.replace(/\n/g,' ')));await p.screenshot({path:'cj3.png'});
// reopen camera from sale sheet and scan unknown
await p.click('[data-a="scanVenta"]');await W(1200);await cur('999999999999');await W(1200);console.log('unknown -> editor:',await p.evaluate(()=>!!document.querySelector('#p-n')),await p.inputValue('#p-cod').catch(()=>'-'),'| overlay',await p.evaluate(()=>document.querySelector('#scan').classList.contains('on')));
await p.fill('#p-n','Chicle');await p.fill('#p-pv','500');await p.fill('#p-st','50');await p.click('[data-a="guardarProd"]');await W(500);console.log('after create tot',await p.textContent('#v-tot'));
await p.click('[data-a="guardarVenta"]');await W(500);console.log('stock',await p.evaluate(()=>LKT.D.prod.map(x=>x.n+':'+x.st).join(', ')));
console.log('errs',errs);await b.close();srv.kill();})();
