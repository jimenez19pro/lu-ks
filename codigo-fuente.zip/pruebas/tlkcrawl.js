const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8811'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},deviceScaleFactor:1,locale:'es-CO',serviceWorkers:'block',colorScheme:process.argv[2]||'dark'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
let CUR='inicio';const DLG=[];await ctx.route(/wa\.me|mailto|whatsapp/,r=>r.fulfill({body:'x'}));const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push('PAGEERROR '+CUR+' :: '+e.message));p.on('console',m=>{if(m.type()==='error'&&!/ERR_FAILED|Failed to load resource/.test(m.text()))errs.push('CONSOLE '+CUR+' :: '+m.text().slice(0,200))});p.on('dialog',d=>{DLG.push(CUR+' :: '+d.type()+': '+d.message().slice(0,80));d.dismiss()});await p.addInitScript(()=>{localStorage.setItem('luks-lang','es')});const W=ms=>p.waitForTimeout(ms||400);const O='/tmp/claude-0/-home-claude/386cd89e-f2f2-549f-a9dc-a0da83d3d90b/scratchpad/crawl/';fs.mkdirSync(O,{recursive:true});
await p.goto('http://localhost:8811/');await W(3000);await p.click('[data-au="up"]');await p.fill('#au-n','Jose');await p.fill('#au-e','jose@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(2500);
for(let i=0;i<8;i++){await p.evaluate(()=>{const s=document.querySelector('[data-ob="skip"]');if(s)s.click()});await W(250)}
await p.evaluate(()=>{const mk=o=>{AE=-1;AF=Object.assign(afNew(),o);saveAcc2()};mk({tipo:"debito",banco:"Bancolombia",ini:"2850000",pri:true});mk({tipo:"credito",banco:"Nu Colombia",color:CLR[7],cupo:"3000000",ini:"0"});mk({tipo:"efectivo",name:"Billetera",ini:"180000"})});await W(800);
await p.evaluate(()=>{const now=new Date();const ds=(m,d)=>{const x=new Date(now.getFullYear(),now.getMonth()-m,d);return x.getFullYear()+'-'+String(x.getMonth()+1).padStart(2,'0')+'-'+String(x.getDate()).padStart(2,'0')};
const base=[[2,38900,'Mercado D1','comida'],[3,12000,'Taxi','transp'],[5,89000,'Internet','serv'],[6,45000,'Cine','ocio'],[1,850000,'Arriendo','hogar'],[8,26500,'Almuerzo','comida'],[9,60000,'Farmacia','salud'],[12,120000,'Ropa','ropa'],[14,64000,'Mercado','comida'],[16,18000,'Uber','transp'],[18,230000,'Cuota tarjeta','deuda'],[19,35000,'Domicilio','comida']];
const f=[1.15,1.05,1.22,0.98,1.1];
for(let m=5;m>=1;m--){base.forEach(([d,v,n,c])=>{PFDATE=ds(m,d);TP='out';addRow(Math.round(v*f[m-1]/100)*100,n,'Bancolombia',c,'')});PFDATE=ds(m,1);TP='in';addRow(3200000,'Sueldo','Bancolombia','','')}
const today=now.getDate();base.filter(x=>x[0]<=today).forEach(([d,v,n,c])=>{PFDATE=ds(0,d);TP='out';addRow(v,n,c==='comida'?'Nu Colombia':'Bancolombia',c,'')});PFDATE=ds(0,1);TP='in';addRow(3200000,'Sueldo','Bancolombia','','')});await W(2500);
await p.evaluate(()=>{[['comida',700000],['hogar',900000],['transp',150000],['ocio',120000],['salud',100000]].forEach(([k,v])=>{BK=k;document.getElementById('b-amt').value=String(v);saveBud()})});await W(800);
await p.evaluate(()=>{GE=-1;document.getElementById('g-n').value='Viaje a Cartagena';document.getElementById('g-t').value='2500000';document.getElementById('g-s').value='1150000';document.getElementById('g-a').value='';document.getElementById('g-d').value='';saveGoal()});await W(800);

await p.evaluate(()=>{document.querySelectorAll('.sheet.on').forEach(s=>s.classList.remove('on'));window.scrollTo(0,0)});await W(500);
const SKIP=/eliminar|borrar|cerrar sesi|elimina|importar|instalar|notificaci|salir|delete|sign out|idioma|language|invita|opini|privacidad|verifica|resetear|restablecer/i;
const close=async()=>{await p.evaluate(()=>{document.querySelectorAll('.on').forEach(x=>{const cs=getComputedStyle(x);if(cs.position==='fixed'&&x.tagName!=='NAV'&&!x.classList.contains('tab'))x.classList.remove('on')});document.querySelectorAll('.lk-ov,.story,#story,.gar-full,.lk-story,#lkst').forEach(x=>{try{x.remove()}catch(e){}});document.body.style.overflow=''});if(!/localhost:8811\/(\?.*)?(#.*)?$/.test(p.url())){await p.goto('http://localhost:8811/');await W(2500)}};
const list=sel=>p.evaluate(sel=>{const out=[];document.querySelectorAll(sel).forEach((e,i)=>{const r=e.getBoundingClientRect();if(r.width>0&&r.height>0&&getComputedStyle(e).visibility!=='hidden'){e.setAttribute('data-crawl',String(i));out.push({i,t:(e.innerText||e.getAttribute('aria-label')||e.id||'').replace(/\s+/g,' ').trim().slice(0,40)})}});return out},sel);
const tabs=[['home',null],['home','fin'],['home','aho'],['tx',null],['rep',null],['con',null]];
let clicks=0,LAST='';
for(const [t,hv] of tabs){
  const goTab=async()=>{await close();await p.click('[data-t="'+t+'"]',{timeout:4000}).catch(async()=>{CUR='BLOQUEO al volver a '+t;errs.push('BLOQUEADO: algo tapa la barra tras '+LAST);await p.goto('http://localhost:8811/');await W(2500);await p.click('[data-t="'+t+'"]').catch(()=>{})});await W(700);if(hv){await p.click('[data-hv="'+hv+'"]').catch(()=>{});await W(600)}};
  await goTab();
  const items=await list('#app button,#app [data-lk],#app .row[data-id],#app .tile,#app a[href]');
  console.log('TAB',t,hv||'','botones',items.length);
  for(const it of items){
    if(SKIP.test(it.t))continue;if(it.t==='')it.t='(sin texto #'+it.i+')';
    await goTab();await list('#app button,#app [data-lk],#app .row[data-id],#app .tile,#app a[href]');
    const el=await p.$('#app [data-crawl="'+it.i+'"]');if(!el)continue;
    CUR=t+(hv?'/'+hv:'')+' > '+it.t;LAST=CUR;
    try{await el.scrollIntoViewIfNeeded();await el.click({timeout:2000});clicks++}catch(e){continue}
    await W(450);
    // segundo nivel: botones dentro de la hoja abierta
    const sh=await p.evaluate(()=>{const s=[...document.querySelectorAll('.sheet.on')].pop();return s?s.id:null});
    if(sh){const inner=await list('#'+sh+' button:not(#cancel):not(#nclose),#'+sh+' .pk,#'+sh+' [data-lk]');
      for(const jt of inner.slice(0,25)){if(SKIP.test(jt.t)||/cancelar|cerrar|guardar|crear|^✕$/i.test(jt.t))continue;
        const e2=await p.$('#'+sh+' [data-crawl="'+jt.i+'"]');if(!e2)continue;CUR=t+' > '+it.t+' > '+jt.t;
        try{await e2.click({timeout:1500});clicks++}catch(e){}await W(250);
        const still=await p.evaluate(id=>{const s=document.getElementById(id);return s&&s.classList.contains('on')},sh);if(!still)break}}
  }
}
console.log('clics',clicks);console.log('ERRORES',errs.length);errs.forEach(e=>console.log(' ',e));console.log('DIALOGOS',DLG.length);DLG.slice(0,30).forEach(d=>console.log(' ',d));
await b.close();srv.kill()})();