const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8818'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},deviceScaleFactor:2,locale:'es-CO',serviceWorkers:'block',colorScheme:process.argv[2]||'dark'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));await ctx.route(/wa\.me/,r=>r.fulfill({body:'wa'}));
let CUR='inicio';const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push('PAGEERROR '+CUR+' :: '+e.message));p.on('console',m=>{if(m.type()==='error'&&!/ERR_FAILED|Failed to load/.test(m.text()))errs.push('CONSOLE '+CUR+' :: '+m.text().slice(0,200))});p.on('dialog',d=>d.dismiss());const W=ms=>p.waitForTimeout(ms||300);const D='/tmp/claude-0/-home-claude/386cd89e-f2f2-549f-a9dc-a0da83d3d90b/scratchpad/rev/';fs.mkdirSync(D,{recursive:true});
let n=0;const S=async name=>{await W(350);n++;await p.screenshot({path:D+String(n).padStart(2,'0')+'-'+name+'.png'})};
const SS=async name=>{await W(350);n++;const h=await p.evaluate(()=>{const s=document.querySelector('#sh');return s.classList.contains('on')?s.scrollHeight:0});await p.screenshot({path:D+String(n).padStart(2,'0')+'-'+name+'.png'});if(h>800){await p.evaluate(()=>{document.querySelector('#sh').scrollTop=99999});await W(200);await p.screenshot({path:D+String(n).padStart(2,'0')+'-'+name+'-b.png'});await p.evaluate(()=>{document.querySelector('#sh').scrollTop=0})}};
const X=async()=>{await p.click('#ov',{position:{x:20,y:20}}).catch(()=>{});await W(350)};
await p.goto('http://localhost:8818/tienda/');await W(3000);await p.click('[data-am="up"]');await p.fill('#au-e','luis@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500);
const uid=await p.evaluate(()=>firebase.auth().currentUser.uid);
await p.evaluate(u=>{const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});
const P=[['Aceite clarita 220ml',3200,2600],['Arroz Diana 500 g',2600,2200],['Azúcar Manuelita 1 kg',4500,3900],['Gaseosa Coca-Cola 400 ml',3000,2200],['Leche Alquería 1 L',4800,4100],['Huevos AA x 30',16500,14000],['Pan tajado Bimbo',6500,5200],['Papas Margarita limón 25 g',2000,1500],['Chocoramo',2500,1900],['Jabón Rey',2800,2200],['Café Sello Rojo 250 g',9800,8300],['Panela',3000,2400],['Atún Van Camps',6900,5800],['Galletas Festival',1800,1300],['Detergente Fab 500 g',5600,4700],['Papel higiénico Familia x4',8900,7600],['Cerveza Águila lata',3500,2700],['Agua Cristal 600 ml',1800,1200],['Pony Malta 330',2500,1900],['Salchichas Zenú x 10',9500,8100]];
const PV=[['Coca cola','3001112233'],['Deditos','3002223344'],['Alpina','3003334455']];PV.forEach((v,i)=>b.set({path:'users/'+u+'/t_prov/pv'+i},{n:v[0],tel:v[1],dia:''}));
for(let i=0;i<62;i++){const q=P[i%P.length];b.set({path:'users/'+u+'/t_prod/p'+i},{n:i<P.length?q[0]:q[0]+' '+(Math.floor(i/P.length)+1),pv:q[1],pc:q[2],st:i%7===0?2:10+i%15,min:i%7===0?5:0,cod:String(7700000000000+i),u:'und',prov:'pv'+(i%3),ts:Date.now()-i*1000})}
const C=['Doña Marta','Don Jorge','Carlos Pérez','La vecina del 5','Andrea'];C.forEach((c,i)=>{b.set({path:'users/'+u+'/t_cli/c'+i},{n:c,tel:'30012345'+i+i,cupo:0});b.set({path:'users/'+u+'/t_fmov/f'+i},{cli:'c'+i,tipo:'cargo',monto:5000*(i+1),fecha:'2026-10-0'+(i+1),metodo:'fi',nota:'Compra',ts:Date.now()-86400000*(20-i)})});
b.set({path:'users/'+u+'/t_conf/conf'},{tienda:'Tienda de Luis',base:50000,margen:20,waDueno:'3137904093'});return b.commit()},uid);await p.reload();await W(3000);
// ventas de hoy
for(const k of [0,3,5]){await p.click('[data-a="venta"] >> nth=0');await W();await p.click('.pb >> nth='+k);await p.click('[data-a="guardarVenta"]');await W(300)}
await p.click('[data-a="gasto"] >> nth=0');await W();await p.fill('#g-m','12000');await p.fill('#g-n','Bolsas');await p.click('[data-a="guardarGasto"]');await W(500);

const SKIPT=/eliminar|borrar|cerrar sesi|salir|anular|quitar|desvincular|borrar todos/i,SKIPA=/borrar|del$|Del|salir|eliminar|anular|reset|Cam|scan|Scan|factura|fx|cargar|qrQuitar|invitar/;
const close=async()=>{if(!/localhost:8818\/tienda\//.test(p.url())){await p.goto('http://localhost:8818/tienda/');await W(3500)}await p.evaluate(()=>{const s=document.querySelector('#sh');if(s)s.classList.remove('on','kb');const o=document.querySelector('#ov');if(o)o.classList.remove('on');const sc=document.querySelector('#scan');if(sc)sc.classList.remove('on')})};
const list=sel=>p.evaluate(sel=>{const out=[];document.querySelectorAll(sel).forEach((e,i)=>{const r=e.getBoundingClientRect();if(r.width>0&&r.height>0){e.setAttribute('data-crawl',String(i));out.push({i,t:(e.innerText||e.getAttribute('aria-label')||'').replace(/\s+/g,' ').trim().slice(0,40),a:e.dataset.a||''})}});return out},sel);
const views=[['caja',null],['fiados',null],['inv',null],['gastos','gastos'],['gastos','prov'],['rep',null]];
let clicks=0;const SEL='#main [data-a],#main [data-tab]:not(nav *),#main .row,#main .chip,#main [data-gv],#main [data-f]';
for(const [t,gv] of views){
  const go=async()=>{await close();await p.click('nav [data-tab="'+t+'"]');await W(500);if(gv){await p.click('[data-gv="'+gv+'"]').catch(()=>{});await W(400)}};
  await go();const items=await list(SEL);console.log('VISTA',t,gv||'','botones',items.length);
  for(const it of items){
    if(SKIPT.test(it.t)||SKIPA.test(it.a))continue;
    await go();await list(SEL);const el=await p.$('#main [data-crawl="'+it.i+'"]');if(!el)continue;
    CUR=t+(gv?'/'+gv:'')+' > '+(it.t||it.a);
    try{await el.scrollIntoViewIfNeeded();await el.click({timeout:2000});clicks++}catch(e){continue}
    await W(400);
    if(!/localhost:8818\/tienda\//.test(p.url())){await close();continue}
    if(await p.evaluate(()=>{const s=document.querySelector('#sh');return !!(s&&s.classList.contains('on'))})){
      const inner=await list('#sh [data-a],#sh .chip,#sh .pb,#sh [data-vm],#sh [data-vmet]');
      for(const jt of inner.slice(0,25)){if(SKIPT.test(jt.t)||SKIPA.test(jt.a)||/^(cerrar|guardar|guardar[A-Z].*|turnoGo|turnoCerrar|guardarCierre)$/.test(jt.a))continue;
        const e2=await p.$('#sh [data-crawl="'+jt.i+'"]');if(!e2)continue;CUR=t+' > '+(it.t||it.a)+' > '+(jt.t||jt.a);
        try{await e2.click({timeout:1500});clicks++}catch(e){}await W(220);
        if(!/localhost:8818\/tienda\//.test(p.url())){await close();break}if(!(await p.evaluate(()=>{const s=document.querySelector('#sh');return !!(s&&s.classList.contains('on'))})))break}}
  }
}
console.log('clics',clicks);console.log('ERRORES',errs.length);errs.forEach(e=>console.log(' ',e));
await b.close();srv.kill()})();