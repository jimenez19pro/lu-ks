const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8794'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));const W=ms=>p.waitForTimeout(ms||300);
await p.goto('http://localhost:8794/tienda/');await W(1200);await p.click('[data-am="up"]');await p.fill('#au-e','f@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500);
await p.evaluate(()=>{const u=firebase.auth().currentUser.uid;const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()});await W(1200);
await p.click('[data-a="ajustes"] >> nth=0');await p.fill('#s-b','100000');await p.click('[data-a="guardarAj"]');await W();
await p.click('[data-a="venta"] >> nth=0');await p.click('[data-vm="rap"]');await p.fill('#v-rap','30000');await p.click('[data-a="guardarVenta"]');await W(400);
await p.click('[data-tab="gastos"]');await p.click('[data-a="gasto"]');await p.fill('#g-m','500000');await p.click('[data-gcat="arr"]');console.log('arr default met',await p.evaluate(()=>document.querySelector('[data-gmet][aria-pressed=true]').dataset.gmet));await p.screenshot({path:'fj1.png'});await p.click('[data-a="guardarGasto"]');await W();
await p.click('[data-a="gasto"]');await p.fill('#g-m','300000');await p.click('[data-gcat="emp"]');await p.click('[data-gmet="ef"]');await p.click('[data-a="guardarGasto"]');await W();
await p.click('[data-a="gasto"]');await p.fill('#g-m','5000');await p.click('[data-gcat="trans"]');console.log('trans default met',await p.evaluate(()=>document.querySelector('[data-gmet][aria-pressed=true]').dataset.gmet));await p.click('[data-a="guardarGasto"]');await W();await p.screenshot({path:'fj2.png'});
const f=await p.evaluate(()=>new Date().toISOString().slice(0,10));
console.log('resumen',JSON.stringify(await p.evaluate(f=>{const r=LKT.resumen(f,f);return{ventas:r.ventas,costo:Math.round(r.costo),gVar:r.gVar,gFij:r.gFij,ganancia:Math.round(r.ganancia),neta:Math.round(r.neta),caja:LKT.esperado(f).total}},f)));
await p.click('[data-tab="caja"]');await W();console.log('kpi:',await p.evaluate(()=>[...document.querySelectorAll('.kpi')].map(k=>k.innerText.replace(/\n/g,' ')).join(' | ')));await p.screenshot({path:'fj3.png'});
await p.click('[data-tab="rep"]');await W();await p.screenshot({path:'fj4.png'});console.log('rep:',(await p.textContent('#main')).replace(/\s+/g,' ').slice(0,330));
console.log('errs',errs);await b.close();srv.kill()})();
