const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8774'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},colorScheme:'light',locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('http://localhost:8774/');await p.waitForTimeout(3000);await p.click('[data-au="up"] >> nth=0');await p.fill('#au-n','Jose');await p.fill('#au-e','j@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await p.waitForTimeout(2000);await p.click('[data-ob="skip"]');await p.waitForTimeout(800);
await p.evaluate(()=>{tab='con';render()});await p.waitForTimeout(300);
await p.click('[data-acc="morado"]');await p.waitForTimeout(800);
console.log('ac',await p.evaluate(()=>getComputedStyle(document.documentElement).getPropertyValue('--ac')),await p.evaluate(()=>JSON.stringify(LKPUBT.Ajustes)));
const r=await p.$('[data-acc="morado"]');await r.scrollIntoViewIfNeeded();await p.screenshot({path:'col1.png'});
await p.evaluate(()=>{tab='home';render()});await p.waitForTimeout(500);await p.evaluate(()=>scrollTo(0,0));await p.screenshot({path:'col2.png'});
await p.click('[data-th="dark"]').catch(()=>{});await p.evaluate(()=>{document.documentElement.setAttribute('data-theme','dark')});await p.waitForTimeout(300);console.log('dark',await p.evaluate(()=>getComputedStyle(document.documentElement).getPropertyValue('--ac')));await p.screenshot({path:'col3.png'});
await p.reload();await p.waitForTimeout(3000);console.log('reload',await p.evaluate(()=>getComputedStyle(document.documentElement).getPropertyValue('--ac')));
console.log('errs',errs);await b.close();srv.kill()})();
