const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8767'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({serviceWorkers:'block',viewport:{width:390,height:844},colorScheme:'dark',acceptDownloads:true});const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
await p.goto('http://localhost:8767/');await p.waitForTimeout(3000);await p.click('[data-au="up"]');await p.fill('#au-n','Ana');await p.fill('#au-e','a@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');
await p.waitForTimeout(1800);console.log('onb shown',await p.evaluate(()=>!!document.getElementById('onb')));const shots=[];
for(let i=0;i<4;i++){await p.screenshot({path:'ob'+i+'.png'});await p.click('[data-ob="next"]');await p.waitForTimeout(450)}
await p.click('[data-obs="1"]');await p.fill('[data-obv="0"][data-k="s"]','50000');await p.fill('[data-obv="1"][data-k="s"]','120000');await p.click('[data-obs="6"]');await p.fill('[data-obv="6"][data-k="s"]','300000');await p.fill('[data-obv="6"][data-k="c"]','2000000');await p.screenshot({path:'ob4.png',fullPage:false});
await p.click('[data-ob="next"]');await p.waitForTimeout(400);await p.fill('[data-obb="comida"]','600000');await p.fill('[data-obb="transp"]','150000');await p.screenshot({path:'ob5.png'});
await p.click('[data-ob="next"]');await p.waitForTimeout(1200);await p.screenshot({path:'ob6.png'});
console.log('acc',await p.evaluate(()=>ACC.map(a=>a.n+':'+a.tipo+':'+a.ini+':'+a.cupo).join(' | ')),'bud',await p.evaluate(()=>budTot()),'onb flag',await p.evaluate(()=>JSON.stringify(LKPUBT.Ajustes)));
await p.reload();await p.waitForTimeout(4000);console.log('onb again?',await p.evaluate(()=>!!document.getElementById('onb')),'acc',await p.evaluate(()=>ACC.length));
await p.evaluate(()=>{TP='out';addRow(25000,'Almuerzo','Nequi','comida','')});await p.waitForTimeout(500);
await p.evaluate(()=>{tab='con';render()});const [dl]=await Promise.all([p.waitForEvent('download'),p.click('[data-pub="exp"]')]);const fp=await dl.path();const j=JSON.parse(fs.readFileSync(fp,'utf8'));console.log('export',dl.suggestedFilename(),Object.keys(j.tabs).map(k=>k+':'+j.tabs[k].length).join(','),'adj',JSON.stringify(j.cuentasSaldoActual.map(r=>r[0]+':'+r[2])));
fs.copyFileSync(fp,'exp-test.json');
await p.click('[data-pub="tour"]');await p.waitForTimeout(400);console.log('tour',await p.evaluate(()=>!!document.getElementById('onb')));
console.log('errs',errs);await b.close();srv.kill()})();
