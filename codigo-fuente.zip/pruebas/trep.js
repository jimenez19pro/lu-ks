// Prueba de Reportes nativo (espejo), editar con el formulario nativo y eliminar.
// Uso: desde la raíz, python3 build_pub.py, LUKSAPP=../lu-ks-app node pruebas/trep.js
const {chromium}=require(process.env.PW||'playwright');const {spawn}=require('child_process');const fs=require('fs');
const APPDIR=process.env.LUKSAPP||'../lu-ks-app';const OUT=process.env.SNAPS||'snaps';fs.mkdirSync(OUT,{recursive:true});
const src=fs.readFileSync(APPDIR+'/puente.js','utf8').replace(/^export function puente/m,'function puente')+'\nmodule.exports=puente;';
const m={exports:{}};new Function('module','exports',src)(m,m.exports);const BR=m.exports({version:'1.3.0',os:'ios',recordatorios:null,sinSplash:false,formNativo:true});
const DARK=process.env.DARK==='1';
(async()=>{
const srv=spawn('python3',['-m','http.server','8820'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},deviceScaleFactor:2,locale:'es-CO',serviceWorkers:'block',colorScheme:DARK?'dark':'light'});
await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept());
await p.addInitScript(()=>{if(!localStorage.getItem('luks-lang'))localStorage.setItem('luks-lang','es');window.__msgs=[];window.ReactNativeWebView={postMessage:m=>window.__msgs.push(JSON.parse(m))}});
await p.addInitScript(BR);
const W=ms=>p.waitForTimeout(ms||400);const G=(f,a)=>p.evaluate(f,a);let ok=0,bad=0;const CK=(n,c,i)=>{c?ok++:bad++;console.log(c?'  ✔':'  ✘',n,i===undefined?'':i)};
const last=t=>G(t=>{const s=window.__msgs.filter(x=>x.t===t);return s[s.length-1]||null},t);
const sheetsOff=()=>G(()=>document.querySelectorAll('.sheet.on').forEach(s=>s.classList.remove('on')));
await p.goto('http://localhost:8820/');await W(3000);
await p.click('[data-au="up"]');await p.fill('#au-n','Jose');await p.fill('#au-e','jose@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(2500);
for(let i=0;i<8;i++){await G(()=>{const s=document.querySelector('[data-ob="skip"]');if(s)s.click()});await W(250)}
await G(()=>{const mk=o=>{AE=-1;AF=Object.assign(afNew(),o);saveAcc2()};mk({tipo:"debito",banco:"Bancolombia",ini:"1000000",pri:true});mk({tipo:"efectivo",name:"Billetera",ini:"80000"})});await W(1500);
const hoy=await G(()=>iso(0));
const seed=[[52300,'Mercado D1','comida','Bancolombia',0],[8000,'Tinto','comida','Billetera',0],[6000,'Tinto','comida','Billetera',1],[12000,'Uber','transp','Bancolombia',1],[45000,'Netflix','ocio','Bancolombia',2],[120000,'Energía','serv','Bancolombia',3],[15000,'Rappi','comida','Bancolombia',4]];
for(const s of seed){await G(s=>window.__lkSave({tp:'out',a:s[0],mer:s[1],cat:s[2],sub:'',acc:s[3],dst:'',date:iso(s[4])}),s)}
await G(()=>window.__lkSave({tp:'in',a:2000000,mer:'Sueldo',cat:'',sub:'',acc:'Bancolombia',dst:'',date:iso(0)}));await W(2500);
// meses anteriores (para la tendencia y suscripciones)
await G(()=>{for(let k=1;k<=3;k++){const d=new Date();d.setMonth(d.getMonth()-k);d.setDate(10);const ds=d.toISOString().slice(0,10);tx.push({id:7000+k,date:ds,amt:300000+k*20000,mer:'Mercado mes '+k,acc:'Bancolombia',tipo:'out',cat:'comida'});tx.push({id:7100+k,date:ds,amt:45000,mer:'Netflix',acc:'Bancolombia',tipo:'out',cat:'ocio'})}render()});await W(800);
console.log('1. Reportes nativo');
await sheetsOff();await G(()=>{window.__msgs=[];window.__lkTap('nav .tab[data-t="rep"]')});await W(1500);
let s=await last('state');const R=s&&s.rep;
CK('estado: Reportes se muestra',s&&s.show===true&&s.kind==='rep'&&!!R,s&&JSON.stringify({show:s.show,kind:s.kind,tab:s.tab}));
const txt=(n,o=[])=>{if(!n)return o;if(n.k==='p')o.push(n.runs.map(r=>r.s||'').join(''));(n.ch||[]).forEach(c=>txt(c,o));return o};
const all=R?R.tree.flatMap(n=>txt(n)):[];const J=all.join(' | ');
['Reportes','Resumen','Saldo actual','Entradas','Salidas','Tendencia','Gastos hormiga','Suscripciones','Top comercios','Fijos vs. variables','Regla 50/30/20','Barras','Pastel','Chat financiero'].forEach(k=>CK('sección: '+k,J.indexOf(k)>=0));
const cnt=(n,f)=>!n?0:(f(n)?1:0)+(n.ch||[]).reduce((a,c)=>a+cnt(c,f),0);
const nsvg=R.tree.reduce((a,n)=>a+cnt(n,x=>x.k==='svg'),0);CK('gráficas en SVG (tendencia, barras, pastel)',nsvg>=3,nsvg);
const svgs=[];const fsvg=n=>{if(!n)return;if(n.k==='svg')svgs.push(n);(n.ch||[]).forEach(fsvg)};R.tree.forEach(fsvg);
CK('SVG sin <svg> anidados (el iPhone no los ubica)',svgs.every(x=>(x.x.match(/<svg/g)||[]).length===1),svgs.map(x=>(x.x.match(/<svg/g)||[]).length).join(','));
CK('SVG sin textos vacíos',svgs.every(x=>!/<text[^>]*><\/text>/.test(x.x)));
CK('botón redondo de enviar centrado',(()=>{const f=(n)=>{if(!n)return null;if(n.tap&&n.b&&n.b.w===44&&n.b.jc==='center'&&n.b.ai==='center')return n;for(const c of n.ch||[]){const r=f(c);if(r)return r}return null};return !!R.tree.map(f).find(Boolean)})());
CK('SVG sin var(--) ni style',svgs.every(x=>!/var\(--|style=|class=/.test(x.x)),svgs.map(x=>x.w+'x'+x.h).join(' '));
const taps=R.tree.reduce((a,n)=>a+cnt(n,x=>!!x.tap),0);CK('botones tocables',taps>=10,taps);
CK('campo del chat',R.tree.reduce((a,n)=>a+cnt(n,x=>x.k==='in'&&x.id==='ai-q'),0)===1);
CK('ancho de la pantalla',R.ancho>300&&R.ancho<=390,R.ancho);
fs.writeFileSync(OUT+'/rep'+(DARK?'-oscuro':'')+'.json',JSON.stringify(R));await p.screenshot({path:OUT+'/web-rep'+(DARK?'-oscuro':'')+'.png',fullPage:true});
// tocar un chip de gastos hormiga (mismo Reportes)
const find=(n,f)=>{if(!n)return null;if(f(n))return n;for(const c of n.ch||[]){const r=find(c,f);if(r)return r}return null};
const chip=R.tree.map(n=>find(n,x=>x.tap&&x.ch&&x.ch[0]&&x.ch[0].k==='p'&&/^\$50\.000$/.test(x.ch[0].runs.map(r=>r.s||'').join('')))).find(Boolean);
CK('chip "$50.000" con ruta',!!chip,chip&&chip.tap);
if(chip){await G(sel=>window.__lkTap(sel),chip.tap);await W(800);CK('el chip cambió el filtro de hormiga',(await G(()=>HU))===50000)}
const ex=R.tree.map(n=>find(n,x=>x.tap&&x.ch&&x.ch[0]&&x.ch[0].k==='p'&&x.ch[0].runs.map(r=>r.s||'').join('')==='Descargar')).find(Boolean);
await G(sel=>window.__lkTap(sel),ex.tap);await W(800);s=await last('state');
CK('Descargar (mismo Reportes)',s.kind==='rep'&&s.show&&s.rep.tree.flatMap(n=>txt(n)).join(' ').indexOf('Exportar movimientos')>=0);
const gen=s.rep.tree.map(n=>find(n,x=>x.id==='expgo')).find(Boolean);await G(sel=>window.__lkTap(sel),gen.tap);await W(800);s=await last('state');
const ta=s.rep.tree.map(n=>find(n,x=>x.k==='in'&&x.id==='exp-t')).find(Boolean);CK('CSV generado (texto para copiar)',ta&&/Mercado D1/.test(ta.v),ta&&ta.v.slice(0,60));
fs.writeFileSync(OUT+'/rep-exp.json',JSON.stringify(s.rep));
await G(()=>window.__lkTap('#app [data-rt="rep"]'));await W(800);
s=await last('state');const inp=s.rep.tree.map(n=>find(n,x=>x.k==='in'&&x.id==='ai-q')).find(Boolean);
await G(sel=>window.__lkIn(sel,'¿En qué puedo recortar?'),inp.sel);await W(200);CK('escribir en el chat',(await G(()=>AIQ))==='¿En qué puedo recortar?');
const tool=s.rep.tree.map(n=>find(n,x=>x.tap&&x.ch&&x.ch[0]&&/4x1000/.test((x.ch[0].runs||[]).map(r=>r.s||'').join('')))).find(Boolean);
await G(sel=>window.__lkTap(sel),tool.tap);await W(900);s=await last('state');CK('herramienta abre su ventana → ventana nativa o web',!!(s.hoja||s.show===false));await sheetsOff();await G(()=>window.__lkSched());await W(900);
s=await last('state');CK('al cerrar vuelve Reportes nativo',s.show===true&&s.kind==='rep');
s=await last('state');const bars=[];const fz=n=>{if(!n)return;if(n.k==='svg'&&n.z)bars.push(n);(n.ch||[]).forEach(fz)};s.rep.tree.forEach(fz);
CK('gráficas con zonas tocables',bars.length>=2,bars.map(b=>b.z.length).join(','));
const zb=bars.find(b=>b.z.some(z=>/rect/.test(z.sel)||true));await G(sel=>{window.__msgs=[];window.__lkTap(sel)},bars[bars.length-1].z[0].sel);await W(900);s=await last('state');
CK('tocar una barra abre su detalle',!!(s.hoja||s.show===false)&&await G(()=>document.getElementById('xsheet').classList.contains('on')));await sheetsOff();await G(()=>window.__lkSched());await W(800);
console.log('2. Editar con el formulario nativo');
const t0=await G(()=>tx.filter(x=>x.mer==='Uber')[0]);
await G(id=>{window.__msgs=[];window.__lkEditData(id)},t0.id);await W(500);
let e=await last('edit');CK('datos para editar',e&&e.d.a===12000&&e.d.cat==='transp'&&e.d.acc==='Bancolombia'&&e.d.tp==='out'&&e.d.date===t0.date,JSON.stringify(e&&e.d));
CK('también manda categorías y cuentas',!!(await last('form')));
const n0=await G(()=>tx.length);
await G(d=>window.__lkSave({tp:'out',a:15500,mer:'Uber aeropuerto',cat:'transp',sub:'',acc:'Billetera',dst:'',date:d.date,edit:d.id}),e.d);await W(1500);
let t=await G(id=>tx.filter(x=>String(x.id)===String(id))[0],t0.id);
CK('movimiento editado (no se duplica)',t&&t.amt===15500&&t.mer==='Uber aeropuerto'&&t.acc==='Billetera'&&(await G(()=>tx.filter(x=>/^Uber/.test(x.mer)).length))===1,JSON.stringify(t&&{amt:t.amt,mer:t.mer,acc:t.acc}));
const ayer=await G(()=>iso(2));await G(a=>window.__lkSave({tp:'out',a:15500,mer:'Uber aeropuerto',cat:'transp',sub:'',acc:'Billetera',dst:'',date:a[1],edit:a[0]}),[String(t0.id),ayer]);await W(1500);
t=await G(id=>tx.filter(x=>String(x.id)===String(id))[0],t0.id);CK('cambiar la fecha al editar',t&&t.date===ayer,t&&t.date);
await G(id=>{window.__msgs=[];openCat(id);document.getElementById('cedit').click()},t0.id);await W(500);
e=await last('edit');CK('"Editar" del detalle abre el formulario nativo',!!e&&!(await G(()=>document.getElementById('sheet').classList.contains('on'))));
console.log('3. Eliminar');
const tt=await G(()=>tx.filter(x=>x.mer==='Rappi')[0]);const n1=await G(()=>tx.length);
await G(id=>window.__lkDel(id),String(tt.id));await W(1500);
CK('movimiento eliminado',(await G(()=>tx.length))===n1-1&&!(await G(()=>tx.some(x=>x.mer==='Rappi'))),n1+' → '+(await G(()=>tx.length)));
CK('aviso "Eliminado"',/Eliminado/.test(((await last('toast'))||{}).s||''));
CK('sin errores de página',errs.length===0,errs.slice(0,3).join(' | '));
console.log('\n'+ok+' bien, '+bad+' mal');await b.close();srv.kill();process.exit(bad?1:0)})();
