const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8823'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/unpkg/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const WA=[];await ctx.route(/wa\.me/,r=>{WA.push(decodeURIComponent(r.request().url()));r.fulfill({body:'<html>wa</html>',contentType:'text/html'})});
let p=await ctx.newPage();const errs=[];const hook=pg=>{pg.on('pageerror',e=>errs.push(e.message));pg.on('dialog',d=>d.accept(d.type()==='prompt'?'':undefined))};hook(p);
const S=async n=>{await p.waitForTimeout(300);await p.screenshot({path:'n'+n+'.png'})};const W=ms=>p.waitForTimeout(ms||300);
const back=async()=>{if(!p.url().includes('/tienda/')){await p.goBack();await W(1500)}};
const login=async(e,up)=>{await p.waitForSelector('#au-e');await p.click(up?'[data-am="up"]':'[data-am="in"]');await p.fill('#au-e',e);await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500)};
await p.goto('http://localhost:8823/tienda/');await W(1200);await login('t@x.com',1);await p.evaluate(()=>{const u=firebase.auth().currentUser.uid;const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()});await p.waitForTimeout(1200);
await p.click('[data-a="ajustes"] >> nth=0');await p.fill('#s-t','Tienda Don Pacho');await p.fill('#s-b','50000');await p.fill('#s-wa','3001112233');await p.click('[data-a="guardarAj"]');await W();
await p.click('[data-tab="inv"]');await p.click('[data-a="nuevoProd"]');await p.fill('#p-n','Gaseosa');await p.fill('#p-pv','3000');await p.fill('#p-st','20');await p.click('[data-a="guardarProd"]');await W();
await p.click('[data-tab="caja"]');await W();console.log('owner solo, turno card?',await p.$('[data-a="turnoIni"]')!==null);
// venta del dueño (no debe contar en el turno)
await p.click('[data-a="venta"] >> nth=0');await W();await p.click('.pb >> text=Gaseosa');await p.click('[data-a="guardarVenta"]');await W(500);
await p.click('[data-a="ajustes"] >> nth=0');await W();await p.click('[data-a="invitar"]');await W();const link=await p.textContent('#sh .code');
await p.click('#sh [data-a="ajustes"]');await W();await p.click('#sh [data-a="salir"]');await W(1000);
await p.goto(link.replace('https://','http://').replace(/^http:\/\/[^/]+/,'http://localhost:8823'));await W(1200);await login('juan@x.com',1);await W(500);await p.fill('#j-n','Juan');await p.click('#j-go');await W(1200);await p.click('#j-out');await W(800);
await login('t@x.com',0);await W(1600);await p.click('[data-a="ajustes"] >> nth=0');await W();await p.click('[data-a="aprobar"]');await W(600);await p.click('#sh [data-a="salir"]');await W(1000);

await login('juan@x.com',0);await W(1500);
const vis=sel=>p.evaluate(sel=>{const e=document.querySelector(sel);return!!(e&&e.offsetParent!==null)},sel);
console.log('ANTES · empleado ve Fiar:',await vis('#main [data-a="fiar"]'),'| Inventario:',await vis('#nav [data-tab="inv"]'),'| Gastos:',await vis('#nav [data-tab="gastos"]'));
await p.click('[data-a="ajustes"] >> nth=0');await W();await p.click('#sh [data-a="salir"]');await W(1000);
await login('t@x.com',0);await W(1500);await p.click('[data-a="ajustes"] >> nth=0');await W();
console.log('fila empleado:',(await p.textContent('#sh [data-a="permisos"]')).replace(/\s+/g,' '));await p.click('#sh [data-a="permisos"]');await W();
await p.click('#sh [data-a="permTog"][data-k="fiar"]');await W(300);await p.click('#sh [data-a="permTog"][data-k="inv"]');await W(300);await p.click('#sh [data-a="permTog"][data-k="caja"]');await W(300);await p.screenshot({path:'perm.png'});
console.log('guardado:',await p.evaluate(()=>JSON.stringify(LKT.D.miem[0].perm)));
await p.click('#sh [data-a="ajustes"]');await W();await p.click('#sh [data-a="salir"]');await W(1000);
await login('juan@x.com',0);await W(1800);
console.log('DESPUÉS · Fiar:',await vis('#main [data-a="fiar"]'),'| Inventario:',await vis('#nav [data-tab="inv"]'),'| Cerrar caja:',await vis('#main [data-a="cierre"]'),'| Gastos:',await vis('#nav [data-tab="gastos"]'),'| Venta:',await vis('#main [data-a="venta"]'));
await p.click('[data-a="venta"] >> nth=0');await W();console.log('chip Fiado en venta:',await vis('#sh [data-vmet="fi"]'));await p.click('#sh [data-a="cerrar"]');await W();
await p.evaluate(()=>document.activeElement.blur());await p.keyboard.press('F3');await W(200);console.log('F3:',await p.textContent('#toast'),'| hoja abierta:',await p.evaluate(()=>document.querySelector('#sh').classList.contains('on')));
await p.screenshot({path:'perm-emp.png'});
console.log('errs',errs);await b.close();srv.kill();})();