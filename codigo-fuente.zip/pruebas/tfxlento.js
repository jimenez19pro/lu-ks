const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8802'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},colorScheme:process.argv[2]||'light',locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
let MODE='ok',REQ=null;const INV={proveedor:'Distribuidora El Sol S.A.S',numero:'FV-1234',fecha:'2026-10-19',total:165200,items:[
{nombre:'GASEOSA COLOMBIANA 400ML PET X12',codigo:null,cantidad:2,presentacion:'Paca x 12',unidades:24,costo_unidad:2200,total_linea:52800,id:null},
{nombre:'ARROZ DIANA X 500 GR',codigo:'7702511000014',cantidad:1,presentacion:'Paca x 25',unidades:25,costo_unidad:2600,total_linea:65000,id:null},
{nombre:'ACEITE GIRASOL 900 ML',codigo:null,cantidad:6,presentacion:'Unidad',unidades:6,costo_unidad:'7.900',total_linea:47400,id:null}]};
let CALLS=[];await ctx.addInitScript(()=>{window.__fxTmo=3000;window.__fxMax=12000});
await ctx.route(/generativelanguage/,r=>{const mdl=r.request().url().split('/models/')[1].split(':')[0];CALLS.push(MODE+':'+mdl);
if(MODE==='hang1'&&mdl==='gemini-flash-latest')return;if(MODE==='hangall')return;if(MODE==='net1'){MODE='ok';return r.abort('failed')}
r.fulfill({contentType:'application/json',body:JSON.stringify({candidates:[{content:{parts:[{text:JSON.stringify(INV)}]}}]})})});
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept());
const W=ms=>p.waitForTimeout(ms||300);const S=async n=>{await W(250);await p.screenshot({path:'fx'+n+'.png'})};const SF=async n=>{await W(250);await p.locator('#sh').screenshot({path:'fx'+n+'.png'})};
await p.goto('http://localhost:8802/tienda/');await W(1500);
await p.click('[data-am="up"]');await p.fill('#au-e','t@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500);
const uid=await p.evaluate(()=>firebase.auth().currentUser.uid);
await p.evaluate(u=>{const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()},uid);await W(1200);
await p.click('[data-a="ajustes"] >> nth=0');await p.fill('#s-t','Tienda Don Pacho');await p.click('[data-a="guardarAj"]');await W();
await p.click('[data-tab="inv"]');for(const [n,pv,pc,st] of [['Gaseosa Colombiana 400 ml','3000','2000','5'],['Arroz Diana 500 g','3200','2600','10'],['Arroz Roa 1000 g','5200','4300','4']]){await p.click('[data-a="nuevoProd"]');await p.fill('#p-n',n);await p.fill('#p-pv',pv);await p.fill('#p-pc',pc);await p.fill('#p-st',st);await p.click('[data-a="guardarProd"]');await W(200)}
// 1) sin clave -> pantalla de configurar
await p.click('[data-a="factura"]');await W(800);console.log('setup:',await p.evaluate(()=>document.querySelector('#sh h1').innerText));await p.fill('#ia-k','abc');await p.click('[data-a="iaSave"]');console.log('bad key msg:',await p.textContent('#ia-m'));await p.click('#sh [data-a="cerrar"]');await W();
// 2) clave importada desde Lu-Ks personal
await p.evaluate(u=>{const b=firebase.firestore().batch();b.set({path:'users/'+u+'/tabs/Ajustes__0'},{t:'Ajustes',i:0,rows:JSON.stringify([['Clave','Valor'],['tema','azul'],['gemini','AIzaSyTEST_1234567890abcdefgh']])});return b.commit()},uid);
await p.reload();await W(2500);await p.click('[data-tab="inv"]');await W();
await p.click('[data-a="factura"]');await W(800);console.log('photo sheet:',await p.evaluate(()=>document.querySelector('#sh h1').innerText));await SF(1);
const st=()=>p.evaluate(()=>{const e=document.querySelector('#fx-st');return e?e.innerText.replace(/\n/g,' | '):'(no fx-st) '+document.querySelector('#sh h1').innerText});
const reopen=async()=>{await p.click('#ov',{position:{x:20,y:20}}).catch(()=>{});await W(600);await p.click('[data-a="factura"]');await W(800)};
// 1) primer modelo se cuelga -> pasa al siguiente
MODE='hang1';CALLS=[];await p.setInputFiles('#fx-f','qr-test.png');await W(1500);console.log('esperando:',await st());await p.screenshot({path:'fxl1.png'});await W(4000);console.log('tras timeout:',await st(),'| calls',CALLS.join(','));
// 2) corte de red una vez -> reintenta
await reopen();MODE='net1';CALLS=[];await p.setInputFiles('#fx-f','qr-test.png');await W(4000);console.log('corte de red:',await st(),'| calls',CALLS.join(','));
// 3) todo se cuelga -> mensaje final
await reopen();MODE='hangall';CALLS=[];await p.setInputFiles('#fx-f','qr-test.png');await W(15000);console.log('todo colgado:',await st(),'| calls',CALLS.length);
// 4) cancelar
MODE='hangall';await p.click('[data-a="fxRetry"]');await W(1500);await p.click('[data-a="fxCancel"]');await W(500);console.log('cancelado:',await st());
// 5) cerrar mientras lee -> no abre revisión después
MODE='hang1';await p.setInputFiles('#fx-f','qr-test.png');await W(800);console.log('antes de cerrar:',await st(),await p.evaluate(()=>[...document.querySelectorAll('#sh [data-a]')].map(b=>b.dataset.a+':'+b.offsetParent!==null).join(',')));console.log('btns',await p.evaluate(()=>[...document.querySelectorAll('#sh button')].map(b=>(b.dataset.a||'-')+'|'+b.innerText).join(' ; ')));console.log('inmediato',await p.evaluate(()=>{const b=document.querySelector('#sh button[data-a="cerrar"]');b.click();return document.querySelector('#sh').className+' / '+document.querySelector('#ov').className}));await W(300);console.log('cerrada?',await p.evaluate(()=>document.querySelector('#sh').classList.contains('on')));await W(5000);console.log('tras cerrar, hoja abierta?',await p.evaluate(()=>document.querySelector('#sh').classList.contains('on')&&document.querySelector('#sh h1').innerText));
// 6) salir de la app y volver -> retoma
await p.click('[data-a="factura"]');await W(800);MODE='hangall';CALLS=[];await p.setInputFiles('#fx-f','qr-test.png');await W(1000);
await p.evaluate(()=>{Object.defineProperty(document,'hidden',{configurable:true,get:()=>true});document.dispatchEvent(new Event('visibilitychange'))});await W(3500);MODE='ok';
await p.evaluate(()=>{Object.defineProperty(document,'hidden',{configurable:true,get:()=>false});document.dispatchEvent(new Event('visibilitychange'))});await W(1500);console.log('volver a la app:',await st(),'| calls',CALLS.join(','));
console.log('errs',errs);await b.close();srv.kill();})();