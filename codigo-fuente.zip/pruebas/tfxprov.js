const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8792'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},colorScheme:process.argv[2]||'light',locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
let MODE='ok',REQ=null;const INV={proveedor:'',numero:'FV-1234',fecha:'2026-10-19',total:165200,items:[
{nombre:'GASEOSA COLOMBIANA 400ML PET X12',codigo:null,cantidad:2,presentacion:'Paca x 12',unidades:24,costo_unidad:2200,total_linea:52800,id:null},
{nombre:'ARROZ DIANA X 500 GR',codigo:'7702511000014',cantidad:1,presentacion:'Paca x 25',unidades:25,costo_unidad:2600,total_linea:65000,id:null},
{nombre:'ACEITE GIRASOL 900 ML',codigo:null,cantidad:6,presentacion:'Unidad',unidades:6,costo_unidad:'7.900',total_linea:47400,id:null}]};
await ctx.route(/generativelanguage/,r=>{REQ=JSON.parse(r.request().postData());if(MODE==='429')return r.fulfill({contentType:'application/json',body:JSON.stringify({error:{code:429,message:'quota'}})});r.fulfill({contentType:'application/json',body:JSON.stringify({candidates:[{content:{parts:[{text:'```json\n'+JSON.stringify(INV)+'\n```'}]}}]})})});
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept());
const W=ms=>p.waitForTimeout(ms||300);const S=async n=>{await W(250);await p.screenshot({path:'fx'+n+'.png'})};const SF=async n=>{await W(250);await p.locator('#sh').screenshot({path:'fx'+n+'.png'})};
await p.goto('http://localhost:8792/tienda/');await W(1500);
await p.click('[data-am="up"]');await p.fill('#au-e','t@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500);
const uid=await p.evaluate(()=>firebase.auth().currentUser.uid);
await p.evaluate(u=>{const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()},uid);await W(1200);
await p.click('[data-a="ajustes"] >> nth=0');await p.fill('#s-t','Tienda Don Pacho');await p.click('[data-a="guardarAj"]');await W();
await p.click('[data-tab="inv"]');for(const [n,pv,pc,st] of [['Gaseosa Colombiana 400 ml','3000','2000','5'],['Arroz Diana 500 g','3200','2600','10'],['Arroz Roa 1000 g','5200','4300','4']]){await p.click('[data-a="nuevoProd"]');await p.fill('#p-n',n);await p.fill('#p-pv',pv);await p.fill('#p-pc',pc);await p.fill('#p-st',st);await p.click('[data-a="guardarProd"]');await W(200)}
// 1) sin clave -> pantalla de configurar
await p.click('[data-a="factura"]');await W(800);console.log('setup:',await p.evaluate(()=>document.querySelector('#sh h1').innerText));await p.fill('#ia-k','abc');await p.click('[data-a="iaSave"]');console.log('bad key msg:',await p.textContent('#ia-m'));await p.click('#sh [data-a="cerrar"]');await W();
// 2) clave importada desde Lu-Ks personal
await p.evaluate(u=>{const b=firebase.firestore().batch();b.set({path:'users/'+u+'/tabs/Ajustes__0'},{t:'Ajustes',i:0,rows:JSON.stringify([['Clave','Valor'],['tema','azul'],['gemini','AIzaSyTEST_1234567890abcdefgh']])});return b.commit()},uid);
await p.reload();await W(2500);await p.click('[data-tab="inv"]');await W();
await p.click('[data-a="factura"]');await W(800);console.log('photo sheet:',await p.evaluate(()=>document.querySelector('#sh h1').innerText));await SF(1);
// 429 first
MODE='429';await p.setInputFiles('#fx-f','qr-test.png');await W(1500);console.log('429 msg:',await p.textContent('#fx-st'));
MODE='ok';await p.setInputFiles('#fx-f','qr-test.png');await W(1500);
console.log('req key ok:',!!REQ,'img parts',REQ.contents[0].parts.filter(x=>x.inline_data).length,'prompt has products',REQ.contents[0].parts[0].text.includes('Arroz Roa'));
console.log('ia doc saved:',await p.evaluate(()=>JSON.stringify(LKT.D.conf.filter(x=>x.id==='ia')[0])));
console.log('SHEET',await p.evaluate(()=>document.querySelector('#sh').innerText.slice(0,300)),errs);const rev=await p.evaluate(()=>[...document.querySelectorAll('.fxl')].map(w=>{const s=w.querySelector('[data-fxp]');return s.options[s.selectedIndex].text+' | q='+(w.querySelector('[data-fxq]')||{}).value+' c='+(w.querySelector('[data-fxc]')||{}).value+' v='+((w.querySelector('[data-fxv]')||{}).value||'')+' | '+w.querySelector('.fxh').innerText.replace(/\n/g,' ')}));console.log(rev.join('\n'));
console.log('prov sel:',await p.evaluate(()=>{const s=document.querySelector('#fx-p');return s.options[s.selectedIndex].text}),'| dif:',await p.textContent('#fx-d'));
console.log('opciones:',await p.evaluate(()=>[...document.querySelector('#fx-p').options].map(o=>o.text).join(' / ')));
await p.selectOption('#fx-p','__new');await W(400);console.log('campo nombre visible:',await p.$('#fx-pn')!==null);await p.screenshot({path:'fxp1.png'});
await p.click('[data-fxm="cr"]');await W();await p.click('[data-a="fxGuardar"]');await W(400);console.log('msg vacío:',await p.textContent('#fx-msg'));
await p.fill('#fx-pn','Plátanos Don José');await p.fill('#fx-pt','300 123 4567');await p.click('[data-fxm="cr"]');await W();console.log('nombre tras redibujar:',await p.inputValue('#fx-pn'));
await p.click('[data-a="fxGuardar"]');await W(700);
console.log('prov:',await p.evaluate(()=>JSON.stringify(LKT.D.prov.map(x=>[x.n,x.tel]))),'pmov:',await p.evaluate(()=>JSON.stringify(LKT.D.pmov.map(x=>[x.tipo,x.monto,x.metodo]))));
console.log('errs',errs);await b.close();srv.kill();})();