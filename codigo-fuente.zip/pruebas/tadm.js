const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8780'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const WA=[];await ctx.route(/wa\.me/,r=>{WA.push(decodeURIComponent(r.request().url()));r.fulfill({body:'wa',contentType:'text/html'})});
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept(d.type()==='prompt'?d.defaultValue():undefined));const W=ms=>p.waitForTimeout(ms||300);const S=async n=>{await W(250);await p.screenshot({path:'ad'+n+'.png'})};
const setDoc=(path,o)=>p.evaluate(([path,o])=>{const b=firebase.firestore().batch();b.set({path},o);return b.commit()},[path,o]);
const uid=()=>p.evaluate(()=>firebase.auth().currentUser.uid);
const login=async(e,up)=>{await p.waitForSelector('#au-e');await p.click(up?'[data-am="up"]':'[data-am="in"]');await p.fill('#au-e',e);await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500)};
const back=async()=>{if(!p.url().includes('/tienda/')){await p.goBack();await W(1500)}};
await p.goto('http://localhost:8780/tienda/');await W(1200);
// 1) tendero nuevo -> prueba gratis
await login('tienda@x.com',1);await S(1);console.log('trial btn',!!(await p.$('#pay-try')));await p.fill('#pay-tel','3005556677');await p.click('#pay-try');await W(1200);
console.log('trial active',JSON.stringify(await p.evaluate(()=>({own:LKT.state().OWN!=null,lic:LKT.state().LIC}))));
const tu=await uid();
// vence en 3 dias -> aviso
await setDoc('licencias/'+tu,{prueba:true,vence:Date.now()+2.5*864e5,email:'tienda@x.com',nombre:'',tel:'3005556677',ts:Date.now()});await W(600);await p.click('[data-tab="caja"]');await W();await S(2);console.log('aviso:',await p.evaluate(()=>{const c=[...document.querySelectorAll('#main .card')].find(x=>x.innerText.includes('⏰'));return c&&c.innerText.replace(/\n/g,' ')}));
await p.click('[data-a="renovar"]');await W(800);await back();console.log('WA renov:',WA[WA.length-1].slice(0,90));
// ajustes tienda + producto con vencimiento
await p.click('[data-a="ajustes"] >> nth=0');await p.fill('#s-t','Tienda La Esquina');await p.fill('#s-b','40000');await p.click('[data-a="guardarAj"]');await W();
await p.click('[data-tab="inv"]');await p.click('[data-a="nuevoProd"]');await p.fill('#p-n','Leche entera 1 L');await p.fill('#p-pv','4800');await p.fill('#p-pc','3900');await p.fill('#p-st','10');await p.fill('#p-min','3');
const f2=await p.evaluate(()=>{const d=new Date();d.setDate(d.getDate()+2);return d.toISOString().slice(0,10)});const fm1=await p.evaluate(()=>{const d=new Date();d.setDate(d.getDate()-1);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')});
await p.fill('#p-f',f2);await p.click('[data-a="guardarProd"]');await W();
await p.click('[data-a="entrada"]');await p.fill('#e-s','Leche');await p.waitForTimeout(150);await p.click('#e-l [data-a="ePick"] >> nth=0');await p.fill('#e-q','6');await p.evaluate(f=>{document.querySelector('#e-f').value=f},fm1);await p.click('[data-a="guardarEntrada"]');await W();await p.click('#sh [data-a="cerrar"]');await W();
console.log('lotes',JSON.stringify(await p.evaluate(()=>LKT.D.prod[0].lotes)),'st',await p.evaluate(()=>LKT.D.prod[0].st));
await S(3);
// venta de 2 -> consume lote mas viejo
await p.click('[data-tab="caja"]');await p.click('[data-a="venta"] >> nth=0');await p.click('.pb >> text=Leche');await p.click('.pb >> text=Leche');await p.click('[data-a="guardarVenta"]');await W(500);
console.log('lotes tras venta',JSON.stringify(await p.evaluate(()=>LKT.D.prod[0].lotes)));
console.log('card venc:',await p.evaluate(()=>{const c=document.querySelector('#main [data-a=vencer]');return c&&c.innerText.replace(/\n/g,' ')}));
const esp0=await p.evaluate(()=>LKT.esperado(new Date().toISOString().slice(0,10)).total);
await p.click('#main [data-a="vencer"]');await W();await S(4);await p.click('#sh [data-a="lotBotar"] >> nth=0');await W(500);
console.log('tras botar st',await p.evaluate(()=>LKT.D.prod[0].st),'perd',JSON.stringify(await p.evaluate(()=>LKT.D.gasto.map(g=>[g.cat,g.metodo,g.monto,g.nota]))),'caja igual',esp0===await p.evaluate(()=>LKT.esperado(new Date().toISOString().slice(0,10)).total));
await p.click('#sh [data-a="lotOferta"] >> nth=0');await W(400);console.log('oferta pv',await p.evaluate(()=>LKT.D.prod[0].pv));await p.click('#sh [data-a="cerrar"]');await W();
// otra persona pide activar (sin prueba): crea solicitud
await p.evaluate(()=>firebase.auth().signOut());await W(800);await login('otro@x.com',1);await p.fill('#pay-tel','3112223344');await p.click('#pay-wa');await W(800);await back();const ou=await uid();
// 2) admin
await p.evaluate(()=>firebase.auth().signOut());await W(800);await login('jose@x.com',1);const ju=await uid();await setDoc('licencias/'+ju,{nombre:'Jose'});await setDoc('admins/'+ju,{nombre:'Jose'});await W(1200);
await p.click('[data-a="ajustes"] >> nth=0');await W();console.log('admin row',!!(await p.$('#sh [data-a="admPanel"]')));await p.click('#sh [data-a="admPanel"]');await W(800);await S(5);
console.log('panel:',(await p.textContent('#sh')).replace(/\s+/g,' ').slice(0,420));
await p.click('#sh [data-a="admAbrir"][data-id="'+ou+'"] >> nth=0');await W();await p.fill('#ad-n','Minimercado El Otro');await S(6);await p.click('[data-a="admExt"][data-p="fund"]');await W(600);
console.log('lic otro',JSON.stringify(await p.evaluate(id=>JSON.parse(localStorage.mockdb)['licencias/'+id],ou)));
await p.click('[data-a="admExt"][data-p="mes"]');await W(500);console.log('renov +1',await p.evaluate(id=>JSON.parse(localStorage.mockdb)['licencias/'+id].hasta,ou));
await p.click('[data-a="admPanel"]');await W(500);await p.click('#sh [data-a="admAbrir"][data-id="'+tu+'"] >> nth=0');await W();await p.click('[data-a="admExt"][data-p="ano"]');await W(500);console.log('tienda anual',JSON.stringify(await p.evaluate(id=>JSON.parse(localStorage.mockdb)['licencias/'+id],tu)));
await p.click('[data-a="admCobrar"]');await W(800);await back();console.log('WA cobro:',WA[WA.length-1].slice(0,160));
await p.click('[data-a="ajustes"] >> nth=0');await W();await p.click('#sh [data-a="admPanel"]');await W(500);await p.fill('#ad-pt','$15.000 al mes · 1er mes gratis');await p.click('[data-a="admCfg"]');await W(500);console.log('cfg',JSON.stringify(await p.evaluate(()=>JSON.parse(localStorage.mockdb)['config/tienda'])));await S(7);
// desactivar
await p.click('#sh [data-a="admAbrir"][data-id="'+ou+'"] >> nth=0');await W();await p.click('[data-a="admOff"]');await W(500);console.log('off',await p.evaluate(id=>JSON.parse(localStorage.mockdb)['licencias/'+id].hasta,ou));
console.log('errs',errs);await b.close();srv.kill()})();
