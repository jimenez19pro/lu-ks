const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8798'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/unpkg/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const WA=[];await ctx.route(/wa\.me/,r=>{WA.push(decodeURIComponent(r.request().url()));r.fulfill({body:'<html>wa</html>',contentType:'text/html'})});
let p=await ctx.newPage();const errs=[];const hook=pg=>{pg.on('pageerror',e=>errs.push(e.message));pg.on('dialog',d=>d.accept(d.type()==='prompt'?'':undefined))};hook(p);
const S=async n=>{await p.waitForTimeout(300);await p.screenshot({path:'n'+n+'.png'})};const W=ms=>p.waitForTimeout(ms||300);
const back=async()=>{if(!p.url().includes('/tienda/')){await p.goBack();await W(1500)}};
const login=async(e,up)=>{await p.waitForSelector('#au-e');await p.click(up?'[data-am="up"]':'[data-am="in"]');await p.fill('#au-e',e);await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500)};
await p.goto('http://localhost:8798/tienda/');await W(1200);await login('t@x.com',1);await p.evaluate(()=>{const u=firebase.auth().currentUser.uid;const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()});await p.waitForTimeout(1200);
await p.click('[data-a="ajustes"] >> nth=0');await p.fill('#s-t','Tienda Don Pacho');await p.fill('#s-b','50000');await p.fill('#s-wa','3001112233');await p.click('[data-a="guardarAj"]');await W();
await p.click('[data-tab="inv"]');await p.click('[data-a="nuevoProd"]');await p.fill('#p-n','Gaseosa');await p.fill('#p-pv','3000');await p.fill('#p-st','20');await p.click('[data-a="guardarProd"]');await W();
await p.click('[data-tab="caja"]');await W();console.log('owner solo, turno card?',await p.$('[data-a="turnoIni"]')!==null);
// venta del dueño (no debe contar en el turno)
await p.click('[data-a="venta"] >> nth=0');await W();await p.click('.pb >> text=Gaseosa');await p.click('[data-a="guardarVenta"]');await W(500);
await p.click('[data-a="ajustes"] >> nth=0');await W();await p.click('[data-a="invitar"]');await W();const link=await p.textContent('#sh .code');
await p.click('#sh [data-a="ajustes"]');await W();await p.click('#sh [data-a="salir"]');await W(1000);
await p.goto(link.replace('https://','http://').replace(/^http:\/\/[^/]+/,'http://localhost:8798'));await W(1200);await login('juan@x.com',1);await W(500);await p.fill('#j-n','Juan');await p.click('#j-go');await W(1200);await p.click('#j-out');await W(800);
await login('t@x.com',0);await W(1600);await p.click('[data-a="ajustes"] >> nth=0');await W();await p.click('[data-a="aprobar"]');await W(600);await p.click('#sh [data-a="salir"]');await W(1000);
await login('juan@x.com',0);await W(1500);await p.click('[data-tab="caja"]');await W();
console.log('emp card:',await p.evaluate(()=>{const c=document.querySelector('[data-a="turnoIni"]');return c&&c.innerText.replace(/\n/g,' | ')}));
await p.click('[data-a="turnoIni"]');await W();console.log('base sugerida:',await p.inputValue('#tk-b'));await S('t1');
await p.fill('#tk-b','53000');await p.click('[data-a="turnoGo"]');await W(500);
for(let i=0;i<2;i++){await p.click('[data-a="venta"] >> nth=0');await W();await p.click('.pb >> text=Gaseosa');await p.click('[data-a="guardarVenta"]');await W(500);await p.evaluate(()=>{try{document.querySelector('#sh [data-a="cerrar"]')&&document.querySelector('#sh').classList.contains('on')&&document.querySelector('#sh [data-a="cerrar"]').click()}catch(e){}});await W()}
console.log('turno abierto:',await p.evaluate(()=>{const b=document.querySelector('[data-a="turnoFin"]');return b&&b.closest('.card').innerText.replace(/\n/g,' | ')}));await S('t2');
await p.click('[data-a="turnoFin"]');await W();await p.fill('#tk-c','58000');await W(300);console.log('dif vivo:',await p.textContent('#tk-d'));await S('t3');
await p.click('[data-a="turnoCerrar"]');await W(600);console.log('toast:',await p.textContent('#toast'));console.log('detalle:',(await p.textContent('#sh')).slice(0,400));await S('t4');
await p.click('#sh [data-a="turnoShare"]');await W(800);console.log('WA:',WA[WA.length-1]);await back();
await login('juan@x.com',0).catch(()=>{});await W(800);
console.log('card tras cerrar:',await p.$('[data-a="turnoIni"]')!==null);
await p.click('[data-a="ajustes"] >> nth=0');await W();await p.click('#sh [data-a="salir"]');await W(1000);
await login('t@x.com',0);await W(1500);await p.click('[data-tab="caja"]');await W();
console.log('dueño turnos hoy:',await p.evaluate(()=>{const h=[...document.querySelectorAll('#main h2')].find(x=>x.innerText.includes('Turnos'));return h&&h.nextElementSibling.innerText.replace(/\n/g,' | ')}));await S('t5');
await p.click('[data-tab="rep"]');await W(500);console.log('reportes:',await p.evaluate(()=>{const h=[...document.querySelectorAll('#main h2')].find(x=>x.innerText.includes('Turnos'));return h&&h.nextElementSibling.innerText.replace(/\n/g,' | ')}),'| cierres incluye turno?',await p.evaluate(()=>{const h=[...document.querySelectorAll('#main h2')].find(x=>x.innerText.includes('Cierres'));return!!h}));await S('t6');
console.log('dia esperado',await p.evaluate(()=>LKT.esperado(new Date().toISOString().slice(0,10)).total));
console.log('errs',errs);await b.close();srv.kill();})();