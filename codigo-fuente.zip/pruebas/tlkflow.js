const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8812'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},deviceScaleFactor:1,locale:'es-CO',serviceWorkers:'block',colorScheme:'dark'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error'&&!/ERR_FAILED|Failed to load/.test(m.text()))errs.push('C '+m.text().slice(0,160))});p.on('dialog',d=>d.accept());await p.addInitScript(()=>{localStorage.setItem('luks-lang','es')});const W=ms=>p.waitForTimeout(ms||400);const O='/tmp/claude-0/-home-claude/386cd89e-f2f2-549f-a9dc-a0da83d3d90b/scratchpad/flow/';fs.mkdirSync(O,{recursive:true});
await p.goto('http://localhost:8812/');await W(3000);await p.click('[data-au="up"]');await p.fill('#au-n','Jose');await p.fill('#au-e','jose@x.com');await p.fill('#au-p','secreto1');await p.click('#au-go');await W(2500);
for(let i=0;i<8;i++){await p.evaluate(()=>{const s=document.querySelector('[data-ob="skip"]');if(s)s.click()});await W(250)}

let ok=0,bad=0;const CK=(name,cond,info)=>{if(cond){ok++;console.log('  ✔',name,info===undefined?'':info)}else{bad++;console.log('  ✘',name,info===undefined?'':info)}};
const G=f=>p.evaluate(f);const sheetsOff=()=>p.evaluate(()=>document.querySelectorAll('.sheet.on').forEach(s=>s.classList.remove('on')));
console.log('1. Cuentas');
await G(()=>{const mk=o=>{AE=-1;AF=Object.assign(afNew(),o);saveAcc2()};mk({tipo:"debito",banco:"Bancolombia",ini:"1000000",pri:true});mk({tipo:"credito",banco:"Nu Colombia",color:CLR[7],cupo:"3000000",ini:"0"});mk({tipo:"efectivo",name:"Billetera",ini:"100000"})});await W(1500);
CK('3 cuentas creadas',(await G(()=>ACC.map(a=>a.n).join(',')))==='Bancolombia,Nu Colombia,Billetera',await G(()=>ACC.map(a=>a.n).join(',')));
const fab=async()=>{await sheetsOff();await p.click('[data-t="home"]');await W(500);await p.click('#add');await W(500)};
console.log('2. Gasto por el formulario');
await fab();await p.fill('#f-amt','50000');await p.fill('#f-mer','Mercado D1');await p.click('#fo-cat');await W(400);await p.click('[data-pkc="comida"]');await W(300);await G(()=>{$("#f-acc").value="Bancolombia"});await p.click('#save');await W(1500);
let r=await G(()=>({n:tx.length,last:tx.filter(t=>t.mer==="Mercado D1")[0],b:bal("Bancolombia")}));
CK('gasto guardado',r.last&&r.last.amt===50000&&r.last.cat==="comida"&&r.last.tipo==="out",JSON.stringify(r.last&&{amt:r.last.amt,cat:r.last.cat,acc:r.last.acc,tipo:r.last.tipo}));CK('saldo Bancolombia −50.000',r.b===-50000,r.b);
console.log('3. Ingreso');
await fab();await p.click('#fo-tp');await W(200);CK('cambia a Ingreso',(await p.textContent('#fo-tpl'))==='Ingreso',await p.textContent('#fo-tpl'));await p.fill('#f-amt','2000000');await p.fill('#f-mer','Sueldo');await G(()=>{$("#f-acc").value="Bancolombia"});await p.click('#save');await W(1500);
r=await G(()=>({b:bal("Bancolombia"),t:tx.filter(t=>t.mer==="Sueldo")[0]}));CK('ingreso guardado',r.t&&r.t.tipo==="in"&&r.t.amt===2000000);CK('saldo Bancolombia +1.950.000',r.b===1950000,r.b);
console.log('4. Transferencia');
await fab();await p.click('#fo-tp');await p.click('#fo-tp');await W(200);CK('cambia a Entre cuentas',/cuentas|Transf/i.test(await p.textContent('#fo-tpl')),await p.textContent('#fo-tpl'));await p.fill('#f-amt','100000');await G(()=>{$("#f-acc").value="Bancolombia";$("#f-dst").value="Billetera";DST="Billetera"});await p.click('#save');await W(1500);
r=await G(()=>({b:bal("Bancolombia"),w:bal("Billetera"),t:tx.filter(t=>t.tipo==="tr")[0]}));CK('transferencia guardada',!!r.t,JSON.stringify(r.t&&{amt:r.t.amt,acc:r.t.acc,dst:r.t.dst}));CK('Bancolombia 1.850.000',r.b===1850000,r.b);CK('Billetera +100.000',r.w===100000,r.w);
console.log('5. Gasto con tarjeta de crédito');
await fab();await p.fill('#f-amt','80000');await p.fill('#f-mer','Ropa');await p.click('#fo-cat');await W(300);await p.click('[data-pkc="ropa"]').catch(async()=>{await p.click('.pk >> nth=3')});await W(200);await G(()=>{$("#f-acc").value="Nu Colombia"});await p.click('#save');await W(1500);
r=await G(()=>({n:bal("Nu Colombia")}));CK('deuda tarjeta 80.000',r.n===-80000,r.n);
console.log('6. Editar movimiento');
await sheetsOff();await p.click('[data-t="tx"]');await W(900);const rowSel=await G(()=>{const t=tx.filter(t=>t.mer==="Mercado D1")[0];const el=document.querySelector('.row[data-id="'+t.id+'"]');return el?'.row[data-id="'+t.id+'"]':null});CK('fila visible en Movimientos',!!rowSel);
if(rowSel){await p.click(rowSel);await W(500);CK('abre detalle',await G(()=>document.getElementById('csheet').classList.contains('on')));await p.click('#cedit');await W(500);await p.fill('#f-amt','60000');await p.click('#save');await W(1800);
r=await G(()=>({t:tx.filter(t=>t.mer==="Mercado D1")[0],b:bal("Bancolombia")}));CK('monto editado a 60.000',r.t&&r.t.amt===60000,r.t&&r.t.amt);CK('saldo ajustado 1.840.000',r.b===1840000,r.b)}
console.log('7. Eliminar movimiento');
await sheetsOff();await p.click('[data-t="tx"]');await W(900);const rs2=await G(()=>{const t=tx.filter(t=>t.mer==="Ropa")[0];return t?'.row[data-id="'+t.id+'"]':null});
if(rs2){await p.click(rs2);await W(400);await p.click('#cdel');await W(200);await p.click('#cdel');await W(1800);r=await G(()=>({e:tx.some(t=>t.mer==="Ropa"),n:bal("Nu Colombia")}));CK('eliminado',!r.e);CK('tarjeta vuelve a 0',r.n===0,r.n)}
console.log('8. Presupuesto');
await sheetsOff();await G(()=>openBud('comida'));await W(300);await p.fill('#b-amt','700000');await p.click('#bsave');await W(1200);CK('presupuesto comida 700.000',(await G(()=>BUD.comida))===700000,await G(()=>BUD.comida));
console.log('9. Meta de ahorro');
await G(()=>openGoal(-1));await W(300);await p.fill('#g-n','Viaje');await p.fill('#g-t','2000000');await p.fill('#g-s','500000');await p.click('#gsave');await W(1200);r=await G(()=>GOALS[0]);CK('meta creada',r&&r.n==='Viaje'&&r.target===2000000&&r.saved===500000,JSON.stringify(r));
await G(()=>openGoal(0));await W(300);await p.fill('#g-a','100000');await p.click('#gsave');await W(1200);CK('abono a la meta → 600.000',(await G(()=>GOALS[0].saved))===600000,await G(()=>GOALS[0].saved));
console.log('10. Deuda');
await G(()=>openDebt(-1));await W(300);await p.fill('#d-n','Banco');await p.fill('#d-t','1000000');await p.fill('#d-p','200000');await p.click('#dsave');await W(1200);r=await G(()=>DEBTS[0]);CK('deuda creada',r&&r.total===1000000&&r.paid===200000,JSON.stringify(r));
await G(()=>openDebt(-1));await W(300);await p.click('[data-dt="deben"]');await p.fill('#d-n','Carlos');await p.fill('#d-t','50000');await p.click('#dsave');await W(1200);CK('"me deben" creada',(await G(()=>DEBTS[1]&&DEBTS[1].tipo))==='deben',await G(()=>DEBTS[1]&&DEBTS[1].tipo));
console.log('11. Pago recurrente');
await G(()=>openRec(-1));await W(300);await p.fill('#r-n','Netflix');await p.fill('#r-a','45000');await p.fill('#r-d','15');await p.click('#rsave');await W(1200);CK('recurrente creado',(await G(()=>REC[0]&&REC[0].n))==='Netflix');
console.log('12. Pantallas con los datos');
await sheetsOff();await p.click('[data-t="home"]');await W(800);let home=await p.textContent('#app');CK('Inicio muestra saldo de cuentas',/1\.840\.000|1\.940\.000/.test(home));
await p.click('[data-t="rep"]');await W(1200);let rep=await p.textContent('#app');CK('Reportes muestra ingresos 2.000.000',/2\.000\.000/.test(rep));CK('Reportes muestra gasto 60.000',/60\.000/.test(rep));
await p.click('[data-t="tx"]');await W(800);await p.fill('#app input[type=search],#app input',"Mercado").catch(()=>{});await W(600);CK('búsqueda encuentra Mercado',/Mercado D1/.test(await p.textContent('#app')));
console.log('13. Tras recargar la app');
const before=await G(()=>JSON.stringify({n:tx.length,acc:ACC.length,bud:BUD.comida,g:GOALS.length,d:DEBTS.length,r:REC.length}));await p.reload();await W(4000);for(let i=0;i<8;i++){await p.evaluate(()=>{const s=document.querySelector('[data-ob="skip"]');if(s)s.click()});await W(200)}
const after=await G(()=>JSON.stringify({n:tx.length,acc:ACC.length,bud:BUD.comida,g:GOALS.length,d:DEBTS.length,r:REC.length}));CK('los datos se conservan',before===after,before+' → '+after);
console.log('\nRESULTADO',ok,'bien',bad,'mal');console.log('errs',errs);await b.close();srv.kill()})();