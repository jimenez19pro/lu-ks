const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8803'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/unpkg/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const WA=[];await ctx.route(/wa\.me/,r=>{WA.push(decodeURIComponent(r.request().url()));r.fulfill({body:'<html>wa</html>',contentType:'text/html'})});
let p=await ctx.newPage();const errs=[];const hook=pg=>{pg.on('pageerror',e=>errs.push(e.message));pg.on('dialog',d=>d.accept(d.type()==='prompt'?'':undefined))};hook(p);
const S=async n=>{await p.waitForTimeout(300);await p.screenshot({path:'n'+n+'.png'})};const W=ms=>p.waitForTimeout(ms||300);
const back=async()=>{if(!p.url().includes('/tienda/')){await p.goBack();await W(1500)}};
const login=async(e,up)=>{await p.waitForSelector('#au-e');await p.click(up?'[data-am="up"]':'[data-am="in"]');await p.fill('#au-e',e);await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500)};
await p.goto('http://localhost:8803/tienda/');await W(1200);await login('t@x.com',1);await p.evaluate(()=>{const u=firebase.auth().currentUser.uid;const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()});await W(1200);
const L=id=>p.evaluate(id=>[...document.querySelectorAll('#'+id+'-l .row')].map(r=>r.innerText.replace(/\n/g,' ')).join(' / '),id);
await p.click('[data-tab="inv"]');await p.click('[data-a="nuevoProd"]');await p.fill('#p-n','Gaseosa');await p.fill('#p-pv','3000');await p.fill('#p-st','20');
await p.fill('#p-prov-s','Postobón');await W(200);console.log('prod prov lista:',await L('p-prov'));await p.click('[data-a="guardarProd"]');await W(300);
console.log('prov creado al guardar prod:',await p.evaluate(()=>JSON.stringify(LKT.D.prov.map(x=>x.n))),'| prod.prov ok:',await p.evaluate(()=>LKT.D.prod[0].prov===LKT.D.prov[0].id));
// fiar a cliente nuevo
await p.click('[data-tab="caja"]');await p.click('[data-a="fiar"]');await W();await p.click('.pb >> text=Gaseosa');await W();
await p.fill('#v-cli-s','Doña Marta');await W(200);console.log('fiar lista:',await L('v-cli'),'| tel visible:',await p.isVisible('#v-ct'));await p.fill('#v-ct','3001234567');
await p.click('.pb >> text=Gaseosa');await W();console.log('tras +1 conserva:',await p.inputValue('#v-cli-s'),await p.inputValue('#v-ct'));
await p.click('[data-a="guardarVenta"]');await W(500);console.log('clientes:',await p.evaluate(()=>JSON.stringify(LKT.D.cli.map(c=>[c.n,c.tel]))));
await p.evaluate(()=>{const s=document.querySelector('#sh');if(s.classList.contains('on'))s.querySelector('[data-a="cerrar"]')?.click()});await W();
// fiar a cliente existente buscando
await p.click('[data-a="fiar"]');await W();await p.click('.pb >> text=Gaseosa');await p.fill('#v-cli-s','mar');await W(200);console.log('busca mar:',await L('v-cli'));await p.click('#v-cli-l [data-a="pkPick"]');await W(200);
console.log('elegido:',await p.inputValue('#v-cli-s'),'| tel visible:',await p.isVisible('#v-ct').catch(()=>false));await p.click('[data-a="guardarVenta"]');await W(500);console.log('n clientes',await p.evaluate(()=>LKT.D.cli.length),'saldo fmov',await p.evaluate(()=>LKT.D.fmov.length));
await p.evaluate(()=>{const s=document.querySelector('#sh');if(s.classList.contains('on'))s.querySelector('[data-a="cerrar"]')?.click()});await W();
// abono
await p.click('[data-tab="fiados"]');await W();await p.click('[data-a="abono"] >> nth=0');await W();await p.click('#a-cli-s');await W(200);console.log('abono lista al tocar:',await L('a-cli'));
await p.fill('#a-cli-s','pedro');await W(200);console.log('abono pedro:',await p.textContent('#a-cli-l'));await p.fill('#a-m','2000');await p.click('[data-a="guardarAbono"]');await W(200);console.log('abono msg:',await p.textContent('#a-msg'));
await p.fill('#a-cli-s','doña');await W(200);await p.click('#a-cli-l [data-a="pkPick"]');await p.click('[data-a="guardarAbono"]');await W(400);console.log('abonos:',await p.evaluate(()=>LKT.D.fmov.filter(x=>x.tipo==='abono').length));
await p.evaluate(()=>{const s=document.querySelector('#sh');if(s.classList.contains('on'))s.querySelector('[data-a="cerrar"]')?.click()});await W();
// gasto mercancía con proveedor nuevo
await p.click('[data-tab="caja"]');await p.click('[data-a="gasto"] >> nth=0');await W();await p.fill('#g-m','50000');await p.click('[data-gcat="merc"]');await W();console.log('g-pw visible:',await p.isVisible('#g-p-s'));
await p.fill('#g-p-s','Alpina');await W(200);console.log('gasto lista:',await L('g-p'));await p.click('#g-p-l [data-a="pkNew"]');await W(200);await p.click('[data-a="guardarGasto"]');await W(300);
console.log('provs:',await p.evaluate(()=>JSON.stringify(LKT.D.prov.map(x=>x.n))),'gasto prov ok:',await p.evaluate(()=>{const g=LKT.D.gasto[0];return(LKT.D.prov.find(x=>x.id===g.prov)||{}).n}));
// compra a crédito
await p.click('[data-tab="gastos"]');await W();await p.click('[data-gv="prov"]');await W();await p.click('[data-a="pmov"][data-t="compra"] >> nth=0');await W();await p.fill('#m-m','80000');await p.click('[data-a="guardarPmov"]');await W(200);console.log('pmov sin prov:',await p.textContent('#m-msg'));
await p.fill('#m-p-s','alp');await W(200);console.log('pmov lista:',await L('m-p'));await p.click('#m-p-l [data-a="pkPick"]');await p.click('[data-a="guardarPmov"]');await W(300);console.log('pmov:',await p.evaluate(()=>JSON.stringify(LKT.D.pmov.map(x=>[(LKT.D.prov.find(v=>v.id===x.prov)||{}).n,x.monto]))));
await p.evaluate(()=>{const s=document.querySelector('#sh');if(s.classList.contains('on'))s.querySelector('[data-a="cerrar"]')?.click()});await W();
// pedido
await p.click('[data-tab="inv"]');await p.click('[data-a="nuevoProd"]');await p.fill('#p-n','Leche');await p.fill('#p-pv','4000');await p.fill('#p-st','1');await p.fill('#p-min','5');await p.click('[data-a="guardarProd"]');await W(300);
await p.click('[data-tab="caja"]');await W();await p.click('[data-tab="inv"]');await W();const pb=await p.$('[data-a="pedido"]:not([data-id])');if(pb){await pb.click();await W();await p.fill('#pd-p-s','Postob');await W(200);console.log('pedido lista:',await L('pd-p'));await p.click('#pd-p-l [data-a="pkPick"]');await W(300);console.log('pedido título:',await p.textContent('#sh h1'),'| cambiar:',!!(await p.$('[data-a="pdCambiar"]')));await S('pk-ped')}else console.log('no hay boton pedido');
console.log('errs',errs);await b.close();srv.kill();})();