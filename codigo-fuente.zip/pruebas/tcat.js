// Catálogo compartido: subida (admin), lectura con caché, propuesta al escanear, seguridad.
// Uso (carpeta con pub/ y mockfb.js): node pruebas/tcat.js   (JSON: env CATJSON)
const {chromium}=require(process.env.PW||'playwright');const {spawn}=require('child_process');const fs=require('fs');
(async()=>{
const srv=spawn('python3',['-m','http.server','8871'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();let ok=0,bad=0;const CK=(n,c,i)=>{c?ok++:bad++;console.log(c?'  ✔':'  ✘',n,i===undefined?'':i)};
const ctx=await b.newContext({viewport:{width:390,height:844},locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());
await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));
await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));
await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
await ctx.route(/openfoodfacts/,r=>r.fulfill({status:404,body:'{}'}));
const p=await ctx.newPage();const errs=[],DL=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>{DL.push(d.message());d.accept()});
const W=ms=>p.waitForTimeout(ms||300);
const setDoc=(path,o)=>p.evaluate(([path,o])=>{const b=firebase.firestore().batch();b.set({path},o);return b.commit()},[path,o]);
const getDoc=path=>p.evaluate(path=>{const[c,d]=path.split('/');return firebase.firestore().collection(c).doc(d).get().then(s=>s.exists?s.data():null)},path);
const login=async(e)=>{await p.waitForSelector('#au-e');await p.click('[data-am="up"]');await p.fill('#au-e',e);await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500)};
const uid=()=>p.evaluate(()=>firebase.auth().currentUser.uid);
await p.goto('http://localhost:8871/tienda/');await W(1200);
// --- administrador sube el catálogo
await login('jose@x.com');const ju=await uid();await setDoc('licencias/'+ju,{nombre:'Jose'});await setDoc('admins/'+ju,{nombre:'Jose'});await W(1200);
await p.click('[data-a="ajustes"] >> nth=0');await W();await p.click('#sh [data-a="admPanel"]');await W(800);
CK('panel muestra catálogo sin subir',/Todavía no has subido el catálogo/.test(await p.textContent('#sh')));
const demo=[{Nombre:'SHAMPOO PANTENE X 700 ML',Codigo:'7500435114912',CategoriaNombre:'SHAMPOOS '},{Nombre:'GASEOSA COCA X 1750',Codigo:'7702535018675',CategoriaNombre:'BEBIDAS'},{Nombre:'VIEJO',Codigo:'7700000000012',CategoriaNombre:'X',Activo:false},{Nombre:'REPE',Codigo:'7500435114912',CategoriaNombre:'Z'},{Nombre:'SIN NOMBRE',Codigo:'7700000000099',CategoriaNombre:'X'},{Nombre:'<img src=x onerror=window.PWN=1> MALO',Codigo:'7701234567877',CategoriaNombre:'<b>cat</b>'},{Nombre:'',Codigo:'7700000000100'},{Nombre:'Código raro',Codigo:'ab<c',CategoriaNombre:''}];
fs.writeFileSync('/tmp/demo.json',JSON.stringify(demo));
await p.setInputFiles('#cat-f','/tmp/demo.json');await W(600);
let t=(await p.textContent('#cat-r')).replace(/\s+/g,' ');console.log('  ',t);
CK('vista previa: 4 válidos, 1 inactivo, 1 repetido, 2 inválidos',/4 productos para subir/.test(t)&&/1 inactivos/.test(t)&&/1 con código repetido/.test(t)&&/2 sin código o nombre válido/.test(t));
await p.click('[data-a="catSube"]');await W(1500);
CK('subió',/Catálogo subido: 4/.test(await p.textContent('#cat-r')));
const d12=await getDoc('catalogo/c12'),d00=await getDoc('catalogo/c00'),meta=await getDoc('config/catalogo');
CK('c12 tiene el champú',d12&&d12.p['7500435114912']&&d12.p['7500435114912'][0]==='SHAMPOO PANTENE X 700 ML'&&d12.p['7500435114912'][1]==='SHAMPOOS',JSON.stringify(d12));
CK('inactivo no se subió',!(await getDoc('catalogo/c12')).p['7700000000012']);
CK('100 documentos (c00 existe)',!!d00&&d00.n===0);
CK('meta en config/catalogo',meta&&meta.n===4&&meta.docs===100);
CK('nombre peligroso quedó neutralizado',(await getDoc('catalogo/c77')).p['7701234567877'][0].indexOf('<img')<0);
// --- tendero escanea
await p.click('#sh [data-a="ajustes"]');await W(300);await p.evaluate(()=>document.querySelector('#ov').click());await W(300);await p.evaluate(()=>firebase.auth().signOut());await W(800);await login('tienda@x.com');
await p.fill('#pay-tel','3005556677');await p.click('#pay-try');await W(1200);
await p.click('[data-tab="inv"]');await W();
const scan=async code=>{DL.length=0;await p.click('[data-a="scanInv"]');await W(500);await p.evaluate(c=>LKT.found(c,true),code);await W(900)};
await scan('7500435114912');
CK('pregunta con el nombre del catálogo',DL.length===1&&/SHAMPOO PANTENE X 700 ML \(SHAMPOOS\)/.test(DL[0])&&/Crear el producto con este nombre/.test(DL[0]),DL[0]);
CK('formulario con nombre y código puestos',(await p.inputValue('#p-n'))==='SHAMPOO PANTENE X 700 ML'&&(await p.inputValue('#p-cod'))==='7500435114912');
CK('aviso de catálogo',/Nombre del catálogo/.test(await p.textContent('#sh')));
await p.click('#sh [data-a="cerrar"]');await W();
CK('copia local guardada',await p.evaluate(()=>!!localStorage.getItem('lkt-cat-c12')));
// desde caché: borrar el doc del servidor y volver a escanear
await p.evaluate(()=>{const b=firebase.firestore().batch();b.delete({path:'catalogo/c12'});return b.commit()});
await scan('7500435114912');CK('sigue proponiendo desde la copia local',/SHAMPOO PANTENE/.test(DL[0]||''),DL[0]);
await p.click('#sh [data-a="cerrar"]');await W();
// código que no está en el catálogo
await scan('7709999999995');CK('código desconocido: pregunta normal',DL.length===1&&/no está en tu inventario\. ¿Crear el producto ahora\?/.test(DL[0]),DL[0]);
await p.click('#sh [data-a="cerrar"]');await W();
// nombre con código escondido
await scan('7701234567877');CK('nombre peligroso: se muestra sin ejecutarse',DL.length===1&&DL[0].indexOf('<img')<0&&!(await p.evaluate(()=>window.PWN)),DL[0]);
CK('campo nombre seguro',(await p.inputValue('#p-n')).indexOf('<img')<0);
await p.click('#sh [data-a="cerrar"]');await W();
// guardar producto creado desde catálogo
await scan('7702535018675');await p.fill('#p-pv','4500');await p.click('[data-a="guardarProd"]');await W(600);
CK('producto guardado con nombre del catálogo',await p.evaluate(()=>LKT.D.prod.some(x=>x.n==='GASEOSA COCA X 1750'&&x.cod==='7702535018675')));
// con el producto ya creado, ya no pregunta
await scan('7702535018675');CK('ya existe: abre el producto, sin preguntar',DL.length===0&&(await p.inputValue('#p-n'))==='GASEOSA COCA X 1750');
CK('sin errores de página',errs.length===0,errs.join('|'));
console.log(ok+' bien, '+bad+' mal');await b.close();srv.kill();process.exit(bad?1:0)})();
