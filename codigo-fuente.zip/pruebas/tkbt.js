const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8805'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/unpkg/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const WA=[];await ctx.route(/wa\.me/,r=>{WA.push(decodeURIComponent(r.request().url()));r.fulfill({body:'<html>wa</html>',contentType:'text/html'})});
let p=await ctx.newPage();const errs=[];const hook=pg=>{pg.on('pageerror',e=>errs.push(e.message));pg.on('dialog',d=>d.accept(d.type()==='prompt'?'':undefined))};hook(p);
const S=async n=>{await p.waitForTimeout(300);await p.screenshot({path:'n'+n+'.png'})};const W=ms=>p.waitForTimeout(ms||300);
const back=async()=>{if(!p.url().includes('/tienda/')){await p.goBack();await W(1500)}};
const login=async(e,up)=>{await p.waitForSelector('#au-e');await p.click(up?'[data-am="up"]':'[data-am="in"]');await p.fill('#au-e',e);await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500)};
await p.goto('http://localhost:8805/tienda/');await W(1200);await login('t@x.com',1);await p.evaluate(()=>{const u=firebase.auth().currentUser.uid;const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()});await W(1200);
const A=()=>p.evaluate(()=>document.activeElement.id+'('+document.activeElement.enterKeyHint+')');
await p.click('[data-tab="inv"]');await p.click('[data-a="nuevoProd"]');await W();await p.click('#p-n');await p.keyboard.type('Arroz');const seq=[await A()];
for(let i=0;i<7;i++){await p.keyboard.press('Enter');await W(80);seq.push(await A())}console.log('orden:',seq.join(' → '));
// teclado de iPhone: área visible 470px
await p.click('#p-st');await p.evaluate(()=>{const v=window.visualViewport;Object.defineProperty(v,'height',{get:()=>470,configurable:true});Object.defineProperty(v,'offsetTop',{get:()=>0,configurable:true});v.dispatchEvent(new Event('resize'))});await W(500);
console.log('hoja con teclado:',await p.evaluate(()=>{const s=document.querySelector('#sh'),r=s.getBoundingClientRect(),a=document.activeElement.getBoundingClientRect();return JSON.stringify({kb:s.classList.contains('kb'),top:Math.round(r.top),h:Math.round(r.height),campoTop:Math.round(a.top),campoBottom:Math.round(a.bottom)})}));await p.screenshot({path:'kb-t.png',clip:{x:0,y:0,width:390,height:470}});
await p.evaluate(()=>{const v=window.visualViewport;Object.defineProperty(v,'height',{get:()=>844,configurable:true});v.dispatchEvent(new Event('resize'))});await W(300);console.log('sin teclado kb:',await p.evaluate(()=>document.querySelector('#sh').classList.contains('kb')));
// buscador: Enter elige el primero
await p.fill('#p-n','Arroz');await p.fill('#p-pv','2000');await p.fill('#p-prov-s','Ramo');await p.click('[data-a="guardarProd"]');await W(300);
await p.click('[data-a="nuevoProd"]');await W();await p.fill('#p-prov-s','ram');await W(150);await p.focus('#p-prov-s');await p.keyboard.press('Enter');await W(150);console.log('Enter en buscador:',await p.inputValue('#p-prov-s'),'| id',await p.inputValue('#p-prov')!=='');
console.log('errs',errs);await b.close();srv.kill();})();