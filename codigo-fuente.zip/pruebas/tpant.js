const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');(async()=>{
const srv=spawn('python3',['-m','http.server','8807'],{cwd:process.cwd()+'/pub',stdio:'ignore'});await new Promise(r=>setTimeout(r,800));
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},locale:'es-CO',serviceWorkers:'block'});await ctx.route(/fonts\.g/,r=>r.abort());await ctx.route(/unpkg/,r=>r.abort());await ctx.route(/firebase-app-compat/,r=>r.fulfill({body:fs.readFileSync('mockfb.js','utf8'),contentType:'application/javascript'}));await ctx.route(/firebase-(auth|firestore|messaging)-compat/,r=>r.fulfill({body:'',contentType:'application/javascript'}));await ctx.route(/config\.js/,r=>r.fulfill({body:'window.LUKS_FB={apiKey:"x"}',contentType:'application/javascript'}));
const WA=[];await ctx.route(/wa\.me/,r=>{WA.push(decodeURIComponent(r.request().url()));r.fulfill({body:'<html>wa</html>',contentType:'text/html'})});
let p=await ctx.newPage();const errs=[];const hook=pg=>{pg.on('pageerror',e=>errs.push(e.message));pg.on('dialog',d=>d.accept(d.type()==='prompt'?'':undefined))};hook(p);
const S=async n=>{await p.waitForTimeout(300);await p.screenshot({path:'n'+n+'.png'})};const W=ms=>p.waitForTimeout(ms||300);
const back=async()=>{if(!p.url().includes('/tienda/')){await p.goBack();await W(1500)}};
const login=async(e,up)=>{await p.waitForSelector('#au-e');await p.click(up?'[data-am="up"]':'[data-am="in"]');await p.fill('#au-e',e);await p.fill('#au-p','secreto1');await p.click('#au-go');await W(1500)};
await p.goto('http://localhost:8807/tienda/');await W(1200);await login('t@x.com',1);await p.evaluate(()=>{const u=firebase.auth().currentUser.uid;const b=firebase.firestore().batch();b.set({path:'licencias/'+u},{});return b.commit()});await W(1200);
const bg=()=>p.evaluate(()=>getComputedStyle(document.body).backgroundColor+' fs='+document.documentElement.getAttribute('data-fs')+' th='+document.documentElement.getAttribute('data-theme'));
console.log('inicio',await bg());
await p.click('[data-a="ajustes"] >> nth=0');await W();await p.click('[data-pth="dark"]');await W(200);console.log('oscuro',await bg());
await p.click('[data-pfs="2"]');await W(300);await p.screenshot({path:'fs2.png'});console.log('muy grande',await bg(),'| ancho hoja',await p.evaluate(()=>Math.round(document.querySelector('#sh').getBoundingClientRect().right)));
await p.reload();await W(2500);console.log('tras recargar',await bg());await p.screenshot({path:'fs2-main.png'});
await p.click('[data-a="ajustes"] >> nth=0');await W();await p.click('[data-pth="auto"]');await p.click('[data-pfs="0"]');await W(200);console.log('vuelta',await bg());
console.log('errs',errs);await b.close();srv.kill();})();