const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1024,height:1024}});
for(const n of ['luks','tienda']){await p.goto('file:///home/claude/v3/work/icon/'+n+'.svg');await p.screenshot({path:'/home/claude/v3/work/icon/'+n+'-1024.png'})}await b.close()})();
