import base64
import os;d=os.path.dirname(os.path.abspath(__file__))+"/"
s=open(d+"conoce.src.html").read()
b=lambda f:"data:image/jpeg;base64,"+base64.b64encode(open(d+f,"rb").read()).decode()
wa="https://wa.me/573137904093?text=Hola%2C%20quiero%20saber%20m%C3%A1s%20de%20Lu-Ks%20Tienda"
ic='<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><path d="M12.04 2a9.9 9.9 0 0 0-8.5 15l-1.4 5 5.1-1.3A9.9 9.9 0 1 0 12.04 2zm5.8 14.1c-.25.7-1.43 1.33-1.98 1.38-.5.05-.98.24-3.3-.69-2.8-1.1-4.56-3.95-4.7-4.13-.13-.18-1.1-1.47-1.1-2.8s.7-1.99.95-2.26c.25-.27.54-.34.72-.34h.52c.17 0 .4-.06.62.47.25.6.84 2.05.91 2.2.08.15.13.32.03.5-.1.19-.15.3-.3.47l-.44.51c-.15.15-.3.31-.13.6.17.3.76 1.25 1.63 2.03 1.12 1 2.06 1.3 2.36 1.45.29.15.46.12.63-.07.17-.2.73-.85.92-1.14.2-.3.38-.25.65-.15.26.1 1.68.8 1.97.94.29.15.48.22.55.34.07.12.07.7-.18 1.39z"/></svg>'
s=s.replace("__LOGO32__",'<img src="icon-192.png" width="32" height="32" alt="" style="border-radius:9px">')
s=s.replace("__WA__",wa).replace("__WAICON__",ic).replace("__POSTER__",b("poster.jpg"))
for i,f in enumerate(["t-venta.jpg","t-caja.jpg","t-fiados.jpg","t-inv.jpg"],1): s=s.replace("__S%d__"%i,b(f))
assert "__" not in s.replace("__agentproxy","")
open(d+"conoce.html","w").write(s); print(len(s))
