#!/bin/bash
# Voz del video de Lu-Ks Tienda: frases en su escena, música baja bajo la voz, bips del escáner sin bajar.
set -e
V=tienda.mp3; M=../audio/musica-tienda-sinbip.wav; BIP=../audio/bips.wav; VID=../video-tienda.mp4; OUT=../video-tienda-voz.mp4
ffmpeg -y -loglevel error -i $V -i $M -i $VID -i $BIP -filter_complex "
[0:a]aresample=44100,aformat=channel_layouts=mono,highpass=f=80,equalizer=f=3500:t=q:w=1.2:g=2,acompressor=threshold=-20dB:ratio=3:attack=8:release=120,asplit=6[a1][a2][a3][a4][a5][a6];
[a1]atrim=0:0.95,asetpts=PTS-STARTPTS,adelay=1000|1000[p1];
[a2]atrim=1.25:4.33,asetpts=PTS-STARTPTS,adelay=3700|3700[p2];
[a3]atrim=4.60:7.50,asetpts=PTS-STARTPTS,adelay=9200|9200[p3];
[a4]atrim=7.78:10.32,asetpts=PTS-STARTPTS,adelay=13200|13200[p4];
[a5]atrim=10.55:12.45,asetpts=PTS-STARTPTS,adelay=17300|17300[p5];
[a6]atrim=12.78:15.80,asetpts=PTS-STARTPTS,adelay=21100|21100[p6];
[p1][p2][p3][p4][p5][p6]amix=inputs=6:normalize=0,apad=whole_dur=25,atrim=0:25,aformat=channel_layouts=stereo,volume=1.9[voz];
[voz]asplit=2[vk][vm];
[1:a]aresample=44100,volume=0.55[mus];
[mus][vk]sidechaincompress=threshold=0.012:ratio=14:attack=15:release=400:makeup=1[musd];
[3:a]aresample=44100,volume=0.9[bip];
[musd][vm][bip]amix=inputs=3:normalize=0,loudnorm=I=-14:TP=-1.5:LRA=11[out]" \
-map 2:v -map "[out]" -c:v copy -c:a aac -b:a 192k -ar 44100 -t 25 -movflags +faststart $OUT
