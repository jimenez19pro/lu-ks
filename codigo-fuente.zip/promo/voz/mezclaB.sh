#!/bin/bash
# Coloca cada frase de la voz en su escena, baja la música bajo la voz y une todo al video.
set -e
V=tomaB.mp3; M=../audio/musica.wav; VID=../LuKs-promo.mp4
ffmpeg -y -loglevel error -i $V -i $M -i $VID -filter_complex "
[0:a]aresample=44100,aformat=channel_layouts=mono,highpass=f=80,equalizer=f=3500:t=q:w=1.2:g=2,acompressor=threshold=-20dB:ratio=3:attack=8:release=120,asplit=5[a1][a2][a3][a4][a5];
[a1]atrim=0:1.70,asetpts=PTS-STARTPTS,adelay=500|500[p1];
[a2]atrim=2.06:8.00,asetpts=PTS-STARTPTS,atempo=1.10,adelay=3150|3150[p2];
[a3]atrim=8.27:9.43,asetpts=PTS-STARTPTS,adelay=8700|8700[p3];
[a4]atrim=9.62:16.05,asetpts=PTS-STARTPTS,adelay=10150|10150[p4];
[a5]atrim=16.30:21.47,asetpts=PTS-STARTPTS,atempo=1.04,adelay=16950|16950[p5];
[p1][p2][p3][p4][p5]amix=inputs=5:normalize=0,apad=whole_dur=22,atrim=0:22,aformat=channel_layouts=stereo,volume=1.9[voz];
[voz]asplit=2[vk][vm];
[1:a]aresample=44100,volume=0.55[mus];
[mus][vk]sidechaincompress=threshold=0.012:ratio=14:attack=15:release=400:makeup=1[musd];
[musd][vm]amix=inputs=2:normalize=0,loudnorm=I=-14:TP=-1.5:LRA=11[out]" \
-map 2:v -map "[out]" -c:v copy -c:a aac -b:a 192k -ar 44100 -t 22 -movflags +faststart ../LuKs-promo-vozB.mp4
