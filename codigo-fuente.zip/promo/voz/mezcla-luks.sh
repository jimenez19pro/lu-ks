#!/bin/bash
# Voz del video de Lu-Ks: cada frase en su escena, música baja bajo la voz.
set -e
V=luks.mp3; M=../audio/musica-luks.wav; VID=../video-luks.mp4; OUT=../video-luks-voz.mp4
ffmpeg -y -loglevel error -i $V -i $M -i $VID -filter_complex "
[0:a]aresample=44100,aformat=channel_layouts=mono,highpass=f=80,equalizer=f=3500:t=q:w=1.2:g=2,acompressor=threshold=-20dB:ratio=3:attack=8:release=120,asplit=6[a1][a2][a3][a4][a5][a6];
[a1]atrim=0:1.70,asetpts=PTS-STARTPTS,adelay=600|600[p1];
[a2]atrim=2.00:5.50,asetpts=PTS-STARTPTS,adelay=3900|3900[p2];
[a3]atrim=5.75:8.48,asetpts=PTS-STARTPTS,adelay=8900|8900[p3];
[a4]atrim=8.72:10.95,asetpts=PTS-STARTPTS,adelay=13100|13100[p4];
[a5]atrim=11.10:12.85,asetpts=PTS-STARTPTS,adelay=17400|17400[p5];
[a6]atrim=13.20:16.85,asetpts=PTS-STARTPTS,adelay=21050|21050[p6];
[p1][p2][p3][p4][p5][p6]amix=inputs=6:normalize=0,apad=whole_dur=25,atrim=0:25,aformat=channel_layouts=stereo,volume=1.9[voz];
[voz]asplit=2[vk][vm];
[1:a]aresample=44100,volume=0.55[mus];
[mus][vk]sidechaincompress=threshold=0.012:ratio=14:attack=15:release=400:makeup=1[musd];
[musd][vm]amix=inputs=2:normalize=0,loudnorm=I=-14:TP=-1.5:LRA=11[out]" \
-map 2:v -map "[out]" -c:v copy -c:a aac -b:a 192k -ar 44100 -t 25 -movflags +faststart $OUT
