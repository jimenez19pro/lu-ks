# Genera los videos individuales (Lu-Ks y Lu-Ks Tienda) a partir de una lista de escenas.
import sys
CSS=open('promo.css',encoding='utf-8').read()
EZ='cubic-bezier(.16,1,.3,1)'
IC={'plus':'<path d="M12 5v14M5 12h14"/>','clock':'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>','trend':'<path d="M4 17l6-6 4 4 6-7"/><path d="M14 8h6v6"/>',
'wallet':'<rect x="3" y="6" width="18" height="13" rx="3"/><path d="M16 12.5h2"/><path d="M3 9h18"/>','spark':'<path d="M12 3.5 13.8 9 19.5 11 13.8 13 12 18.5 10.2 13 4.5 11 10.2 9z"/>',
'tag':'<path d="M3.5 12.5V5a1.5 1.5 0 0 1 1.5-1.5h7.5l8 8-9 9z"/><circle cx="8" cy="8" r="1.4"/>','bell':'<path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15z"/><path d="M10 20.5a2 2 0 0 0 4 0"/>',
'target':'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/>','check':'<path d="M5 12.5l4.5 4.5L19 7.5"/>',
'scan':'<path d="M4 7V5a1 1 0 0 1 1-1h2M17 4h2a1 1 0 0 1 1 1v2M20 17v2a1 1 0 0 1-1 1h-2M7 20H5a1 1 0 0 1-1-1v-2M7 8v8M10 8v8M13 8v8M16 8v8"/>',
'wa':'<path d="M21 12a9 9 0 0 1-13.4 7.9L3 21l1.1-4.6A9 9 0 1 1 21 12z"/>','qr':'<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><path d="M14 14h2v2h-2zM18 18h2v2h-2zM14 18h2"/>',
'cam':'<path d="M4 8.5A1.5 1.5 0 0 1 5.5 7h2l1.5-2h6l1.5 2h2A1.5 1.5 0 0 1 20 8.5v9a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 17.5z"/><circle cx="12" cy="12.5" r="3.2"/>',
'box':'<path d="M3.5 7.5 12 3l8.5 4.5v9L12 21l-8.5-4.5z"/><path d="M3.5 7.5 12 12l8.5-4.5M12 12v9"/>','cloud':'<path d="M7 18a4.5 4.5 0 0 1-.5-9A6 6 0 0 1 18 9.5a4 4 0 0 1-1 8.5z"/>','lock':'<rect x="5" y="10.5" width="14" height="10" rx="2"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>',
'phone':'<rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M11 18.5h2"/>'}
def ico(k):return '<svg class="i" viewBox="0 0 24 24">'+IC[k]+'</svg>'
def chip(txt,k,t0,t1,pos):
    return '<div style="position:absolute;%s"><div class="chip" style="animation:up .7s %s %.2fs both,sOut .3s ease %.2fs forwards"><span class="ic">%s</span>%s</div></div>'%(pos,EZ,t0,t1,ico(k),txt)
LUKS_MARK='''<svg viewBox="0 0 92 92" width="%d" height="%d"><rect x="2" y="2" width="88" height="88" rx="24" fill="#0A84FF" stroke="rgba(255,255,255,.25)" stroke-width="1.2"/><path d="M20 64 L36 52 L46 56 L58 42 L72 30 L72 92 L20 92 Z" fill="#FFFFFF" fill-opacity=".16"/><polyline points="20,64 36,52 46,56 58,42 72,30" fill="none" stroke="#FFFFFF" stroke-width="4.2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="72" cy="30" r="5" fill="#FFFFFF"/></svg>'''
STORE='''<rect x="2" y="2" width="88" height="88" rx="24" fill="url(#tt)"/><rect %s x="21" y="36" width="50" height="38" rx="3" fill="#EAF1FF"/><rect %s x="26" y="47" width="11" height="10" rx="2" fill="#B8CCFF"/><rect %s x="55" y="47" width="11" height="10" rx="2" fill="#B8CCFF"/><rect %s x="40" y="50" width="12" height="24" rx="3" fill="#2F7BFF"/><rect %s x="14" y="21" width="64" height="6" rx="3" fill="#FFFFFF"/>'''
def store(anim=False,size=46):
    A=lambda d,k: ('style="transform-box:fill-box;transform-origin:50%% %s;animation:%s"'%(('100%' if k=='rise' else '0'),d)) if anim else ''
    body=STORE%(A('rise2 .5s %s .45s both'%EZ,'rise'),A('fadeIn .5s ease 1.0s both;opacity:0',''),A('fadeIn .5s ease 1.1s both;opacity:0',''),A('fadeIn .4s ease .9s both;opacity:0',''),A('drop .4s %s .6s both'%EZ,'drop'))
    cols=['#FFFFFF','#C9DBFF','#FFFFFF','#C9DBFF','#FFFFFF']
    aw=''.join('<path d="M%d 26h12v10a6 6 0 0 1-12 0z" fill="%s" %s/>'%(16+12*k,cols[k],A('drop .42s %s %.2fs both'%(EZ,.65+.06*k),'drop')) for k in range(5))
    return '<svg viewBox="0 0 92 92" width="%d" height="%d"><defs><linearGradient id="tt" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5AC8FA"/><stop offset="1" stop-color="#5E3BE0"/></linearGradient><linearGradient id="sw2" x1="0" x2="1"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".28"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient><clipPath id="c2"><rect x="2" y="2" width="88" height="88" rx="24"/></clipPath></defs>'%(size,size)+body+aw+('<g clip-path="url(#c2)"><g transform="rotate(18 46 46)"><rect x="10" y="-20" width="40" height="132" fill="url(#sw2)" style="animation:sweep .9s cubic-bezier(.4,0,.2,1) 1.35s both"/></g></g>' if anim else '')+'</svg>'
def page(title,DUR,accent,glow,body):
    extra='@keyframes rise2{from{opacity:0;transform:translateY(8px) scaleY(.7)}to{opacity:1;transform:none}}@keyframes drop{from{opacity:0;transform:translateY(-9px)}to{opacity:1;transform:none}}@keyframes ph{to{transform:translateY(60px) scale(.94);opacity:0}}'
    return '<!doctype html><html lang="es"><head><meta charset="utf-8"><title>%s</title><style>%s %s .acc{--ac:%s}.acc .h b{color:%s}.acc .chip .ic{background:color-mix(in srgb,%s 18%%,transparent);color:%s}</style></head><body><div class="st acc"><div class="bgg" style="background:radial-gradient(circle,%s,transparent 60%%);animation:sIn 1s ease 0s both"></div><div class="grid" style="animation:drift %ds linear 0s both"></div>%s</div></body></html>'%(title,CSS,extra,accent,accent,accent,accent,glow,DUR,body)
def heads(items):
    # items: (html,t_in,t_out)
    h='<div style="position:absolute;left:0;right:0;top:64px;height:120px">'
    for html,a,b in items:
        h+='<div class="h" style="position:absolute;inset:0;font-size:40px;animation:up .8s %s %.2fs both%s">%s</div>'%(EZ,a,(',sOut .35s ease %.2fs forwards'%b) if b else '',html)
    return h+'</div>'
def phone(shots,t_in,t_out):
    h='<div class="phone" style="top:236px;left:139px;animation:upBig 1s %s %.2fs both,ph .6s cubic-bezier(.4,0,.2,1) %.2fs forwards"><div class="isl"></div><div class="scr">'%(EZ,t_in,t_out)
    for k,(src,a) in enumerate(shots):
        nxt=shots[k+1][1] if k+1<len(shots) else None
        st='opacity:0;' if k else ''
        an=[]
        if k: an.append('sIn .45s ease %.2fs forwards'%a)
        if nxt: an.append('sOut .45s ease %.2fs forwards'%nxt)
        h+='<img src="%s" style="%sanimation:%s">'%(src,st,','.join(an) if an else 'none')
    return h+'%s</div></div>'
# ---------------- Lu-Ks ----------------
def luks():
    D=25
    b='''<div class="sc" style="justify-content:center;animation:sOut .45s ease 2.8s forwards">
    <svg class="mark" viewBox="0 0 92 92" style="animation:pop .8s %s .15s both"><defs><linearGradient id="sw1" x1="0" x2="1"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".25"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient><clipPath id="c1"><rect x="2" y="2" width="88" height="88" rx="24"/></clipPath></defs>
      <rect x="2" y="2" width="88" height="88" rx="24" fill="#0A84FF" stroke="rgba(255,255,255,.25)" stroke-width="1.2"/>
      <g clip-path="url(#c1)"><path d="M20 64 L36 52 L46 56 L58 42 L72 30 L72 92 L20 92 Z" fill="#FFFFFF" style="opacity:0;animation:fadeIn .6s ease 1s forwards;fill-opacity:.16"/><g transform="rotate(18 46 46)"><rect x="10" y="-20" width="40" height="132" fill="url(#sw1)" style="animation:sweep .9s cubic-bezier(.4,0,.2,1) 1.3s both"/></g></g>
      <polyline points="20,64 36,52 46,56 58,42 72,30" fill="none" stroke="#FFFFFF" stroke-width="4.2" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="70" stroke-dashoffset="70" style="animation:draw .8s cubic-bezier(.65,0,.35,1) .5s forwards"/>
      <circle cx="72" cy="30" r="5" fill="none" stroke="#FFFFFF" stroke-width="1.6" style="transform-box:fill-box;transform-origin:center;opacity:0;animation:ring 1s ease-out 1.35s forwards"/>
      <circle cx="72" cy="30" r="5" fill="#FFFFFF" style="transform-box:fill-box;transform-origin:center;animation:dot .4s %s 1.25s both"/></svg>
    <div class="word" style="font-size:78px;margin-top:30px">'''%(EZ,EZ)+''.join('<span><i style="animation:rise .7s %s %.2fs both%s">%s</i></span>'%(EZ,.75+.06*k,';color:var(--ac)' if c=='-' else '',c) for k,c in enumerate('Lu-Ks'))+'''</div>
    <div class="tag" style="font-size:17px;margin-top:18px;animation:up .8s %s 1.2s both">Tus finanzas, claras</div></div>'''%EZ
    b+='<div class="sc" style="animation:sIn .4s ease 3.1s both,sOut .5s ease 20.7s forwards">'
    b+=heads([('Sabe en qué se va<br><b>tu plata</b>',3.25,8.0),('Anota un gasto<br><b>en segundos</b>',8.35,12.2),('Presupuestos que<br><b>sí se cumplen</b>',12.55,16.4),('Mira cómo vas<br><b>mes a mes</b>',16.75,20.5)])
    b+=phone([('l2-home.png',0),('l2-mov.png',8.2),('l2-pres.png',12.4),('l2-rep.png',16.6),('l2-aho.png',18.6)],3.45,20.4)%''
    b+=chip('Cuánto te queda este mes','wallet',4.6,8.0,'left:22px;top:430px')+chip('Todas tus cuentas juntas','tag',5.3,8.0,'right:18px;top:640px')
    b+=chip('Con IA o foto del recibo','spark',9.2,12.2,'left:22px;top:460px')+chip('Categorías automáticas','check',9.9,12.2,'right:18px;top:690px')
    b+=chip('Cuánto puedes gastar hoy','clock',13.4,16.4,'left:22px;top:450px')+chip('Te avisa antes de pasarte','bell',14.1,16.4,'right:18px;top:680px')
    b+=chip('Tendencia de 6 meses','trend',17.5,20.4,'left:22px;top:440px')+chip('Metas y plan de deudas','target',18.9,20.4,'right:18px;top:690px')
    b+='</div>'
    b+='''<div class="sc" style="justify-content:center;animation:sIn .5s ease 20.8s both">
    <div style="animation:pop .8s %s 20.9s both">%s</div>
    <div class="h" style="font-size:48px;margin-top:34px;animation:up .8s %s 21.2s both">Tus finanzas,<br><b>claras</b></div>
    <div style="display:flex;flex-direction:column;gap:12px;margin-top:30px;align-items:center">
      <div class="chip" style="animation:up .7s %s 21.7s both"><span class="ic">%s</span>Gratis y sin anuncios</div>
      <div class="chip" style="animation:up .7s %s 22.0s both"><span class="ic">%s</span>Se instala en tu celular</div></div>
    <div style="margin-top:38px;padding:16px 26px;border-radius:22px;background:var(--ac);color:#fff;font-weight:800;font-size:22px;animation:pop .7s %s 22.5s both">jimenez19pro.github.io/lu-ks</div>
    <div class="tag" style="font-size:14px;margin-top:22px;letter-spacing:.12em;animation:up .7s %s 22.9s both">Hecho en Colombia 🇨🇴</div></div>'''%(EZ,LUKS_MARK%(110,110),EZ,EZ,ico('check'),EZ,ico('phone'),EZ,EZ)
    return page('Lu-Ks video',D,'#0A84FF','rgba(10,132,255,.26)',b)
# ---------------- Tienda ----------------
def tienda():
    D=25
    b='''<div class="sc" style="justify-content:center;animation:sOut .45s ease 2.8s forwards">
    <div style="width:124px;height:124px;animation:pop .8s %s .1s both;filter:drop-shadow(0 18px 40px rgba(251,146,60,.4))">%s</div>
    <div class="word" style="font-size:62px;margin-top:30px"><span><i style="animation:rise .7s %s .8s both">Lu-Ks</i></span><span><i style="animation:rise .7s %s .88s both;color:var(--ac);margin-left:.22em">Tienda</i></span></div>
    <div class="tag" style="font-size:16px;margin-top:18px;animation:up .8s %s 1.2s both">Caja · Fiados · Inventario</div></div>'''%(EZ,store(True,124),EZ,EZ,EZ)
    b+='<div class="sc" style="animation:sIn .4s ease 3.1s both,sOut .5s ease 20.7s forwards">'
    b+=heads([('Vende escaneando,<br><b>como en el súper</b>',3.25,8.4),('Sabe cuánto vendiste<br><b>y cuánto ganaste</b>',8.75,12.4),('Fiados claros,<br><b>cobros por WhatsApp</b>',12.75,16.4),('Tu inventario<br><b>siempre al día</b>',16.75,20.5)])
    ph=phone([('t-venta.png',0),('t-caja.png',8.6),('t-fiados.png',12.6),('t-inv.png',16.6)],3.45,20.4)
    beam='<div style="position:absolute;left:8%%;right:8%%;height:3px;border-radius:2px;background:#22C55E;box-shadow:0 0 18px 4px rgba(34,197,94,.6);animation:beam 1.6s ease-in-out 4.2s 2 both;opacity:0"></div>'
    b+=ph%beam
    for k,(txt,t) in enumerate([('✓ Gaseosa 400 ml · $3.000',4.6),('✓ Arroz Diana 500 g · $3.200',5.4),('✓ Huevos AA x 30 · $16.500',6.2)]):
        b+='<div style="position:absolute;left:0;right:0;top:%dpx;display:flex;justify-content:center"><div class="chip" style="background:#16a34a;border:0;opacity:0;animation:bip 1s ease %.2fs both">%s</div></div>'%(440+k*70,t,txt)
    b+=chip('Cierre de caja en un toque','lock',9.6,12.4,'left:22px;top:450px')+chip('Resumen del día por WhatsApp','wa',10.3,12.4,'right:14px;top:690px')
    b+=chip('Recordatorio para cobrar','bell',13.6,16.4,'left:22px;top:450px')+chip('QR de Nequi y Bre-B','qr',14.3,16.4,'right:18px;top:690px')
    b+=chip('Foto a la factura con IA','cam',17.5,20.4,'left:22px;top:440px')+chip('Aviso de lo que se acaba','box',18.2,20.4,'right:18px;top:690px')
    b+='</div>'
    b+='''<div class="sc" style="justify-content:center;animation:sIn .5s ease 20.8s both">
    <div style="animation:pop .8s %s 20.9s both;filter:drop-shadow(0 18px 40px rgba(251,146,60,.35))">%s</div>
    <div class="h" style="font-size:48px;margin-top:34px;animation:up .8s %s 21.2s both">Tu tienda,<br><b>en orden</b></div>
    <div style="display:flex;flex-direction:column;gap:12px;margin-top:30px;align-items:center">
      <div class="chip" style="animation:up .7s %s 21.7s both"><span class="ic">%s</span>Prueba gratis 30 días</div>
      <div class="chip" style="animation:up .7s %s 22.0s both"><span class="ic">%s</span>Tus datos guardados en la nube</div></div>
    <div style="margin-top:38px;padding:16px 22px;border-radius:22px;background:var(--ac);color:#fff;font-weight:800;font-size:20px;animation:pop .7s %s 22.5s both">jimenez19pro.github.io/lu-ks/tienda</div>
    <div class="tag" style="font-size:14px;margin-top:22px;letter-spacing:.12em;animation:up .7s %s 22.9s both">WhatsApp 313 790 4093 · Hecho en Colombia 🇨🇴</div></div>'''%(EZ,store(False,110),EZ,EZ,ico('check'),EZ,ico('cloud'),EZ,EZ)
    return page('Lu-Ks Tienda video',D,'#0A84FF','rgba(10,132,255,.26)',b)
open('video-luks.html','w',encoding='utf-8').write(luks())
open('video-tienda.html','w',encoding='utf-8').write(tienda())
print('ok')
