// node render2.js archivo.html duracion(s) carpeta [preview t1,t2,...]
const {chromium}=require('playwright');const fs=require('fs');(async()=>{
const [file,dur,dir,prev]=process.argv.slice(2);const fps=30;
const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:540,height:960},deviceScaleFactor:2})).newPage();
await p.goto('file:///home/claude/promo/'+file);await p.waitForTimeout(800);
await p.evaluate(()=>document.getAnimations().forEach(a=>a.pause()));
const at=async ms=>{await p.evaluate(t=>document.getAnimations().forEach(a=>{a.currentTime=t}),ms)};
fs.mkdirSync(dir,{recursive:true});
if(prev){for(const t of prev.split(',').map(Number)){await at(t);await p.waitForTimeout(60);await p.screenshot({path:dir+'/pv'+t+'.jpg',type:'jpeg',quality:80})}}
else{const N=Math.round(fps*dur);for(let f=0;f<N;f++){await at(f*1000/fps);await p.screenshot({path:dir+'/'+String(f).padStart(4,'0')+'.jpg',type:'jpeg',quality:93})}}
await b.close();console.log('done')})();
