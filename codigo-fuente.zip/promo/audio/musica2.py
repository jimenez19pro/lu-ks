# Música original para el video promocional de Lu-Ks (22 s, 120 BPM, Re mayor). Sin muestras externas.
import numpy as np, scipy.signal as sg, scipy.io.wavfile as wf
import sys
SR=44100; DUR=float(sys.argv[2]); KEY=int(sys.argv[3]); MODE=sys.argv[1]; N=int(SR*DUR); rng=np.random.default_rng(7)
L=np.zeros(N); R=np.zeros(N)
def add(sig,t,pan=0.0,g=1.0):
    i=int(t*SR); j=min(N,i+len(sig)); 
    if i>=N: return
    s=sig[:j-i]*g; L[i:j]+=s*np.sqrt((1-pan)/2); R[i:j]+=s*np.sqrt((1+pan)/2)
def env(n,a,d,s=0.0,r=None):
    t=np.arange(n)/SR; e=np.minimum(t/max(a,1e-4),1.0); e*=np.exp(-np.maximum(t-a,0)/d)*(1-s)+s
    if r: e*=np.clip((n/SR-t)/r,0,1)
    return e
def hz(m): return 440*2**((m-69)/12)
def lp(x,fc,o=2): b,a=sg.butter(o,fc/(SR/2),'low'); return sg.lfilter(b,a,x)
def hp(x,fc,o=2): b,a=sg.butter(o,fc/(SR/2),'high'); return sg.lfilter(b,a,x)
def bp(x,lo,hi): b,a=sg.butter(2,[lo/(SR/2),hi/(SR/2)],'band'); return sg.lfilter(b,a,x)
def saw(f,n,det=0.0):
    t=np.arange(n)/SR; x=np.zeros(n)
    for k in range(1,14):
        if f*k>9000: break
        x+=np.sin(2*np.pi*f*k*(1+det)*t)/k
    return x
# ---------- instrumentos ----------
def kick(g=1.0):
    n=int(.32*SR); t=np.arange(n)/SR; f=45+75*np.exp(-t/.045); ph=2*np.pi*np.cumsum(f)/SR
    return np.sin(ph)*np.exp(-t/.13)*g+ lp(rng.standard_normal(n),3000)*np.exp(-t/.004)*.25*g
def clap():
    n=int(.2*SR); x=bp(rng.standard_normal(n),900,5000); e=np.zeros(n)
    for o in (0,.011,.022): e+=np.exp(-np.maximum(np.arange(n)/SR-o,0)/.012)*(np.arange(n)/SR>=o)
    return x*(e*.35+np.exp(-np.arange(n)/SR/.07)*.5)*.5
def hat(open_=False):
    n=int((.18 if open_ else .05)*SR); return hp(rng.standard_normal(n),7000)*np.exp(-np.arange(n)/SR/(.06 if open_ else .015))*.22
def bass(m,d):
    n=int(d*SR); sw=saw(hz(m),n); x=lp(sw,520,2)+lp(sw,1600,2)*np.exp(-np.arange(n)/SR/.05)*.5
    return x*env(n,.004,.25,.55,.03)*.55
def pluck(m,d=.35):
    n=int(d*SR); f=hz(m); t=np.arange(n)/SR
    x=np.sin(2*np.pi*f*t)+.45*np.sin(2*np.pi*2*f*t)+.18*np.sin(2*np.pi*3*f*t)+.08*np.sin(2*np.pi*4.01*f*t)
    return x*env(n,.002,.13)*.22
def pad(ms,d,a=.6,bright=1800):
    n=int(d*SR); x=np.zeros(n)
    for m in ms:
        for dt in (-.004,0,.0045): x+=saw(hz(m),n,dt)
    x=lp(x,bright,2); e=np.minimum(np.arange(n)/SR/a,1)*np.clip((d-np.arange(n)/SR)/.5,0,1)
    return x*e*.035
def bell(m,d=1.6,g=.25):
    n=int(d*SR); t=np.arange(n)/SR; f=hz(m); x=np.zeros(n)
    for k,a,dc in ((1,1,.9),(2.76,.35,.35),(5.4,.18,.18),(8.9,.08,.1)): x+=a*np.sin(2*np.pi*f*k*t)*np.exp(-t/dc)
    return x*np.minimum(t/.003,1)*g
def beep():  # el mismo "bip" de la app (1500 Hz)
    n=int(.13*SR); t=np.arange(n)/SR; return (np.sin(2*np.pi*2600*t)+.3*np.sin(2*np.pi*5200*t))*np.minimum(t/.003,1)*np.clip((.13-t)/.025,0,1)*.55
def whoosh(d=.7,lo=300,hi=6000,g=.45,rise=True):
    n=int(d*SR); x=rng.standard_normal(n); out=np.zeros(n); seg=512
    for i in range(0,n,seg):
        p=i/n; f=(lo*(hi/lo)**p) if rise else (hi*(lo/hi)**p)
        b,a=sg.butter(2,[max(f*.6,40)/(SR/2),min(f*1.6,20000)/(SR/2)],'band'); out[i:i+seg]=sg.lfilter(b,a,x[i:i+seg])
    e=np.sin(np.pi*np.linspace(0,1,n))**1.6
    return out*e*g
def impact():
    n=int(1.2*SR); t=np.arange(n)/SR
    return (np.sin(2*np.pi*(40+60*np.exp(-t/.05))*t)*np.exp(-t/.35)*.7+lp(rng.standard_normal(n),1200)*np.exp(-t/.25)*.35)
# ---------- armonía ----------
B=0.5  # una pulsación = 0,5 s
CH=[(50,[62,66,69,74]),(45,[61,64,69,73]),(47,[62,66,71,74]),(43,[62,67,71,74])]  # D A Bm G
def chord_at(t,t0): return CH[int(((t-t0)/(4*B)))%4]

CH=[(r+KEY,[n+KEY for n in ns]) for r,ns in CH]
def T(m): return m+KEY
def groove(t0,t1,bright=False):
    nb=int(round((t1-t0)/B))
    for b in range(nb):
        t=t0+b*B; root,ch=chord_at(t,t0)
        add(kick(.95),t)
        if b%2==1: add(clap(),t,pan=.05)
        add(hat(),t+B/2,pan=.35)
        if bright: add(hat(),t+B/4,pan=-.35,g=.6); add(hat(),t+3*B/4,pan=-.35,g=.6)
        if b%4==3 and bright: add(hat(True),t+B/2,pan=.4)
        for h in range(2): add(bass(root+12 if (b%4==3 and h) else root,B/2),t+h*B/2)
        notes=ch+[ch[1]+12] if bright else ch
        for s_ in range(4):
            m=notes[(b*4+s_)%len(notes)]+(12 if bright else 0)
            add(pluck(m),t+s_*B/4,pan=(-.45 if s_%2 else .45))
        if b%4==0: add(pad(ch,4*B+.3,a=.25,bright=2400 if bright else 1600),t)
def intro(sting):
    add(pad([T(62),T(66),T(69)],3.4,a=1.2,bright=1200),0.0)
    add(whoosh(1.0,200,3000,.18),0.05,pan=-.2)
    for k,m in enumerate([74,78,81,86]): add(bell(T(m),1.4,.10),0.55+k*.12,pan=(-.4+k*.27))
    add(bell(T(86),2.2,.22),sting,pan=.1); add(bell(T(93),1.6,.08),sting+.05,pan=.3)
    add(whoosh(.55,4000,300,.2,rise=False),2.75,pan=.3)
def outro(t0):
    add(whoosh(.8,200,8000,.36),t0-.85,pan=-.3)
    add(impact(),t0,g=.8)
    add(pad([T(50),T(62),T(66),T(69),T(74),T(78)],DUR-t0+.1,a=.08,bright=2600),t0,g=1.15)
    add(bass(T(38),3.0),t0,g=1.1)
    for k,m in enumerate([74,78,81,86,90]): add(bell(T(m),1.8,.09),t0+.05+k*.09,pan=(-.5+k*.25))
    add(bell(T(86),2.5,.18),t0+1.7,pan=0); add(bell(T(93),2.0,.07),t0+1.75,pan=.3)
    for k in range(8): add(pluck([T(74),T(78),T(81),T(86)][k%4]+12,.5),t0+2.0+k*B/2,pan=(.5 if k%2 else -.5),g=.6)
def swap(t): add(whoosh(.5,700,6000,.16),t-.3,pan=.4); add(bell(T(86),1.0,.06),t,pan=-.3)
if MODE=="luks":
    intro(1.25); groove(3.0,20.5,bright=False)
    for t in (8.2,12.4,16.6): swap(t)
    outro(20.8)
else:
    intro(1.35); groove(3.0,20.5,bright=True)
    if not (len(sys.argv)>5 and sys.argv[5]=='nobip'):
        for t in (4.6,5.4,6.2): add(beep(),t,pan=.1)
    for t in (8.6,12.6,16.6): swap(t)
    outro(20.8)
# ---------- mezcla ----------
mix=np.vstack([L,R])
# reverberación sencilla
ir_n=int(1.8*SR); t=np.arange(ir_n)/SR; ir=rng.standard_normal((2,ir_n))*np.exp(-t/0.45); ir[:, :int(.02*SR)]=0
wet=np.vstack([sg.fftconvolve(mix[c],ir[c])[:N] for c in range(2)])
wet=lp(wet,6000)*0.045
out=mix+wet
fade=np.ones(N); fn=int(1.6*SR); fade[-fn:]=np.linspace(1,0,fn)**1.5; fi=int(.03*SR); fade[:fi]=np.linspace(0,1,fi)
out*=fade
out=hp(out,30)
pk=np.max(np.abs(out)); out=out/pk*1.25; out=np.tanh(out)/np.tanh(1.25)*0.89
wf.write(sys.argv[4],SR,(out.T*32767).astype(np.int16))
print('ok',round(float(np.sqrt(np.mean(out**2))),3))
