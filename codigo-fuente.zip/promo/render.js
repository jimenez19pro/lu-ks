const {chromium}=require('playwright');const fs=require('fs');(async()=>{
const mode=process.argv[2]||'preview';const fps=30,DUR=22;
const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:540,height:960},deviceScaleFactor:2})).newPage();
await p.goto('file:///home/claude/promo/promo.html');await p.waitForTimeout(800);
await p.evaluate(()=>document.getAnimations().forEach(a=>a.pause()));
const at=async ms=>{await p.evaluate(t=>document.getAnimations().forEach(a=>{a.currentTime=t}),ms)};
if(mode==='preview'){const T=(process.argv[3]||'1500,5000,7000,9000,11800,14800,16000,20000').split(',').map(Number);for(const t of T){await at(t);await p.waitForTimeout(60);await p.screenshot({path:'/home/claude/promo/pv'+t+'.jpg',type:'jpeg',quality:80})}}
else{fs.mkdirSync('/home/claude/promo/fr',{recursive:true});const N=fps*DUR;for(let f=0;f<N;f++){await at(f*1000/fps);await p.screenshot({path:'/home/claude/promo/fr/'+String(f).padStart(4,'0')+'.jpg',type:'jpeg',quality:93})}}
await b.close();console.log('done')})();
