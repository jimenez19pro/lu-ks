D = r'''
(opcional)|(optional)
(toca para marcar)|(tap to select)
+ Agregar|+ Add
- - - Promedio mensual: {}|- - - Monthly average: {}
. Escribe cuánto tienes hoy y la app ajusta el resto con tus movimientos.|. Type what you have today and the app adjusts the rest with your transactions.
/ meta {}%|/ goal {}%
Abonar ahora (opcional)|Pay now (optional)
Actualizar|Update
Agrega una cuenta que ya tienes. Esta app solo lleva el control de tu dinero: no es un banco ni mueve tus fondos.|Add an account you already have. This app only tracks your money: it isn't a bank and doesn't move your funds.
Agregar cuenta|Add account
Agregar movimiento|Add transaction
Agregar recurrente|Add recurring payment
Ahorrado hasta ahora (COP)|Saved so far (COP)
Ahorraste|You saved
Ahorro|Savings
Ahorros|Savings
Ahorros y deudas|Savings & debts
Ahorros y metas|Savings & goals
Ajustes|Settings
Al año|Per year
Al guardar, eliminar y en las celebraciones ·|When saving, deleting and celebrating ·
Al ritmo actual, al año|At this pace, per year
Amplio|Wide
Anota lo que compraste a cuotas para saber cuánto te falta y cuánto tienes comprometido cada mes.|Track what you bought in installments to see what's left and what you owe each month.
Análisis|Analysis
Apariencia|Appearance
Apodo (opcional)|Nickname (optional)
Ayer|Yesterday
Hoy|Today
Balance del período|Period balance
Banco|Bank
Barras (top categorías)|Bars (top categories)
Billetera|Wallet
Borrar búsqueda|Clear search
Buscar banco…|Search bank…
Buscar en la app|Search the app
Buscar movimientos|Search transactions
Buscar: uber, mercado, {}, >{}k…|Search: uber, groceries, {}, >{}k…
Calculado con tus movimientos; metas y deudas se toman con su valor actual.|Calculated from your transactions; goals and debts use their current value.
Cambiar tipo|Change type
Cancelar|Cancel
Categoría|Category
Categorías|Categories
Categorías y subcategorías|Categories & subcategories
Cerrar|Close
Chat financiero|Money chat
Chat financiero 💬|Money chat 💬
Claro|Light
Oscuro|Dark
Compacto|Compact
Compara cuánto te cuesta pagar solo el mínimo frente a abonar más cada mes.|Compare paying only the minimum vs. paying more each month.
Compras a cuotas|Installment purchases
Compras más grandes|Biggest purchases
Configuración|Configuration
Crea, edita o elimina tus categorías|Create, edit or delete your categories
Crear gasto|Save expense
Guardar gasto|Save expense
Crear ingreso|Save income
Crear transferencia|Save transfer
Crédito|Credit
Cuenta|Account
Cuenta destino|Destination account
Cuenta o efectivo|Account or cash
Cuenta principal|Main account
Cuentas|Accounts
Cuentas exentas|Exempt accounts
Cuentas y tarjetas|Accounts & cards
Cuentas, tarjetas, presupuestos y pagos recurrentes|Accounts, cards, budgets and recurring payments
Cupo total (COP)|Credit limit (COP)
Cupo total|Credit limit
Cómo baja tu deuda|How your debt goes down
Debes|You owe
Debes en total|Total debt
Del período|This period
Desliza para ver tus tarjetas →|Swipe to see your cards →
Detecté {} cobros que se repiten cada mes ({} al año). ¿Los agrego a tus pagos recurrentes?|I found {} charges that repeat every month ({} per year). Add them to your recurring payments?
Deuda|Debt
Deuda actual (COP)|Current debt (COP)
Deudas|Debts
Disp. {}|Avail. {}
Donde más puedes recortar|Where you can cut the most
Débito|Debit
Débito (ahorros)|Debit (savings)
Débito (ahorros) · {} COP|Debit (savings) · {} COP
Día del mes ({}-{})|Day of the month ({}-{})
Dónde se van|Where it goes
Editar cuenta|Edit account
Editar deuda|Edit debt
Editar meta|Edit goal
Editar monto o comercio|Edit amount or merchant
Editar recurrente|Edit recurring payment
Editar movimiento|Edit transaction
Guardar cambios|Save changes
Efectivo|Cash
Elegir ahorros y meta|Choose savings and goal
Elegir categorías fijas|Choose fixed categories
Elegir necesidades|Choose needs
Elige categoría|Choose category
Elige tu banco|Choose your bank
Eliminar|Delete
Eliminar cuenta|Delete account
Toca otra vez para eliminar|Tap again to delete
En {} días · día {}|In {} days · day {}
En {}|In {}
Entradas|Income
Enviar|Send
Escanear recibo|Scan receipt
Escribe deuda, tasa y pago mínimo para comparar.|Enter debt, rate and minimum payment to compare.
Escribe el valor y las cuotas para ver la cuota mensual.|Enter the price and installments to see the monthly payment.
Escribe lo que piensas comprar y te digo cómo quedarías.|Type what you plan to buy and I'll tell you how you'd end up.
Escribe monto y plazo para ver la cuota.|Enter amount and term to see the payment.
Escribe tu pregunta|Type your question
Escribe un monto para ver el resultado.|Enter an amount to see the result.
Escribe un movimiento con tus palabras y lo convierto en un gasto o ingreso para que lo revises antes de guardar.|Describe a transaction in your own words and I'll turn it into an expense or income for you to review before saving.
Espaciado|Spacing
Este mes|This month
Este mes paga así|Pay this month like this
Este mes pagas|This month you pay
Te falta por pagar|Left to pay
Comprometido próximos {} meses|Committed next {} months
Estimado: {}% de tus pagos, retiros y transferencias desde cuentas de banco no exentas.|Estimate: {}% of your payments, withdrawals and transfers from non-exempt bank accounts.
Esto toma unos segundos. Después podrás revisar todo antes de guardar.|This takes a few seconds. Then you can review everything before saving.
Exportación|Export
Exportar|Export
Exportar movimientos|Export transactions
Favoritos|Favorites
Fecha|Date
Fecha de la primera cuota|First installment date
Fecha límite (opcional)|Due date (optional)
Fijos vs. variables|Fixed vs. variable
Filtrar por fecha|Filter by date
Filtro|Filter
Finanzas|Finances
Fondo de emergencia|Emergency fund
Fondo de emergencia 🛟|Emergency fund 🛟
Gastado hoy|Spent today
Gastaste|You spent
Gasto|Expense
Gasto de los últimos {} meses|Spending over the last {} months
Gasto mensual promedio: {} (últimos {} meses)|Average monthly spending: {} (last {} months)
Gasto mensual promedio: {} (estimado este mes)|Average monthly spending: {} (estimated this month)
Gasto por categoría|Spending by category
Gastos|Expenses
Gastos de|Spending in
Gastos de hasta|Expenses up to
Gastos fijos ⚓|Fixed expenses ⚓
Gastos hormiga 🐜|Small leaks 🐜
General|Overview
Generar CSV|Generate CSV
Gestionar cuentas|Manage accounts
Gestión rápida|Quick management
Grande|Large
Guardar|Save
Guardar dinero|Save money
Guardar presupuesto|Save budget
Herramientas|Tools
Hogar|Home
Hoy la app calcula|Today the app calculates
Hoy puedes gastar|You can spend today
Hoy puedes gastar {} 💪|You can spend {} today 💪
Hoy te pasaste por|Today you went over by
Ingreso a repartir (COP)|Income to split (COP)
Ingreso|Income
Ingresos|Income
Ingresos +{}|Income +{}
Inicio|Home
Interpretar|Interpret
Interés mensual %|Monthly interest %
Leyendo tu recibo…|Reading your receipt…
Limpiar|Clear
Listo|Done
Llevas {} en {} días · {} por día en gastos variables · incluye {} de pagos fijos pendientes|You've spent {} in {} days · {} per day in variable expenses · includes {} in pending fixed payments
Llevas {} en {} días · {} por día en gastos variables|You've spent {} in {} days · {} per day in variable expenses
Lo que debes|What you owe
Lo que podrías pagar|What you could pay
Lo que tienes menos lo que debes|What you have minus what you owe
Lo recomendado suele ser entre {} y {} meses de gastos.|It's usually recommended to have {} to {} months of expenses.
Manual|Manual
Marca la cuenta que tienes registrada como exenta ante tu banco. Las tarjetas de crédito y el efectivo no se cuentan. Las transferencias entre tus propias cuentas del mismo banco pueden no cobrarse, así que tómalo como un estimado.|Mark the account registered as exempt with your bank. Credit cards and cash aren't counted. Transfers between your own accounts at the same bank may not be charged, so take it as an estimate.
Me deben|Owed to me
Mensual|Monthly
Mes|Month
Mes completo|Full month
Meta|Goal
Meta (meses de gastos)|Goal (months of expenses)
Meta de ahorro|Savings goal
Metas de ahorro|Savings goals
Mira cuánto pagarías antes de pedir un préstamo o diferir una compra.|See what you'd pay before taking a loan or financing a purchase.
Mis cuentas|My accounts
Monto|Amount
Monto (COP)|Amount (COP)
Monto del crédito (COP)|Loan amount (COP)
Monto mensual (COP)|Monthly amount (COP)
Monto total (COP)|Total amount (COP)
Mostrar u ocultar montos|Show or hide amounts
Movimientos|Transactions
Muy grande|Extra large
Mírala en tu extracto, ej. {}|Check your statement, e.g. {}
Navegación|Navigation
No|No
Sí|Yes
Nombre|Name
Nombre (igual al de tus movimientos)|Name (same as in your transactions)
Nombre en tus movimientos|Name in your transactions
Normal|Normal
Notas AI|AI notes
Nueva categoría|New category
Nueva compra a cuotas|New installment purchase
Nueva compra a cuotas 💳|New installment purchase 💳
Editar compra a cuotas 💳|Edit installment purchase 💳
Nueva deuda|New debt
Nueva meta|New goal
Nuevo movimiento|New transaction
Número de cuotas|Number of installments
Objetivo (COP)|Target (COP)
Ocio|Entertainment
Opciones|Options
Opciones avanzadas|Advanced options
Orden en que terminas|Order you'll finish
Pagado hasta ahora (COP)|Paid so far (COP)
Pagando {} al mes · este mes enfócate en|Paying {} per month · this month focus on
Pagas el mínimo de todas y lo que te sobre va a una sola deuda. Cuando la terminas, ese dinero pasa a la siguiente.|You pay the minimum on all of them and the rest goes to one debt. When it's done, that money moves to the next one.
Pagas menos intereses en total|You pay less interest overall
Pago extra al mes, además de los mínimos (COP)|Extra monthly payment, besides minimums (COP)
Pago mínimo|Minimum payment
Pago mínimo mensual|Minimum monthly payment
Pago recurrente|Recurring payment
Pagos recurrentes|Recurring payments
Pagos recurrentes al mes|Recurring payments per month
Para diferenciar varias cuentas o tarjetas del mismo banco.|To tell apart several accounts or cards from the same bank.
Pastel (gastos)|Pie (expenses)
Patrimonio|Net worth
Patrimonio neto|Net worth
Patrimonio neto últimos {} meses|Net worth last {} months
Pendiente|Pending
Pequeño|Small
Perfil|Profile
Persona o entidad|Person or institution
Personal|Personal
Período anterior|Previous period
Período siguiente|Next period
Plan de deudas|Debt plan
Plan de sueldo|Paycheck plan
Plan de sueldo 💼|Paycheck plan 💼
Plan para salir de deudas|Debt payoff plan
Plan para salir de deudas 🧗|Debt payoff plan 🧗
Plazo (meses)|Term (months)
Por categoría · toca para ver|By category · tap to view
Pregúntame lo que quieras sobre tus finanzas. Uso tus datos reales de la app.|Ask me anything about your finances. I use your real app data.
Presupuesto|Budget
Presupuestos|Budgets
Probar|Try
Promedio por gasto|Average per expense
Próximos pagos|Upcoming payments
Quincena ({} días)|Two weeks ({} days)
Registrar|Register
Regla {}/{}/{}|{}/{}/{} rule
Reparte tu ingreso entre pagos fijos, ahorro y el día a día.|Split your income between fixed payments, savings and everyday spending.
Reparto del gasto|Spending breakdown
Reportería|Reports
Reportes|Reports
Resta {}|{} left
Ropa|Clothing
Saldo + ahorros|Balance + savings
Saldo actual|Current balance
Saldo actual (hoy)|Current balance (today)
Saldo inicial|Opening balance
Saldo inicial o deuda actual (COP)|Opening balance or current debt (COP)
Salidas|Expenses
Salud|Health
Selecciona cuenta|Select account
Servicios|Utilities
Sigue registrando para cumplir tus metas.|Keep tracking to reach your goals.
Simulador de crédito|Loan simulator
Simulador de crédito 🏦|Loan simulator 🏦
Sin categoría|Uncategorized
Sin cuenta|No account
Sin subcategorías|No subcategories
Siri|Siri
Sobre {} de ingresos|Based on {} income
Solo es seguimiento: no crea movimientos en tu hoja.|Tracking only: it doesn't create transactions.
Sonidos|Sounds
Supone que no haces compras nuevas y que el pago es fijo cada mes. Si pagas el total antes de la fecha límite, normalmente no pagas intereses en compras a una cuota.|Assumes no new purchases and a fixed monthly payment. If you pay the full balance before the due date, you usually pay no interest on single-installment purchases.
Suscripciones y cobros fijos|Subscriptions & fixed charges
Tamaño del texto|Text size
Tarjeta de crédito|Credit card
Tarjeta de crédito · debes {}|Credit card · you owe {}
Tarjeta de crédito 🔥|Credit card 🔥
Tarjeta o cuenta|Card or account
Tarjetas|Cards
Tasa E.A. %|Annual rate %
Tasa de interés %|Interest rate %
Tasa de interés E.A. %|Annual interest rate %
Te deben|Owed to you
Te quedan {}|{} left
Te quedan {} del presupuesto para {} días · {} por día|{} left in your budget for {} days · {} per day
Te quedarían {} de tus ingresos del mes|You'd have {} left from this month's income
Te sobrarían {} del presupuesto|You'd have {} left in your budget
Te pasarías del presupuesto por {}|You'd go over budget by {}
Tema|Theme
Tendencia · últimos {} meses|Trend · last {} months
Terminas deudas más rápido y te motiva|You finish debts faster and stay motivated
Tienes|You have
Tienes {} de {} · te faltan {}|You have {} of {} · {} to go
Tipo|Type
Tipo de movimiento|Transaction type
Toca ⌄ para ver las subcategorías y ⋯ para editar o eliminar.|Tap ⌄ to see subcategories and ⋯ to edit or delete.
Todas|All
Todas las transacciones|All transactions
Todo el tiempo|All time
Todos|All
Top comercios|Top merchants
Total gasto|Total spent
Transacciones|Transactions
Transferencias|Transfers
Transferencia|Transfer
Transporte|Transportation
Tu año en Lu-Ks|Your year in Lu-Ks
Tu categoría top|Your top category
Tu compra más grande|Your biggest purchase
Tu lugar favorito|Your favorite place
Tu mes más caro|Your most expensive month
El día que más gastas|The day you spend the most
La que más creció|The one that grew the most
Tu nombre|Your name
Tu {} en Lu-Ks|Your {} in Lu-Ks
Tu {} en Lu-Ks 🎉|Your {} in Lu-Ks 🎉
Tus datos|Your data
Tus deudas|Your debts
Título (opcional)|Title (optional)
Valor antes de los movimientos registrados. Se calcula solo si llenas el saldo actual.|Value before the recorded transactions. It's calculated if you fill in the current balance.
Valor total (COP)|Total price (COP)
Vas|You're
Ver detalle y cuentas exentas|See details and exempt accounts
Ver en Transacciones|View in Transactions
Ver ese mes en Transacciones|View that month in Transactions
Ver mi plan|See my plan
Ver resultados|See results
Ver subcategorías|View subcategories
Ver todo ›|See all ›
WhatsApp de la persona (opcional)|Person's WhatsApp (optional)
💬 Cobrar por WhatsApp|💬 Ask for payment on WhatsApp
Yo debo|I owe
al mes.|per month.
gastados|spent
registrados este año. ¡Así se lleva el control!|recorded this year. That's how you stay in control!
y te ahorras|and you save
{} = sin interés|{} = no interest
{} compra · promedio {}|{} purchase · avg {}
{} compras · promedio {}|{} purchases · avg {}
{} de {}|{} of {}
{} de {} cuotas|{} of {} installments
{} en el año|{} in the year
{} meses|{} months
{} mes|{} month
{} meses antes|{} months earlier
{} movimientos|{} transactions
{} movimiento|{} transaction
{} movimientos · ingresos {}|{} transactions · income {}
{} visitas · {}|{} visits · {}
{}% de tus ingresos|{}% of your income
{}% de tus {} de ingresos|{}% of your {} income
{}% del gasto|{}% of spending
{}% de tus gastos|{}% of your expenses
{}x{} (GMF) 🇨🇴|{}x{} tax (GMF) 🇨🇴
¡Vamos por un {} aún mejor!|Here's to an even better {}!
¿Con qué pagarías?|What would you pay with?
¿Cuánto cuesta? (COP)|How much is it? (COP)
¿Cómo quieres registrar hoy?|How do you want to record it?
¿Cómo te llamo? 👋|What should I call you? 👋
¿Cómo voy con mis presupuestos?|How am I doing with my budgets?
¿En qué puedo recortar?|Where can I cut back?
¿Me alcanza?|Can I afford it?
¿Me alcanza? 🤔|Can I afford it? 🤔
🤔 ¿Me alcanza?|🤔 Can I afford it?
¿Para cuánto tiempo?|For how long?
¿Por qué gasté más este mes?|Why did I spend more this month?
¿Qué compraste?|What did you buy?
¿Qué cuenta quieres registrar?|What account do you want to add?
¿Qué deuda pagar primero?|Which debt to pay first?
¿Qué dinero cuenta como fondo?|What money counts as the fund?
¿Qué pasó?|What happened?
Últimos movimientos|Latest transactions
‹ Ajustes|‹ Settings
‹ Perfil|‹ Profile
▲ {} vs. el mes pasado|▲ {} vs. last month
▼ {} vs. el mes pasado|▼ {} vs. last month
⚓ Fijos|⚓ Fixed
🎈 Variables|🎈 Variable
⚙️ Administrar categorías|⚙️ Manage categories
⛄ La más pequeña primero|⛄ Smallest first
🏔️ La más cara primero|🏔️ Most expensive first
🎉 Quedas libre de deudas en|🎉 You'll be debt-free in
🧗 Quedas libre en|🧗 Debt-free by
🎉 Gustos|🎉 Wants
🏠 Necesidades|🏠 Needs
💰 Ahorro|💰 Savings
🎉 Tu año|🎉 Your year
🏦 Simulador de crédito|🏦 Loan simulator
🔥 Tarjeta de crédito|🔥 Credit card
👆 Toca un mes para ver el detalle|👆 Tap a month to see details
👆 Toca una barra para ver el detalle|👆 Tap a bar to see details
💡 Si los reduces a la mitad, ahorrarías cerca de|💡 If you cut them in half, you'd save about
💼 Plan de sueldo|💼 Paycheck plan
📈 A este ritmo cerrarás el mes con|📈 At this pace you'll end the month with
📋 Repetir con fecha de hoy|📋 Repeat with today's date
📌 Pagos fijos|📌 Fixed payments
🛒 Para el día a día|🛒 For everyday spending
🛟 Tus ahorros cubren|🛟 Your savings cover
🇨🇴 Este mes|🇨🇴 This month
＋ Agregar cuenta|＋ Add account
+ Agrega tu primera cuenta|+ Add your first account
Dónde más gastas|Where you spend the most
Rango|Range
Cuidado personal|Personal care
Educación|Education
Mascotas|Pets
Viajes|Travel
Impuestos|Taxes
Comida|Food
Antes de comprar algo grande, pregúntate «¿Me alcanza?» 🤔|Before buying something big, ask yourself "Can I afford it?" 🤔
Anotar cada gasto, por pequeño que sea, es el primer paso para ahorrar 📝|Tracking every expense, however small, is the first step to saving 📝
Un café al día puede ser más de $100.000 al mes ☕|A coffee a day can be over $100.000 a month ☕
Págate primero: separa tu ahorro apenas te llegue el sueldo 💰|Pay yourself first: set aside savings as soon as you get paid 💰
Revisa tus suscripciones: ¿todavía usas todas? 📺|Check your subscriptions: do you still use them all? 📺
Pagar más que el mínimo de la tarjeta te ahorra intereses 🔥|Paying more than the card minimum saves you interest 🔥
Tu fondo de emergencia es tu tranquilidad 🛟|Your emergency fund is your peace of mind 🛟
Pequeños ahorros diarios hacen grandes metas 🎯|Small daily savings make big goals 🎯
Compara precios antes de comprar; tu bolsillo lo agradece 🛒|Compare prices before buying; your wallet will thank you 🛒
Hoy es un buen día para revisar tu presupuesto 📊|Today is a good day to review your budget 📊
Buenos días|Good morning
Buenas tardes|Good afternoon
Buenas noches|Good evening
Sincronizado|Synced
Sincronizado · {}:{} p. m.|Synced · {}:{} PM
Sincronizado · {}:{} a. m.|Synced · {}:{} AM
Conectando…|Connecting…
¡Bienvenido! Toca + para registrar tu primer movimiento.|Welcome! Tap + to record your first transaction.
No hay movimientos con estos filtros.|No transactions match these filters.
Aún no hay gastos en este período.|No expenses in this period yet.
Recientes:|Recent:
Borrar|Clear
Este período|This period
Todo el historial|All history
Hoy puedes gastar|You can spend today
Pon tus presupuestos para saber cuánto puedes gastar cada día.|Set your budgets to see how much you can spend each day.
Aún no tienes pagos próximos|You have no upcoming payments
Cambios guardados|Changes saved
Categoría eliminada|Category deleted
Clave guardada|Key saved
Completa nombre y monto total|Fill in name and total amount
Completa nombre y objetivo|Fill in name and target
Completa nombre, monto y día (1-31)|Fill in name, amount and day (1-31)
Completa nombre, valor y cuotas|Fill in name, price and installments
Copiado|Copied
Dirección copiada|Address copied
Elige cuentas de origen y destino distintas|Choose different source and destination accounts
Eliminado|Deleted
Eliminada|Deleted
Escribe algo primero|Type something first
Escribe el cupo total|Enter the credit limit
Escribe un monto mayor a 0|Enter an amount greater than 0
Escribe un nombre|Enter a name
Ese archivo no es un respaldo de Lu-Ks|That file isn't a Lu-Ks backup
Espera a que cargue la hoja|Wait for your data to load
Espera a que carguen tus categorías|Wait for your categories to load
Gasto guardado en tu hoja|Expense saved
Guardado|Saved
Meta guardada|Goal saved
Deuda guardada|Debt saved
Compra a cuotas guardada|Installment purchase saved
Presupuesto guardado|Budget saved
No entendí el monto. Escríbelo y guarda 🙂|I didn't catch the amount. Type it and save 🙂
No pude leer tus datos. Revisa tu conexión|Couldn't read your data. Check your connection
No se pudo guardar el ajuste|Couldn't save the setting
No se pudo guardar en la nube. Revisa tu conexión|Couldn't save to the cloud. Check your connection
No se pudo guardar. Revisa la hoja antes de repetir|Couldn't save. Check before trying again
Respaldo descargado 💾|Backup downloaded 💾
Respaldo listo 💾|Backup ready 💾
Revisa el monto y guarda|Check the amount and save
Revisa los datos y toca Guardar|Check the details and tap Save
Subcategoría eliminada|Subcategory deleted
Te reenviamos el correo de verificación 📩|We resent the verification email 📩
Toca de nuevo para eliminar. Tus movimientos no se borran.|Tap again to delete. Your transactions won't be erased.
Toca otra vez para cerrar sesión|Tap again to sign out
Ya existe esa subcategoría|That subcategory already exists
Ya existe una categoría con ese nombre|A category with that name already exists
Sin internet: tus gastos se guardarán en el teléfono|Offline: your expenses will be saved on the phone
Importado|Imported
No había nada nuevo para importar|There was nothing new to import
¡Datos importados!|Data imported!
¡Meta cumplida!|Goal reached!
¡Deuda pagada!|Debt paid off!
¡Te pagaron!|You got paid back!
¡Compra pagada!|Purchase paid off!
¡Tu Lu-Ks está listo!|Your Lu-Ks is ready!
Ya puedes registrar tu primer movimiento con el botón +|You can now record your first transaction with the + button
Toca + para registrar tu primer movimiento|Tap + to record your first transaction
Iniciar sesión|Sign in
Crear cuenta|Sign up
Correo|Email
Contraseña|Password
Entrar|Sign in
Crear mi cuenta|Create my account
¿Olvidaste tu contraseña?|Forgot your password?
Al crear tu cuenta aceptas la|By creating an account you accept the
política de privacidad|privacy policy
. Tus datos son solo tuyos.|. Your data is yours alone.
Tus finanzas, claras|Your finances, made clear
Asistente con IA|AI assistant
Asistente con IA 🤖|AI assistant 🤖
Clave de Gemini|Gemini key
Opcional y gratis · activa el chat y el escaneo de recibos|Optional and free · enables chat and receipt scanning
Activa: chat, Notas AI y escaneo de recibos|Active: chat, AI notes and receipt scanning
Tu cuenta|Your account
Tus datos se guardan en la nube y se sincronizan en tus dispositivos|Your data is stored in the cloud and synced across your devices
Política de privacidad|Privacy policy
Cerrar sesión|Sign out
Eliminar mi cuenta|Delete my account
Borra tu cuenta y todos tus datos para siempre|Deletes your account and all your data forever
Exportar mi respaldo|Export my backup
Descarga un archivo con todos tus datos|Download a file with all your data
Importar datos|Import data
Importar datos 📥|Import data 📥
Trae tus cuentas y movimientos desde un archivo de respaldo|Bring your accounts and transactions from a backup file
Ver recorrido de bienvenida|View welcome tour
Verifica tu correo|Verify your email
Te enviamos un enlace al registrarte · toca para reenviarlo|We sent you a link when you signed up · tap to resend
Anotar con Siri|Log with Siri
Anotar con Siri 🎙️|Log with Siri 🎙️
«Oye Siri, anotar en Lu-Ks» y dicta tu gasto|"Hey Siri, log in Lu-Ks" and dictate your expense
Omitir|Skip
‹ Atrás|‹ Back
Siguiente|Next
Configurar mi Lu-Ks|Set up my Lu-Ks
¡Listo, empezar! 🚀|Done, let's go! 🚀
Bienvenido a Lu-Ks|Welcome to Lu-Ks
Tu plata, clara y en un solo lugar. Te muestro lo principal en un minuto.|Your money, clear and in one place. I'll show you the basics in a minute.
Registra en segundos|Record in seconds
Entiende a dónde va tu plata|Understand where your money goes
Presupuestos, reportes, proyección del mes y cuánto puedes gastar hoy, todo se calcula solo.|Budgets, reports, month forecast and how much you can spend today, all calculated automatically.
Metas, deudas y cuotas|Goals, debts and installments
¿Dónde tienes tu plata?|Where do you keep your money?
Marca tus cuentas y escribe cuánto tienes hoy. Lu-Ks no se conecta a tu banco: solo lleva tus cuentas.|Pick your accounts and enter what you have today. Lu-Ks doesn't connect to your bank: it only tracks your accounts.
Saldo de hoy|Today's balance
¿Cuánto debes hoy?|How much do you owe today?
¿Cuánto quieres gastar al mes?|How much do you want to spend per month?
Pon un tope a lo principal. Puedes dejarlo en blanco y cambiarlo cuando quieras.|Set a cap for the main ones. You can leave it blank and change it anytime.
¿Qué quieres traer?|What do you want to bring?
📂 Elegir archivo|📂 Choose file
Importar|Import
🏦 Cuentas y tarjetas|🏦 Accounts & cards
💸 Movimientos|💸 Transactions
📊 Presupuestos|📊 Budgets
🔁 Pagos recurrentes|🔁 Recurring payments
🤝 Deudas|🤝 Debts
🎯 Metas|🎯 Goals
💳 Compras a cuotas|💳 Installment purchases
🏷️ Categorías y subcategorías|🏷️ Categories & subcategories
🧠 Categorías aprendidas de comercios|🧠 Categories learned from merchants
⚙️ Ajustes (plan de deudas, sonidos)|⚙️ Settings (debt plan, sounds)
Eliminar definitivamente|Delete permanently
Escribe tu contraseña para confirmar|Enter your password to confirm
Se borrarán tu cuenta y todos tus movimientos, cuentas, metas y ajustes. No se puede deshacer.|Your account and all your transactions, accounts, goals and settings will be deleted. This can't be undone.
✨ Hay una versión nueva de Lu-Ks|✨ A new version of Lu-Ks is available
Prueba aquí cómo lo entiende|Try here how it understands you
Abrir el formulario con esto|Open the form with this
📋 Copiar dirección|📋 Copy address
Crea el atajo (una sola vez)|Create the shortcut (only once)
Di «Oye Siri, anotar en Lu-Ks», dicta el gasto y Lu-Ks se abre con todo listo para guardar.|Say "Hey Siri, log in Lu-Ks", dictate the expense and Lu-Ks opens with everything ready to save.
Correo o contraseña incorrectos.|Wrong email or password.
La contraseña debe tener al menos 6 caracteres.|Password must be at least 6 characters.
Ya existe una cuenta con ese correo. Inicia sesión.|An account with that email already exists. Sign in.
El correo no es válido.|That email isn't valid.
Escribe tu contraseña.|Enter your password.
Sin conexión. Revisa tu internet.|No connection. Check your internet.
Algo salió mal. Inténtalo de nuevo.|Something went wrong. Try again.
Te enviamos un correo para cambiar tu contraseña 📩|We sent you an email to reset your password 📩
Escribe tu correo arriba y vuelve a tocar aquí.|Enter your email above and tap here again.
Ej. Jose|E.g. Jose
Mínimo 6 caracteres|At least 6 characters
Tu contraseña|Your password
tucorreo@ejemplo.com|you@example.com
¿Qué anoto?|What should I log?
Gastos de|Spending in
Este mes|This month
Mayo|May
Otro|Other
'''
