var C="luks-tienda-v4";
// Librerías del escáner: se guardan en el celular para que funcione sin internet.
var LIB=["https://cdn.jsdelivr.net/npm/barcode-detector@3.0.8/dist/iife/polyfill.min.js","https://fastly.jsdelivr.net/npm/zxing-wasm@2.2.4/dist/reader/zxing_reader.wasm"];
var LIBRX=/(jsdelivr\.net|unpkg\.com)\/(npm\/)?(barcode-detector@|zxing-wasm@|@zxing\/library@)/;
function guardarLibs(c){return Promise.all(LIB.map(function(u){return caches.match(u,{ignoreVary:true}).then(function(h){if(h)return;return fetch(u,{mode:"cors"}).then(function(r){if(r&&r.ok)return c.put(u,r)})}).catch(function(){})}))}
self.addEventListener("install",function(e){e.waitUntil(caches.open(C).then(function(c){return c.addAll(["./","index.html","manifest.json","icon-192.png","icon-512.png","apple-touch-icon.png","../config.js"]).then(function(){return guardarLibs(c)})}).then(function(){return self.skipWaiting()}).catch(function(){}))});
self.addEventListener("activate",function(e){e.waitUntil(caches.keys().then(function(k){return Promise.all(k.filter(function(x){return x.indexOf("luks-tienda-")===0&&x!==C}).map(function(x){return caches.delete(x)}))}).then(function(){return self.clients.claim()}).then(function(){return caches.open(C).then(guardarLibs)}))});
self.addEventListener("fetch",function(e){var u=new URL(e.request.url);if(e.request.method!=="GET")return;
if(LIBRX.test(u.href)){e.respondWith(caches.match(e.request,{ignoreVary:true}).then(function(h){return h||fetch(e.request).then(function(r){if(r&&r.ok){var cp=r.clone();caches.open(C).then(function(c){c.put(e.request,cp)})}return r})}));return}
if(/\.(mp4|webm)$/i.test(u.pathname))return;
var same=u.origin===location.origin,gs=/gstatic\.com\/firebasejs|fonts\.(googleapis|gstatic)\.com/.test(u.href);if(!same&&!gs)return;e.respondWith(fetch(e.request).then(function(r){if(r&&(r.ok||r.type==="opaque")){var cp=r.clone();caches.open(C).then(function(c){c.put(e.request,cp)})}return r}).catch(function(){return caches.match(e.request).then(function(r){return r||(same?caches.match("index.html"):undefined)})}))});
